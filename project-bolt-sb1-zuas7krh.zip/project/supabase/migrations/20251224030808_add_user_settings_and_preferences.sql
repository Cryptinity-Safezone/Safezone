/*
  # Add User Settings and Preferences

  ## Overview
  This migration adds user preferences for privacy, safety, and experience settings.

  ## Changes to user_profiles Table
  
  ### Privacy & Safety Settings
  - `messaging_preference` (text) - Controls who can send messages
    - 'mutual_followers' - Only mutual followers can message
    - 'message_requests' - Anyone can send message requests (default)
  - `post_visibility` (text) - Controls who can see posts
    - 'everyone' - Public posts (default)
    - 'followers_only' - Only followers see posts

  ### Sound & Experience Settings
  - `background_sound_enabled` (boolean) - Background sound toggle (default: false)
  - `autoplay_sound` (boolean) - Autoplay sound on app load (default: false)
  - `master_volume` (numeric) - Volume level 0-100 (default: 50)
  - `reduce_motion` (boolean) - Reduce animations/motion (default: false)

  ## Security
  - Users can only update their own settings via existing RLS policies
  - No new policies needed
*/

-- Add privacy settings
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'messaging_preference'
  ) THEN
    ALTER TABLE user_profiles 
    ADD COLUMN messaging_preference text DEFAULT 'message_requests' NOT NULL 
    CHECK (messaging_preference IN ('mutual_followers', 'message_requests'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'post_visibility'
  ) THEN
    ALTER TABLE user_profiles 
    ADD COLUMN post_visibility text DEFAULT 'everyone' NOT NULL 
    CHECK (post_visibility IN ('everyone', 'followers_only'));
  END IF;
END $$;

-- Add sound & experience settings
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'background_sound_enabled'
  ) THEN
    ALTER TABLE user_profiles 
    ADD COLUMN background_sound_enabled boolean DEFAULT false NOT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'autoplay_sound'
  ) THEN
    ALTER TABLE user_profiles 
    ADD COLUMN autoplay_sound boolean DEFAULT false NOT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'master_volume'
  ) THEN
    ALTER TABLE user_profiles 
    ADD COLUMN master_volume numeric(5,2) DEFAULT 50.00 NOT NULL 
    CHECK (master_volume >= 0 AND master_volume <= 100);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'reduce_motion'
  ) THEN
    ALTER TABLE user_profiles 
    ADD COLUMN reduce_motion boolean DEFAULT false NOT NULL;
  END IF;
END $$;
