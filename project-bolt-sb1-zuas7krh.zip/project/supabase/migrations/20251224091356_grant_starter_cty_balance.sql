/*
  # Grant Starter CTY Balance

  ## Overview
  Implements initial CTY balance grants for users with tracking to prevent regeneration.

  ## Changes

  ### 1. New Column
  - `starter_cty_received` (boolean, default false) - Tracks if user received starter CTY

  ### 2. Updates to handle_new_user Function
  - Explicitly sets cty_balance to 100 for new users
  - Marks starter_cty_received as true
  - Logs the starter CTY grant as a transaction

  ### 3. One-Time Grant for Existing Users
  - Users with 0 CTY balance receive 50 CTY
  - Only applies if starter_cty_received is false
  - Transaction logged for transparency

  ## Security
  - No RLS changes (uses existing policies)
  - Function runs as SECURITY DEFINER with explicit search_path

  ## Notes
  - New users receive 100 CTY (enough for 4 standard images at 25 CTY each)
  - Existing users with 0 CTY receive 50 CTY (enough for 2 standard images)
  - Starter CTY cannot be regenerated once marked as received
*/

-- Add column to track starter CTY
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
    AND table_name = 'user_profiles'
    AND column_name = 'starter_cty_received'
  ) THEN
    ALTER TABLE public.user_profiles 
    ADD COLUMN starter_cty_received boolean DEFAULT false;
  END IF;
END $$;

-- Update handle_new_user function to grant starter CTY and log transaction
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  default_avatar text := 'data:image/svg+xml,' || public.uri_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:#0d9488"/><stop offset="100%" style="stop-color:#10b981"/></linearGradient></defs><rect width="100" height="100" rx="20" fill="url(#bg)"/><text x="50" y="65" font-family="system-ui,-apple-system,sans-serif" font-size="48" font-weight="600" fill="white" text-anchor="middle">C</text></svg>');
  default_cover text := 'data:image/svg+xml,' || public.uri_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 400"><defs><linearGradient id="cover" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:#0f172a"/><stop offset="50%" style="stop-color:#134e4a"/><stop offset="100%" style="stop-color:#0f172a"/></linearGradient><filter id="noise"><feTurbulence baseFrequency="0.65" numOctaves="3" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/></filter></defs><rect width="1600" height="400" fill="url(#cover)"/><rect width="1600" height="400" filter="url(#noise)" opacity="0.03"/></svg>');
  new_profile_id uuid;
BEGIN
  INSERT INTO public.user_profiles (
    id, 
    username, 
    handle, 
    avatar_url, 
    cover_url, 
    onboarding_completed,
    cty_balance,
    starter_cty_received
  )
  VALUES (
    NEW.id,
    COALESCE((NEW.raw_user_meta_data->>'username')::text, 'user_' || substring(NEW.id::text, 1, 8)),
    COALESCE((NEW.raw_user_meta_data->>'handle')::text, '@user_' || substring(NEW.id::text, 1, 8)),
    default_avatar,
    default_cover,
    false,
    100,
    true
  )
  RETURNING id INTO new_profile_id;

  INSERT INTO public.cty_transactions (
    user_id,
    amount,
    transaction_type,
    description,
    metadata
  ) VALUES (
    new_profile_id,
    100,
    'earn',
    'Welcome bonus - Starter CTY',
    jsonb_build_object(
      'type', 'starter_bonus',
      'granted_at', now()
    )
  );

  RETURN NEW;
EXCEPTION
  WHEN unique_violation THEN
    RETURN NEW;
  WHEN OTHERS THEN
    RAISE WARNING 'Error creating user profile: %', SQLERRM;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Grant one-time 50 CTY to existing users with 0 balance who haven't received starter CTY
DO $$
DECLARE
  user_record RECORD;
BEGIN
  FOR user_record IN 
    SELECT id 
    FROM public.user_profiles 
    WHERE cty_balance = 0 
    AND (starter_cty_received = false OR starter_cty_received IS NULL)
  LOOP
    UPDATE public.user_profiles
    SET 
      cty_balance = 50,
      starter_cty_received = true
    WHERE id = user_record.id;

    INSERT INTO public.cty_transactions (
      user_id,
      amount,
      transaction_type,
      description,
      metadata
    ) VALUES (
      user_record.id,
      50,
      'earn',
      'Recovery bonus - CTY grant for existing users',
      jsonb_build_object(
        'type', 'recovery_bonus',
        'granted_at', now()
      )
    );
  END LOOP;
END $$;

-- Mark all existing users with balance > 0 as having received starter CTY
UPDATE public.user_profiles
SET starter_cty_received = true
WHERE cty_balance > 0 AND (starter_cty_received = false OR starter_cty_received IS NULL);
