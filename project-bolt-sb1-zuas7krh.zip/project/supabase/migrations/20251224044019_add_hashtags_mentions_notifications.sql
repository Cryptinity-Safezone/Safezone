/*
  # Add Hashtags, Mentions, and Notifications

  1. New Tables
    - `hashtags`
      - `id` (uuid, primary key)
      - `name` (text, unique) - lowercase hashtag without #
      - `post_count` (integer) - number of posts using this hashtag
      - `created_at` (timestamptz)
    
    - `post_hashtags`
      - `id` (uuid, primary key)
      - `post_id` (uuid, references posts)
      - `hashtag_id` (uuid, references hashtags)
      - `created_at` (timestamptz)
    
    - `mentions`
      - `id` (uuid, primary key)
      - `post_id` (uuid, references posts)
      - `mentioned_user_id` (uuid, references user_profiles)
      - `mentioner_id` (uuid, references user_profiles)
      - `created_at` (timestamptz)
    
    - `notifications`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references user_profiles)
      - `type` (text) - 'mention', 'like', 'comment', 'follow', etc.
      - `actor_id` (uuid, references user_profiles)
      - `post_id` (uuid, references posts, nullable)
      - `content` (text, nullable)
      - `is_read` (boolean)
      - `created_at` (timestamptz)
    
    - `muted_users`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - the user doing the muting
      - `muted_user_id` (uuid) - the user being muted
      - `mute_mentions` (boolean) - mute mentions from this user
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all new tables
    - Add appropriate policies for authenticated users

  3. Indexes
    - Index on hashtags.name for fast lookups
    - Index on post_hashtags for post and hashtag lookups
    - Index on mentions for user lookups
    - Index on notifications for user and read status
*/

-- Create hashtags table
CREATE TABLE IF NOT EXISTS hashtags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  post_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE hashtags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Hashtags are viewable by everyone"
  ON hashtags FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create hashtags"
  ON hashtags FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "System can update hashtag counts"
  ON hashtags FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create post_hashtags junction table
CREATE TABLE IF NOT EXISTS post_hashtags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  hashtag_id uuid NOT NULL REFERENCES hashtags(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, hashtag_id)
);

ALTER TABLE post_hashtags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Post hashtags are viewable by everyone"
  ON post_hashtags FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Post authors can add hashtags"
  ON post_hashtags FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM posts
      WHERE posts.id = post_id
      AND posts.user_id = auth.uid()
    )
  );

CREATE POLICY "Post authors can remove hashtags"
  ON post_hashtags FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM posts
      WHERE posts.id = post_id
      AND posts.user_id = auth.uid()
    )
  );

-- Create mentions table
CREATE TABLE IF NOT EXISTS mentions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  mentioned_user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  mentioner_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, mentioned_user_id)
);

ALTER TABLE mentions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Mentions are viewable by involved users"
  ON mentions FOR SELECT
  TO authenticated
  USING (
    mentioned_user_id = auth.uid() OR mentioner_id = auth.uid()
  );

CREATE POLICY "Users can create mentions in their posts"
  ON mentions FOR INSERT
  TO authenticated
  WITH CHECK (mentioner_id = auth.uid());

CREATE POLICY "Post authors can delete mentions"
  ON mentions FOR DELETE
  TO authenticated
  USING (mentioner_id = auth.uid());

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  type text NOT NULL,
  actor_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  post_id uuid REFERENCES posts(id) ON DELETE CASCADE,
  content text,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Authenticated users can create notifications"
  ON notifications FOR INSERT
  TO authenticated
  WITH CHECK (actor_id = auth.uid() OR actor_id IS NULL);

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own notifications"
  ON notifications FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Create muted_users table for mention muting
CREATE TABLE IF NOT EXISTS muted_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  muted_user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  mute_mentions boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, muted_user_id)
);

ALTER TABLE muted_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own muted list"
  ON muted_users FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can mute others"
  ON muted_users FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid() AND muted_user_id != auth.uid());

CREATE POLICY "Users can update own mutes"
  ON muted_users FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can unmute others"
  ON muted_users FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_hashtags_name ON hashtags(name);
CREATE INDEX IF NOT EXISTS idx_hashtags_post_count ON hashtags(post_count DESC);
CREATE INDEX IF NOT EXISTS idx_post_hashtags_post_id ON post_hashtags(post_id);
CREATE INDEX IF NOT EXISTS idx_post_hashtags_hashtag_id ON post_hashtags(hashtag_id);
CREATE INDEX IF NOT EXISTS idx_mentions_mentioned_user ON mentions(mentioned_user_id);
CREATE INDEX IF NOT EXISTS idx_mentions_post ON mentions(post_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread ON notifications(user_id, is_read) WHERE is_read = false;
CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_muted_users_user ON muted_users(user_id);

-- Function to update hashtag post count
CREATE OR REPLACE FUNCTION update_hashtag_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE hashtags SET post_count = post_count + 1 WHERE id = NEW.hashtag_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE hashtags SET post_count = GREATEST(0, post_count - 1) WHERE id = OLD.hashtag_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

-- Trigger for hashtag count updates
DROP TRIGGER IF EXISTS trigger_update_hashtag_count ON post_hashtags;
CREATE TRIGGER trigger_update_hashtag_count
  AFTER INSERT OR DELETE ON post_hashtags
  FOR EACH ROW
  EXECUTE FUNCTION update_hashtag_count();

-- Function to create mention notification
CREATE OR REPLACE FUNCTION create_mention_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_muted boolean;
BEGIN
  SELECT mute_mentions INTO is_muted
  FROM muted_users
  WHERE user_id = NEW.mentioned_user_id
  AND muted_user_id = NEW.mentioner_id;

  IF is_muted IS NOT TRUE AND NEW.mentioned_user_id != NEW.mentioner_id THEN
    INSERT INTO notifications (user_id, type, actor_id, post_id, content)
    VALUES (NEW.mentioned_user_id, 'mention', NEW.mentioner_id, NEW.post_id, 'mentioned you in a post');
  END IF;

  RETURN NEW;
END;
$$;

-- Trigger for mention notifications
DROP TRIGGER IF EXISTS trigger_create_mention_notification ON mentions;
CREATE TRIGGER trigger_create_mention_notification
  AFTER INSERT ON mentions
  FOR EACH ROW
  EXECUTE FUNCTION create_mention_notification();
