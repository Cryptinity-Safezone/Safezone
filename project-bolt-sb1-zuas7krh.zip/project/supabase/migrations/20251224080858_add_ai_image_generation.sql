/*
  # AI Image Generation System
  
  1. New Tables
    - `generated_images` - Stores AI-generated images with metadata
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `prompt` (text, original user prompt)
      - `sanitized_prompt` (text, filtered prompt sent to AI)
      - `style` (text, selected style category)
      - `quality` (text, standard/high)
      - `image_url` (text, storage URL)
      - `thumbnail_url` (text, smaller preview)
      - `is_private` (boolean, privacy setting)
      - `is_shared` (boolean, shared to feed)
      - `cty_cost` (integer, CTY spent)
      - `generation_metadata` (jsonb, AI model info)
      - `created_at` (timestamptz)
    
    - `daily_generation_limits` - Tracks daily generation usage per user
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `date` (date, the day)
      - `generations_used` (integer, count for the day)
      - `last_generation_at` (timestamptz)
    
    - `blocked_prompts` - Admin list of blocked terms/patterns
      - `id` (uuid, primary key)
      - `pattern` (text, regex or exact match)
      - `pattern_type` (text, regex/exact/contains)
      - `category` (text, why blocked)
      - `is_active` (boolean)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Users can only access their own generated images
    - Users can only view/update their own limits
    - Blocked prompts readable by service role only

  3. Indexes
    - Index on user_id for generated_images
    - Index on is_private for feed queries
    - Composite index on user_id + date for limits
*/

-- Generated Images Table
CREATE TABLE IF NOT EXISTS public.generated_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  prompt text NOT NULL,
  sanitized_prompt text,
  style text DEFAULT 'abstract',
  quality text DEFAULT 'standard' CHECK (quality IN ('standard', 'high')),
  image_url text,
  thumbnail_url text,
  is_private boolean DEFAULT true,
  is_shared boolean DEFAULT false,
  cty_cost integer DEFAULT 25,
  generation_metadata jsonb DEFAULT '{}',
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'generating', 'completed', 'failed')),
  error_message text,
  created_at timestamptz DEFAULT now()
);

-- Daily Generation Limits Table
CREATE TABLE IF NOT EXISTS public.daily_generation_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  generations_used integer DEFAULT 0,
  last_generation_at timestamptz,
  UNIQUE(user_id, date)
);

-- Blocked Prompts Table (admin managed)
CREATE TABLE IF NOT EXISTS public.blocked_prompts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pattern text NOT NULL,
  pattern_type text DEFAULT 'contains' CHECK (pattern_type IN ('exact', 'contains', 'regex')),
  category text NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.generated_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_generation_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocked_prompts ENABLE ROW LEVEL SECURITY;

-- RLS Policies for generated_images
CREATE POLICY "Users can view own generated images"
  ON public.generated_images
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view public shared images"
  ON public.generated_images
  FOR SELECT
  TO authenticated
  USING (is_private = false AND is_shared = true AND status = 'completed');

CREATE POLICY "Users can insert own generated images"
  ON public.generated_images
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own generated images"
  ON public.generated_images
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own generated images"
  ON public.generated_images
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for daily_generation_limits
CREATE POLICY "Users can view own limits"
  ON public.daily_generation_limits
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own limits"
  ON public.daily_generation_limits
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own limits"
  ON public.daily_generation_limits
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- No public policies for blocked_prompts (service role only)

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_generated_images_user_id ON public.generated_images(user_id);
CREATE INDEX IF NOT EXISTS idx_generated_images_feed ON public.generated_images(is_private, is_shared, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_generated_images_created ON public.generated_images(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_daily_limits_user_date ON public.daily_generation_limits(user_id, date);

-- Insert default blocked patterns for SafeZone compliance
INSERT INTO public.blocked_prompts (pattern, pattern_type, category) VALUES
  ('celebrity', 'contains', 'public_figure'),
  ('famous person', 'contains', 'public_figure'),
  ('politician', 'contains', 'public_figure'),
  ('president', 'contains', 'public_figure'),
  ('in the style of', 'contains', 'artist_imitation'),
  ('style of', 'contains', 'artist_imitation'),
  ('picasso', 'contains', 'artist_imitation'),
  ('van gogh', 'contains', 'artist_imitation'),
  ('monet', 'contains', 'artist_imitation'),
  ('banksy', 'contains', 'artist_imitation'),
  ('disney', 'contains', 'copyright'),
  ('marvel', 'contains', 'copyright'),
  ('pokemon', 'contains', 'copyright'),
  ('anime character', 'contains', 'copyright'),
  ('mickey mouse', 'contains', 'copyright'),
  ('superman', 'contains', 'copyright'),
  ('batman', 'contains', 'copyright'),
  ('nike', 'contains', 'brand'),
  ('coca cola', 'contains', 'brand'),
  ('apple logo', 'contains', 'brand'),
  ('gucci', 'contains', 'brand'),
  ('realistic human face', 'contains', 'photoreal_restriction'),
  ('photorealistic person', 'contains', 'photoreal_restriction'),
  ('real photo of person', 'contains', 'photoreal_restriction')
ON CONFLICT DO NOTHING;

-- Add plan-based daily limits configuration
COMMENT ON TABLE public.daily_generation_limits IS 'Tracks daily AI generation usage. Limits: free=5/day, personal=15/day, creator=50/day';
