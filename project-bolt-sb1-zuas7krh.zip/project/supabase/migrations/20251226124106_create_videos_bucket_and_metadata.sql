/*
  # Create Videos Storage Bucket and Metadata Table

  ## Overview
  Set up a dedicated storage bucket for video uploads with strict security policies
  and a metadata table to track video uploads.

  ## Storage Bucket: videos
  - Public access for viewing
  - Authenticated users can upload to their own folder
  - Max file size: 10MB
  - Allowed MIME types: video/mp4 only
  - Files stored with user ID prefix and timestamp suffix

  ## New Table: video_uploads
  - Tracks all video uploads
  - Stores video_url, duration, user_id, is_ai_generated
  - Links to posts for video posts

  ## Security
  - RLS enabled on video_uploads
  - Users can only access their own video metadata
  - Storage policies enforce user-owned paths
*/

-- Create videos storage bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'videos',
  'videos',
  true,
  10485760,
  ARRAY['video/mp4']
)
ON CONFLICT (id) DO UPDATE SET
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- Storage policies for videos bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Users can view all videos' 
    AND tablename = 'objects' 
    AND schemaname = 'storage'
  ) THEN
    CREATE POLICY "Users can view all videos"
      ON storage.objects FOR SELECT
      TO public
      USING (bucket_id = 'videos');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Users can upload own videos' 
    AND tablename = 'objects' 
    AND schemaname = 'storage'
  ) THEN
    CREATE POLICY "Users can upload own videos"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (
        bucket_id = 'videos'
        AND (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Users can delete own videos' 
    AND tablename = 'objects' 
    AND schemaname = 'storage'
  ) THEN
    CREATE POLICY "Users can delete own videos"
      ON storage.objects FOR DELETE
      TO authenticated
      USING (
        bucket_id = 'videos'
        AND (storage.foldername(name))[1] = auth.uid()::text
      );
  END IF;
END $$;

-- Create video_uploads metadata table
CREATE TABLE IF NOT EXISTS video_uploads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  video_url text NOT NULL,
  storage_path text NOT NULL,
  duration numeric NOT NULL CHECK (duration > 0),
  file_size integer NOT NULL CHECK (file_size > 0),
  mime_type text NOT NULL DEFAULT 'video/mp4',
  is_ai_generated boolean NOT NULL DEFAULT false,
  post_id uuid REFERENCES posts(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create indexes for video_uploads
CREATE INDEX IF NOT EXISTS idx_video_uploads_user_id ON video_uploads(user_id);
CREATE INDEX IF NOT EXISTS idx_video_uploads_post_id ON video_uploads(post_id);
CREATE INDEX IF NOT EXISTS idx_video_uploads_created_at ON video_uploads(created_at DESC);

-- Enable RLS on video_uploads
ALTER TABLE video_uploads ENABLE ROW LEVEL SECURITY;

-- RLS policies for video_uploads
CREATE POLICY "Users can view own video uploads"
  ON video_uploads FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own video uploads"
  ON video_uploads FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own video uploads"
  ON video_uploads FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
