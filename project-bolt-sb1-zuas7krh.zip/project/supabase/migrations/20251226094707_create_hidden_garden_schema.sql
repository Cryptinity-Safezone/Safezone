/*
  # Hidden Garden - Global Reflective Chat Experience

  ## Overview
  Creates the complete database schema for Hidden Garden, a synchronized global chat 
  room focused on emotional safety and reflection.

  ## Changes
  1. Add is_admin column to user_profiles
  2. Create all Hidden Garden tables with proper RLS

  ## New Tables
  - hidden_garden_settings - Global settings (background, pinned content)
  - hidden_garden_daily_questions - Rotating daily questions
  - hidden_garden_user_state - User's daily answer and status
  - hidden_garden_messages - Chat messages
  - hidden_garden_reactions - Message reactions
  - hidden_garden_music - Music tracks
*/

-- First, add is_admin column to user_profiles if it doesn't exist
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false;

-- Hidden Garden Settings (singleton table)
CREATE TABLE IF NOT EXISTS hidden_garden_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  background_image text DEFAULT '',
  background_motion boolean DEFAULT false,
  color_mood text DEFAULT 'calm' CHECK (color_mood IN ('dark', 'calm', 'green', 'night')),
  pinned_content text,
  pinned_type text CHECK (pinned_type IS NULL OR pinned_type IN ('quote', 'message', 'reflection', 'question', 'reminder')),
  pinned_at timestamptz,
  pinned_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  updated_at timestamptz DEFAULT now(),
  updated_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL
);

ALTER TABLE hidden_garden_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view garden settings" ON hidden_garden_settings;
CREATE POLICY "Anyone can view garden settings"
  ON hidden_garden_settings FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Admins can update garden settings" ON hidden_garden_settings;
CREATE POLICY "Admins can update garden settings"
  ON hidden_garden_settings FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

-- Insert default settings row
INSERT INTO hidden_garden_settings (id, background_image, color_mood)
VALUES ('00000000-0000-0000-0000-000000000001', '', 'calm')
ON CONFLICT (id) DO NOTHING;

-- Daily Questions
CREATE TABLE IF NOT EXISTS hidden_garden_daily_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  active_date date NOT NULL,
  created_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  is_auto_generated boolean DEFAULT false,
  UNIQUE(active_date)
);

ALTER TABLE hidden_garden_daily_questions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view daily questions" ON hidden_garden_daily_questions;
CREATE POLICY "Anyone can view daily questions"
  ON hidden_garden_daily_questions FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Admins can insert daily questions" ON hidden_garden_daily_questions;
CREATE POLICY "Admins can insert daily questions"
  ON hidden_garden_daily_questions FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

DROP POLICY IF EXISTS "Admins can update daily questions" ON hidden_garden_daily_questions;
CREATE POLICY "Admins can update daily questions"
  ON hidden_garden_daily_questions FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

CREATE INDEX IF NOT EXISTS idx_daily_questions_active_date ON hidden_garden_daily_questions(active_date);

-- Insert default questions for rotation
INSERT INTO hidden_garden_daily_questions (question, active_date, is_auto_generated)
VALUES 
  ('How are you feeling today?', CURRENT_DATE, true),
  ('Why are you here right now?', CURRENT_DATE + 1, true),
  ('What''s heavy on your mind?', CURRENT_DATE + 2, true),
  ('One word for your mood?', CURRENT_DATE + 3, true),
  ('What do you need most right now?', CURRENT_DATE + 4, true),
  ('What brought you peace today?', CURRENT_DATE + 5, true),
  ('What are you grateful for?', CURRENT_DATE + 6, true)
ON CONFLICT (active_date) DO NOTHING;

-- User State
CREATE TABLE IF NOT EXISTS hidden_garden_user_state (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  answer_date date NOT NULL DEFAULT CURRENT_DATE,
  answer text,
  question_id uuid REFERENCES hidden_garden_daily_questions(id) ON DELETE SET NULL,
  edit_count integer DEFAULT 0,
  is_muted boolean DEFAULT false,
  muted_until timestamptz,
  muted_reason text,
  last_message_at timestamptz,
  message_count_minute integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, answer_date)
);

ALTER TABLE hidden_garden_user_state ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view all user states" ON hidden_garden_user_state;
CREATE POLICY "Users can view all user states"
  ON hidden_garden_user_state FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Users can insert own state" ON hidden_garden_user_state;
CREATE POLICY "Users can insert own state"
  ON hidden_garden_user_state FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own state" ON hidden_garden_user_state;
CREATE POLICY "Users can update own state"
  ON hidden_garden_user_state FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can update any user state" ON hidden_garden_user_state;
CREATE POLICY "Admins can update any user state"
  ON hidden_garden_user_state FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

CREATE INDEX IF NOT EXISTS idx_user_state_user_date ON hidden_garden_user_state(user_id, answer_date);
CREATE INDEX IF NOT EXISTS idx_user_state_date ON hidden_garden_user_state(answer_date);

-- Messages
CREATE TABLE IF NOT EXISTS hidden_garden_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  is_reflection boolean DEFAULT false,
  is_removed boolean DEFAULT false,
  removed_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  removed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE hidden_garden_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view non-removed messages" ON hidden_garden_messages;
CREATE POLICY "Anyone can view non-removed messages"
  ON hidden_garden_messages FOR SELECT
  TO authenticated
  USING (is_removed = false OR auth.uid() = user_id OR EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.is_admin = true
  ));

DROP POLICY IF EXISTS "Users can insert own messages" ON hidden_garden_messages;
CREATE POLICY "Users can insert own messages"
  ON hidden_garden_messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can update any message" ON hidden_garden_messages;
CREATE POLICY "Admins can update any message"
  ON hidden_garden_messages FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

CREATE INDEX IF NOT EXISTS idx_garden_messages_created ON hidden_garden_messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_garden_messages_user ON hidden_garden_messages(user_id);

-- Reactions
CREATE TABLE IF NOT EXISTS hidden_garden_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES hidden_garden_messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  reaction text NOT NULL CHECK (reaction IN ('heart', 'leaf', 'star', 'peace', 'hug')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(message_id, user_id, reaction)
);

ALTER TABLE hidden_garden_reactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view reactions" ON hidden_garden_reactions;
CREATE POLICY "Anyone can view reactions"
  ON hidden_garden_reactions FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Users can insert own reactions" ON hidden_garden_reactions;
CREATE POLICY "Users can insert own reactions"
  ON hidden_garden_reactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can delete own reactions" ON hidden_garden_reactions;
CREATE POLICY "Users can delete own reactions"
  ON hidden_garden_reactions FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_reactions_message ON hidden_garden_reactions(message_id);

-- Music
CREATE TABLE IF NOT EXISTS hidden_garden_music (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  mood text DEFAULT 'calm',
  duration integer DEFAULT 0,
  audio_url text NOT NULL,
  is_ai_generated boolean DEFAULT false,
  is_active boolean DEFAULT false,
  loop_enabled boolean DEFAULT true,
  volume numeric(3,2) DEFAULT 0.3 CHECK (volume >= 0 AND volume <= 1),
  uploaded_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE hidden_garden_music ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view music" ON hidden_garden_music;
CREATE POLICY "Anyone can view music"
  ON hidden_garden_music FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Admins can insert music" ON hidden_garden_music;
CREATE POLICY "Admins can insert music"
  ON hidden_garden_music FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

DROP POLICY IF EXISTS "Admins can update music" ON hidden_garden_music;
CREATE POLICY "Admins can update music"
  ON hidden_garden_music FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

DROP POLICY IF EXISTS "Admins can delete music" ON hidden_garden_music;
CREATE POLICY "Admins can delete music"
  ON hidden_garden_music FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

CREATE INDEX IF NOT EXISTS idx_music_active ON hidden_garden_music(is_active) WHERE is_active = true;
