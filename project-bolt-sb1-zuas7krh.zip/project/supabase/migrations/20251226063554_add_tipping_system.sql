/*
  # Add Tipping System

  1. New Features
    - Atomic CTY transfer function for tipping between users
    - Tips table to track tip history
    - Only subscribers (personal, creator plans) can tip
    - Free users cannot tip

  2. Security
    - Atomic transfer prevents race conditions
    - Row-level locking ensures consistency
    - RLS policies protect tip records
    - Self-tipping is blocked

  3. Database Changes
    - New `tips` table for tracking tips
    - New `transfer_cty` function for atomic peer-to-peer transfers
    - Indexes for efficient queries
*/

-- Create tips table to track tip history
CREATE TABLE IF NOT EXISTS tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  post_id uuid REFERENCES posts(id) ON DELETE SET NULL,
  amount integer NOT NULL CHECK (amount > 0 AND amount <= 1000),
  message text CHECK (message IS NULL OR length(message) <= 200),
  created_at timestamptz DEFAULT now(),
  CONSTRAINT no_self_tipping CHECK (sender_id != recipient_id)
);

-- Enable RLS
ALTER TABLE tips ENABLE ROW LEVEL SECURITY;

-- Policies for tips table
CREATE POLICY "Users can view tips they sent or received"
  ON tips
  FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = recipient_id);

CREATE POLICY "Authenticated users can create tips"
  ON tips
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id AND sender_id != recipient_id);

-- Indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_tips_sender_id ON tips(sender_id);
CREATE INDEX IF NOT EXISTS idx_tips_recipient_id ON tips(recipient_id);
CREATE INDEX IF NOT EXISTS idx_tips_post_id ON tips(post_id) WHERE post_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tips_created_at ON tips(created_at DESC);

-- Atomic transfer function for tipping
CREATE OR REPLACE FUNCTION public.transfer_cty(
  p_sender_id uuid,
  p_recipient_id uuid,
  p_amount int,
  p_message text DEFAULT NULL,
  p_post_id uuid DEFAULT NULL
)
RETURNS TABLE(success boolean, sender_new_balance int, error_message text, tip_id uuid)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_sender_balance int;
  v_sender_plan text;
  v_new_tip_id uuid;
BEGIN
  -- Validate no self-tipping
  IF p_sender_id = p_recipient_id THEN
    RETURN QUERY SELECT false, 0, 'Cannot tip yourself'::text, NULL::uuid;
    RETURN;
  END IF;

  -- Validate amount
  IF p_amount <= 0 OR p_amount > 1000 THEN
    RETURN QUERY SELECT false, 0, 'Tip amount must be between 1 and 1000 CTY'::text, NULL::uuid;
    RETURN;
  END IF;

  -- Lock sender row and check balance + plan
  SELECT cty_balance, plan_type INTO v_sender_balance, v_sender_plan
  FROM user_profiles
  WHERE id = p_sender_id
  FOR UPDATE;

  IF v_sender_balance IS NULL THEN
    RETURN QUERY SELECT false, 0, 'Sender profile not found'::text, NULL::uuid;
    RETURN;
  END IF;

  -- Check if sender is allowed to tip (subscribers only)
  IF v_sender_plan NOT IN ('personal', 'creator') THEN
    RETURN QUERY SELECT false, v_sender_balance, 'Tipping requires a Personal or Creator subscription'::text, NULL::uuid;
    RETURN;
  END IF;

  -- Check sufficient balance
  IF v_sender_balance < p_amount THEN
    RETURN QUERY SELECT false, v_sender_balance, 'Insufficient CTY balance'::text, NULL::uuid;
    RETURN;
  END IF;

  -- Verify recipient exists
  IF NOT EXISTS (SELECT 1 FROM user_profiles WHERE id = p_recipient_id) THEN
    RETURN QUERY SELECT false, v_sender_balance, 'Recipient not found'::text, NULL::uuid;
    RETURN;
  END IF;

  -- Deduct from sender
  UPDATE user_profiles
  SET cty_balance = cty_balance - p_amount
  WHERE id = p_sender_id;

  -- Add to recipient
  UPDATE user_profiles
  SET cty_balance = cty_balance + p_amount
  WHERE id = p_recipient_id;

  -- Record tip
  INSERT INTO tips (sender_id, recipient_id, post_id, amount, message)
  VALUES (p_sender_id, p_recipient_id, p_post_id, p_amount, p_message)
  RETURNING id INTO v_new_tip_id;

  -- Record transactions for both parties
  INSERT INTO cty_transactions (user_id, amount, transaction_type, description, metadata)
  VALUES 
    (p_sender_id, -p_amount, 'spend', 'Sent tip', jsonb_build_object('tip_id', v_new_tip_id, 'recipient_id', p_recipient_id)),
    (p_recipient_id, p_amount, 'earn', 'Received tip', jsonb_build_object('tip_id', v_new_tip_id, 'sender_id', p_sender_id));

  RETURN QUERY SELECT true, (v_sender_balance - p_amount), NULL::text, v_new_tip_id;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION public.transfer_cty TO authenticated;
