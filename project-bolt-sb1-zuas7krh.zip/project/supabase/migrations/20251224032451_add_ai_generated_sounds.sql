/*
  # Add AI-Generated Sounds Table

  1. New Tables
    - `ai_generated_sounds`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `name` (text) - User-given name for the sound
      - `soundscape_type` (text) - Type of ambient soundscape
      - `parameters` (jsonb) - Generation parameters used
      - `duration_seconds` (integer) - Length of the generated sound
      - `is_private` (boolean) - Privacy setting, default true
      - `cty_cost` (integer) - CTY spent on generation
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `ai_generated_sounds` table
    - Users can only access their own generated sounds
    - Private sounds are only visible to the owner

  3. Notes
    - All generated sounds are private by default
    - Soundscape types are limited to non-vocal ambient categories
    - No artist-style imitation or genre labels tied to real musicians
*/

CREATE TABLE IF NOT EXISTS ai_generated_sounds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT 'Untitled Soundscape',
  soundscape_type text NOT NULL,
  parameters jsonb NOT NULL DEFAULT '{}',
  duration_seconds integer NOT NULL DEFAULT 30,
  is_private boolean NOT NULL DEFAULT true,
  cty_cost integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ai_generated_sounds_user_id ON ai_generated_sounds(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_generated_sounds_created_at ON ai_generated_sounds(created_at DESC);

ALTER TABLE ai_generated_sounds ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own generated sounds"
  ON ai_generated_sounds
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own generated sounds"
  ON ai_generated_sounds
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own generated sounds"
  ON ai_generated_sounds
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own generated sounds"
  ON ai_generated_sounds
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

COMMENT ON TABLE ai_generated_sounds IS 'Stores AI-generated ambient soundscapes. All sounds are private by default. Only non-vocal, non-imitative ambient sounds are allowed.';
COMMENT ON COLUMN ai_generated_sounds.soundscape_type IS 'Ambient soundscape category (e.g., nature, cosmic, underwater). No artist-style or genre labels tied to real musicians.';