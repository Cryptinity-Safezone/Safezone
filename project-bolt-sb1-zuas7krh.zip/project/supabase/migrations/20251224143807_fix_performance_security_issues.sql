/*
  # Fix Critical Performance and Security Issues

  ## Performance Optimizations
  
  ### 1. Missing Foreign Key Indexes
  Adding indexes on foreign key columns to improve join performance:
  - `admin_users.granted_by`
  - `content_similarity_flags.reviewed_by`, `similar_content_id`
  - `creator_notifications.flag_id`
  - `mentions.mentioner_id`
  - `muted_users.muted_user_id`
  - `notifications.actor_id`, `post_id`
  - `showcase_similarity_flags.reviewed_by`, `similar_to_id`
  - `similarity_flags.reviewed_by`
  
  ### 2. RLS Auth Function Optimization
  Replacing `auth.uid()` with `(select auth.uid())` in all RLS policies
  to prevent re-evaluation for each row (critical at scale)
  
  ## Security Fixes
  
  ### 3. Missing RLS Policies
  Adding policies for `blocked_prompts` table which has RLS enabled but no policies
  
  ### 4. Multiple Permissive Policy Consolidation
  Optimizing tables with multiple permissive policies for better performance
*/

-- =====================================================
-- PART 1: ADD MISSING FOREIGN KEY INDEXES
-- =====================================================

CREATE INDEX IF NOT EXISTS idx_admin_users_granted_by 
  ON admin_users(granted_by);

CREATE INDEX IF NOT EXISTS idx_content_similarity_flags_reviewed_by 
  ON content_similarity_flags(reviewed_by);

CREATE INDEX IF NOT EXISTS idx_content_similarity_flags_similar_content_id 
  ON content_similarity_flags(similar_content_id);

CREATE INDEX IF NOT EXISTS idx_creator_notifications_flag_id 
  ON creator_notifications(flag_id);

CREATE INDEX IF NOT EXISTS idx_mentions_mentioner_id 
  ON mentions(mentioner_id);

CREATE INDEX IF NOT EXISTS idx_muted_users_muted_user_id 
  ON muted_users(muted_user_id);

CREATE INDEX IF NOT EXISTS idx_notifications_actor_id 
  ON notifications(actor_id);

CREATE INDEX IF NOT EXISTS idx_notifications_post_id 
  ON notifications(post_id);

CREATE INDEX IF NOT EXISTS idx_showcase_similarity_flags_reviewed_by 
  ON showcase_similarity_flags(reviewed_by);

CREATE INDEX IF NOT EXISTS idx_showcase_similarity_flags_similar_to_id 
  ON showcase_similarity_flags(similar_to_id);

CREATE INDEX IF NOT EXISTS idx_similarity_flags_reviewed_by 
  ON similarity_flags(reviewed_by);

-- =====================================================
-- PART 2: FIX RLS POLICIES - AUTH FUNCTION OPTIMIZATION
-- =====================================================

-- ai_generated_sounds policies
DROP POLICY IF EXISTS "Users can create own generated sounds" ON ai_generated_sounds;
CREATE POLICY "Users can create own generated sounds"
  ON ai_generated_sounds FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can view own generated sounds" ON ai_generated_sounds;
CREATE POLICY "Users can view own generated sounds"
  ON ai_generated_sounds FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()) OR is_private = false);

DROP POLICY IF EXISTS "Users can update own generated sounds" ON ai_generated_sounds;
CREATE POLICY "Users can update own generated sounds"
  ON ai_generated_sounds FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own generated sounds" ON ai_generated_sounds;
CREATE POLICY "Users can delete own generated sounds"
  ON ai_generated_sounds FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- muted_users policies
DROP POLICY IF EXISTS "Users can view own muted list" ON muted_users;
CREATE POLICY "Users can view own muted list"
  ON muted_users FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can mute others" ON muted_users;
CREATE POLICY "Users can mute others"
  ON muted_users FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own mutes" ON muted_users;
CREATE POLICY "Users can update own mutes"
  ON muted_users FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can unmute others" ON muted_users;
CREATE POLICY "Users can unmute others"
  ON muted_users FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- similarity_flags policies
DROP POLICY IF EXISTS "Users can view own flags" ON similarity_flags;
CREATE POLICY "Users can view own flags"
  ON similarity_flags FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "System can update flags" ON similarity_flags;
CREATE POLICY "System can update flags"
  ON similarity_flags FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- ai_generated_content policies
DROP POLICY IF EXISTS "Users can view own AI content" ON ai_generated_content;
DROP POLICY IF EXISTS "Users can view AI content in feed" ON ai_generated_content;
CREATE POLICY "Users can view AI content"
  ON ai_generated_content FOR SELECT
  TO authenticated
  USING (
    user_id = (select auth.uid()) 
    OR is_watermarked = true
  );

DROP POLICY IF EXISTS "Users can insert own AI content" ON ai_generated_content;
CREATE POLICY "Users can insert own AI content"
  ON ai_generated_content FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own AI content" ON ai_generated_content;
CREATE POLICY "Users can update own AI content"
  ON ai_generated_content FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- content_fingerprints policies
DROP POLICY IF EXISTS "Users can view own fingerprints" ON content_fingerprints;
CREATE POLICY "Users can view own fingerprints"
  ON content_fingerprints FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "System can insert fingerprints" ON content_fingerprints;
CREATE POLICY "System can insert fingerprints"
  ON content_fingerprints FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

-- content_similarity_flags policies
DROP POLICY IF EXISTS "Users can view flags for own content" ON content_similarity_flags;
CREATE POLICY "Users can view flags for own content"
  ON content_similarity_flags FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ai_generated_content 
      WHERE id = content_similarity_flags.content_id 
      AND user_id = (select auth.uid())
    )
  );

-- content_unlocks policies
DROP POLICY IF EXISTS "Users can view own unlocks" ON content_unlocks;
DROP POLICY IF EXISTS "Creators can view who unlocked their content" ON content_unlocks;
CREATE POLICY "Users and creators can view unlocks"
  ON content_unlocks FOR SELECT
  TO authenticated
  USING (
    user_id = (select auth.uid())
    OR EXISTS (
      SELECT 1 FROM ai_generated_content 
      WHERE id = content_unlocks.content_id 
      AND user_id = (select auth.uid())
    )
  );

DROP POLICY IF EXISTS "Users can insert own unlocks" ON content_unlocks;
CREATE POLICY "Users can insert own unlocks"
  ON content_unlocks FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

-- post_hashtags policies
DROP POLICY IF EXISTS "Post authors can add hashtags" ON post_hashtags;
CREATE POLICY "Post authors can add hashtags"
  ON post_hashtags FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM posts 
      WHERE id = post_hashtags.post_id 
      AND user_id = (select auth.uid())
    )
  );

DROP POLICY IF EXISTS "Post authors can remove hashtags" ON post_hashtags;
CREATE POLICY "Post authors can remove hashtags"
  ON post_hashtags FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM posts 
      WHERE id = post_hashtags.post_id 
      AND user_id = (select auth.uid())
    )
  );

-- mentions policies
DROP POLICY IF EXISTS "Mentions are viewable by involved users" ON mentions;
CREATE POLICY "Mentions are viewable by involved users"
  ON mentions FOR SELECT
  TO authenticated
  USING (mentioned_user_id = (select auth.uid()) OR mentioner_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create mentions in their posts" ON mentions;
CREATE POLICY "Users can create mentions in their posts"
  ON mentions FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM posts 
      WHERE id = mentions.post_id 
      AND user_id = (select auth.uid())
    )
  );

DROP POLICY IF EXISTS "Post authors can delete mentions" ON mentions;
CREATE POLICY "Post authors can delete mentions"
  ON mentions FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM posts 
      WHERE id = mentions.post_id 
      AND user_id = (select auth.uid())
    )
  );

-- notifications policies
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Authenticated users can create notifications" ON notifications;
CREATE POLICY "Authenticated users can create notifications"
  ON notifications FOR INSERT
  TO authenticated
  WITH CHECK (actor_id = (select auth.uid()) OR (select auth.uid()) IS NOT NULL);

DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;
CREATE POLICY "Users can delete own notifications"
  ON notifications FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- creator_notifications policies
DROP POLICY IF EXISTS "Users can view own creator notifications" ON creator_notifications;
CREATE POLICY "Users can view own creator notifications"
  ON creator_notifications FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own creator notifications" ON creator_notifications;
CREATE POLICY "Users can update own creator notifications"
  ON creator_notifications FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- generated_images policies
DROP POLICY IF EXISTS "Users can view own generated images" ON generated_images;
DROP POLICY IF EXISTS "Users can view public shared images" ON generated_images;
CREATE POLICY "Users can view generated images"
  ON generated_images FOR SELECT
  TO authenticated
  USING (
    user_id = (select auth.uid()) 
    OR (is_private = false AND is_shared = true)
  );

DROP POLICY IF EXISTS "Users can insert own generated images" ON generated_images;
CREATE POLICY "Users can insert own generated images"
  ON generated_images FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own generated images" ON generated_images;
CREATE POLICY "Users can update own generated images"
  ON generated_images FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own generated images" ON generated_images;
CREATE POLICY "Users can delete own generated images"
  ON generated_images FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- daily_generation_limits policies
DROP POLICY IF EXISTS "Users can view own limits" ON daily_generation_limits;
CREATE POLICY "Users can view own limits"
  ON daily_generation_limits FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own limits" ON daily_generation_limits;
CREATE POLICY "Users can insert own limits"
  ON daily_generation_limits FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own limits" ON daily_generation_limits;
CREATE POLICY "Users can update own limits"
  ON daily_generation_limits FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- motion_generations policies
DROP POLICY IF EXISTS "Users can view their own motion generations" ON motion_generations;
CREATE POLICY "Users can view their own motion generations"
  ON motion_generations FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()) OR is_private = false);

DROP POLICY IF EXISTS "Users can insert their own motion generations" ON motion_generations;
CREATE POLICY "Users can insert their own motion generations"
  ON motion_generations FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update their own motion generations" ON motion_generations;
CREATE POLICY "Users can update their own motion generations"
  ON motion_generations FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete their own motion generations" ON motion_generations;
CREATE POLICY "Users can delete their own motion generations"
  ON motion_generations FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- showcase_similarity_flags policies
DROP POLICY IF EXISTS "Admins can manage similarity flags" ON showcase_similarity_flags;
CREATE POLICY "Admins can manage similarity flags"
  ON showcase_similarity_flags FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE user_id = (select auth.uid())
    )
  );

-- admin_users policies
DROP POLICY IF EXISTS "Admins can view admin users" ON admin_users;
DROP POLICY IF EXISTS "Super admins can manage admin users" ON admin_users;
CREATE POLICY "Admin users access control"
  ON admin_users FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users a 
      WHERE a.user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users a 
      WHERE a.user_id = (select auth.uid()) 
      AND a.role = 'super_admin'
    )
  );

-- =====================================================
-- PART 3: ADD MISSING POLICIES FOR blocked_prompts
-- =====================================================

CREATE POLICY "Admins can view blocked prompts"
  ON blocked_prompts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE user_id = (select auth.uid())
    )
  );

CREATE POLICY "Admins can manage blocked prompts"
  ON blocked_prompts FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE user_id = (select auth.uid()) 
      AND role IN ('super_admin', 'moderator')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE user_id = (select auth.uid()) 
      AND role IN ('super_admin', 'moderator')
    )
  );