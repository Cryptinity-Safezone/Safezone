/*
  # Fix Security and Performance Issues

  ## Overview
  This migration addresses security and performance issues identified by Supabase:
  - Adds missing indexes for foreign keys
  - Optimizes RLS policies to use subqueries for auth functions
  - Removes duplicate/overlapping policies
  - Fixes function search paths for security

  ## Changes

  ### 1. Add Missing Indexes
  - Add index on user_subscriptions.user_id for better FK performance

  ### 2. Optimize RLS Policies
  All policies updated to use `(select auth.uid())` instead of `auth.uid()` to avoid
  re-evaluation for each row, improving query performance at scale.

  ### 3. Remove Duplicate Policies
  - Remove overlapping SELECT policies on showcase_items
  - Remove overlapping SELECT policies on warehouse_items

  ### 4. Fix Function Search Paths
  - Set immutable search_path on trigger functions for security
*/

-- ================================================
-- 1. ADD MISSING INDEXES
-- ================================================

-- Add index on user_subscriptions.user_id for FK performance
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_user_id ON user_subscriptions(user_id);

-- ================================================
-- 2. DROP EXISTING POLICIES (to recreate with optimization)
-- ================================================

-- user_profiles policies
DROP POLICY IF EXISTS "Users can insert own profile" ON user_profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON user_profiles;

-- posts policies
DROP POLICY IF EXISTS "Users can create own posts" ON posts;
DROP POLICY IF EXISTS "Users can delete own posts" ON posts;
DROP POLICY IF EXISTS "Users can update own posts" ON posts;

-- cty_transactions policies
DROP POLICY IF EXISTS "Users can create own transactions" ON cty_transactions;
DROP POLICY IF EXISTS "Users can view own transactions" ON cty_transactions;

-- user_subscriptions policies
DROP POLICY IF EXISTS "Users can view own subscriptions" ON user_subscriptions;

-- showcase_items policies
DROP POLICY IF EXISTS "Anyone can view showcase items" ON showcase_items;
DROP POLICY IF EXISTS "Users can manage own showcase items" ON showcase_items;

-- warehouse_items policies
DROP POLICY IF EXISTS "Users can manage own warehouse items" ON warehouse_items;
DROP POLICY IF EXISTS "Users can view own warehouse items" ON warehouse_items;

-- follows policies
DROP POLICY IF EXISTS "Users can create own follows" ON follows;
DROP POLICY IF EXISTS "Users can delete own follows" ON follows;

-- post_likes policies
DROP POLICY IF EXISTS "Users can create own likes" ON post_likes;
DROP POLICY IF EXISTS "Users can delete own likes" ON post_likes;

-- ================================================
-- 3. CREATE OPTIMIZED POLICIES
-- ================================================

-- user_profiles: Optimized policies
CREATE POLICY "Users can insert own profile"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = id)
  WITH CHECK ((select auth.uid()) = id);

-- posts: Optimized policies
CREATE POLICY "Users can create own posts"
  ON posts FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own posts"
  ON posts FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own posts"
  ON posts FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- cty_transactions: Optimized policies
CREATE POLICY "Users can view own transactions"
  ON cty_transactions FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can create own transactions"
  ON cty_transactions FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

-- user_subscriptions: Optimized policies
CREATE POLICY "Users can view own subscriptions"
  ON user_subscriptions FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- showcase_items: Single combined policy (removes duplication)
CREATE POLICY "Users can view and manage showcase items"
  ON showcase_items FOR ALL
  TO authenticated
  USING (
    -- Users can view all showcase items OR manage their own
    true
  )
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can view all showcase items"
  ON showcase_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage own showcase items"
  ON showcase_items FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own showcase items"
  ON showcase_items FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own showcase items"
  ON showcase_items FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- warehouse_items: Single policy for viewing own items
CREATE POLICY "Users can view own warehouse items"
  ON warehouse_items FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can create own warehouse items"
  ON warehouse_items FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own warehouse items"
  ON warehouse_items FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own warehouse items"
  ON warehouse_items FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- follows: Optimized policies
CREATE POLICY "Users can create own follows"
  ON follows FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = follower_id);

CREATE POLICY "Users can delete own follows"
  ON follows FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = follower_id);

-- post_likes: Optimized policies
CREATE POLICY "Users can create own likes"
  ON post_likes FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own likes"
  ON post_likes FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- ================================================
-- 4. FIX FUNCTION SEARCH PATHS
-- ================================================

-- Recreate update_updated_at_column function with secure search_path
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Recreate handle_new_user function with secure search_path
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
BEGIN
  INSERT INTO public.user_profiles (
    id,
    username,
    handle,
    cty_balance,
    plan_type
  )
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'handle', '@' || split_part(NEW.email, '@', 1)),
    100,
    'free'
  );
  RETURN NEW;
END;
$$;
