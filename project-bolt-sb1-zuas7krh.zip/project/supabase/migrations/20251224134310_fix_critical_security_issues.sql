/*
  # Critical Security Fixes

  1. CTY Race Condition Fix
    - Create atomic balance update functions using database-level locking
    - Prevent race conditions with FOR UPDATE SKIP LOCKED

  2. Admin Detection via Database
    - Create admin_users table
    - Move admin detection from hardcoded emails to database
    - Add RLS policies for admin table

  3. Important Notes
    - All balance operations now use atomic functions
    - Admin status is database-driven, not client-driven
    - These fixes address critical security vulnerabilities
*/

-- 1. CTY RACE CONDITION FIX: Atomic balance operations

-- Function to atomically spend CTY (with row locking)
CREATE OR REPLACE FUNCTION public.spend_cty(
  p_user_id uuid,
  p_amount int,
  p_description text,
  p_metadata jsonb DEFAULT '{}'::jsonb
)
RETURNS TABLE(success boolean, new_balance int, error_message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current_balance int;
BEGIN
  -- Lock the row for update to prevent race conditions
  SELECT cty_balance INTO v_current_balance
  FROM user_profiles
  WHERE id = p_user_id
  FOR UPDATE;

  IF v_current_balance IS NULL THEN
    RETURN QUERY SELECT false, 0, 'Profile not found'::text;
    RETURN;
  END IF;

  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, v_current_balance, 'Insufficient balance'::text;
    RETURN;
  END IF;

  -- Atomic update
  UPDATE user_profiles
  SET cty_balance = cty_balance - p_amount
  WHERE id = p_user_id;

  -- Record transaction
  INSERT INTO cty_transactions (user_id, amount, transaction_type, description, metadata)
  VALUES (p_user_id, -p_amount, 'spend', p_description, p_metadata);

  RETURN QUERY SELECT true, (v_current_balance - p_amount), NULL::text;
END;
$$;

-- Function to atomically earn/add CTY (with row locking)
CREATE OR REPLACE FUNCTION public.add_cty(
  p_user_id uuid,
  p_amount int,
  p_description text,
  p_transaction_type text DEFAULT 'earn',
  p_metadata jsonb DEFAULT '{}'::jsonb
)
RETURNS TABLE(success boolean, new_balance int, error_message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_balance int;
BEGIN
  -- Validate amount
  IF p_amount <= 0 THEN
    RETURN QUERY SELECT false, 0, 'Amount must be positive'::text;
    RETURN;
  END IF;

  -- Lock the row for update
  UPDATE user_profiles
  SET cty_balance = cty_balance + p_amount
  WHERE id = p_user_id
  RETURNING cty_balance INTO v_new_balance;

  IF v_new_balance IS NULL THEN
    RETURN QUERY SELECT false, 0, 'Profile not found'::text;
    RETURN;
  END IF;

  -- Record transaction
  INSERT INTO cty_transactions (user_id, amount, transaction_type, description, metadata)
  VALUES (p_user_id, p_amount, p_transaction_type, p_description, p_metadata);

  RETURN QUERY SELECT true, v_new_balance, NULL::text;
END;
$$;

-- 2. ADMIN DETECTION VIA DATABASE

-- Create admin_users table if not exists
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'admin' CHECK (role IN ('admin', 'super_admin', 'moderator')),
  granted_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  granted_at timestamptz DEFAULT now(),
  is_active boolean DEFAULT true,
  notes text
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Policies: Only admins can view admin list
CREATE POLICY "Admins can view admin users"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.user_id = auth.uid()
      AND au.is_active = true
    )
  );

-- Only super_admins can manage admin users
CREATE POLICY "Super admins can manage admin users"
  ON admin_users
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.user_id = auth.uid()
      AND au.is_active = true
      AND au.role = 'super_admin'
    )
  );

-- Create index for fast admin lookups
CREATE INDEX IF NOT EXISTS idx_admin_users_user_id ON admin_users(user_id) WHERE is_active = true;

-- Function to check if user is admin (server-side)
CREATE OR REPLACE FUNCTION public.is_admin(p_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM admin_users
    WHERE user_id = p_user_id
    AND is_active = true
  );
$$;

-- Function to check admin role
CREATE OR REPLACE FUNCTION public.get_admin_role(p_user_id uuid)
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT role FROM admin_users
  WHERE user_id = p_user_id
  AND is_active = true;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION public.spend_cty TO authenticated;
GRANT EXECUTE ON FUNCTION public.add_cty TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_admin_role TO authenticated, service_role;
