/*
  # Create Storage Buckets for Cryptinity

  ## Overview
  Set up storage buckets for user-generated content with appropriate security policies.

  ## Storage Buckets

  ### 1. avatars
  User profile avatars
  - Public access for reading
  - Authenticated users can upload their own
  - Max file size handled by client

  ### 2. covers
  User profile cover photos
  - Public access for reading
  - Authenticated users can upload their own

  ### 3. posts
  Post images and media
  - Public access for reading
  - Authenticated users can upload

  ### 4. warehouse
  Private user storage for creations
  - Private bucket
  - Users can only access their own files

  ### 5. showcase
  Public showcase portfolio items
  - Public access for reading
  - Users can upload their own

  ## Security
  - All buckets have appropriate RLS-style policies
  - File paths include user ID to prevent conflicts
  - Users can only manage their own files
*/

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
  ('avatars', 'avatars', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']),
  ('covers', 'covers', true, 10485760, ARRAY['image/jpeg', 'image/png', 'image/webp']),
  ('posts', 'posts', true, 10485760, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']),
  ('warehouse', 'warehouse', false, 52428800, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'audio/mpeg', 'audio/wav', 'audio/ogg', 'video/mp4', 'video/webm']),
  ('showcase', 'showcase', true, 20971520, ARRAY['image/jpeg', 'image/png', 'image/webp', 'audio/mpeg', 'audio/wav', 'video/mp4', 'video/webm'])
ON CONFLICT (id) DO NOTHING;

-- Storage policies for avatars bucket
CREATE POLICY "Users can view all avatars"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'avatars');

CREATE POLICY "Users can upload own avatar"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'avatars' 
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can update own avatar"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = auth.uid()::text
  )
  WITH CHECK (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete own avatar"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

-- Storage policies for covers bucket
CREATE POLICY "Users can view all covers"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'covers');

CREATE POLICY "Users can upload own cover"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'covers'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can update own cover"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'covers'
    AND (storage.foldername(name))[1] = auth.uid()::text
  )
  WITH CHECK (
    bucket_id = 'covers'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete own cover"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'covers'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

-- Storage policies for posts bucket
CREATE POLICY "Users can view all post images"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'posts');

CREATE POLICY "Users can upload post images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'posts'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete own post images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'posts'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

-- Storage policies for warehouse bucket (private)
CREATE POLICY "Users can view own warehouse files"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'warehouse'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can upload to own warehouse"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'warehouse'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete from own warehouse"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'warehouse'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

-- Storage policies for showcase bucket
CREATE POLICY "Users can view all showcase items"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'showcase');

CREATE POLICY "Users can upload to own showcase"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'showcase'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete from own showcase"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'showcase'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );