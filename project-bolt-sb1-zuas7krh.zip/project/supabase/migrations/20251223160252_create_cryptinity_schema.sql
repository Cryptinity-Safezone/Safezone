/*
  # Cryptinity Platform Database Schema

  ## Overview
  Complete database schema for the Cryptinity SafeZone social platform with CTY⚡ economy,
  authentication, storage, and user profiles following non-manipulative design principles.

  ## New Tables

  ### 1. user_profiles
  Extended user profile information linked to auth.users
  - `id` (uuid, primary key, references auth.users)
  - `username` (text, unique, required)
  - `handle` (text, unique, required)
  - `avatar_url` (text)
  - `cover_url` (text)
  - `plan_type` (text, default 'free')
  - `cty_balance` (integer, default 100)
  - `is_verified` (boolean, default false)
  - `is_restricted` (boolean, default false)
  - `bio` (text)
  - `interests` (text array)
  - `background_music_title` (text)
  - `background_music_artist` (text)
  - `background_music_url` (text)
  - `followers_count` (integer, default 0)
  - `following_count` (integer, default 0)
  - `creations_count` (integer, default 0)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. posts
  User-generated content and posts
  - `id` (uuid, primary key)
  - `user_id` (uuid, references user_profiles)
  - `content` (text, required)
  - `image_url` (text)
  - `likes_count` (integer, default 0)
  - `comments_count` (integer, default 0)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 3. cty_transactions
  All CTY⚡ currency transactions for transparency and tracking
  - `id` (uuid, primary key)
  - `user_id` (uuid, references user_profiles)
  - `amount` (integer, required)
  - `transaction_type` (text, required) - 'earn', 'spend', 'purchase', 'monthly_allowance'
  - `description` (text, required)
  - `metadata` (jsonb)
  - `created_at` (timestamptz)

  ### 4. user_subscriptions
  User subscription plan tracking
  - `id` (uuid, primary key)
  - `user_id` (uuid, references user_profiles)
  - `plan_type` (text, required) - 'free', 'personal', 'creator'
  - `status` (text, default 'active') - 'active', 'cancelled', 'expired'
  - `started_at` (timestamptz)
  - `expires_at` (timestamptz)
  - `created_at` (timestamptz)

  ### 5. showcase_items
  User showcase portfolio items
  - `id` (uuid, primary key)
  - `user_id` (uuid, references user_profiles)
  - `title` (text, required)
  - `description` (text)
  - `media_url` (text, required)
  - `media_type` (text, required) - 'image', 'sound', 'video'
  - `order_index` (integer, default 0)
  - `created_at` (timestamptz)

  ### 6. warehouse_items
  Private user storage for creations
  - `id` (uuid, primary key)
  - `user_id` (uuid, references user_profiles)
  - `name` (text, required)
  - `file_url` (text, required)
  - `file_type` (text, required)
  - `file_size` (bigint, required)
  - `metadata` (jsonb)
  - `created_at` (timestamptz)

  ### 7. follows
  User follow relationships
  - `id` (uuid, primary key)
  - `follower_id` (uuid, references user_profiles)
  - `following_id` (uuid, references user_profiles)
  - `created_at` (timestamptz)

  ### 8. post_likes
  Track which users liked which posts
  - `id` (uuid, primary key)
  - `user_id` (uuid, references user_profiles)
  - `post_id` (uuid, references posts)
  - `created_at` (timestamptz)

  ## Security

  ### Row Level Security (RLS)
  All tables have RLS enabled with appropriate policies:
  - Users can read their own data and public data
  - Users can only modify their own data
  - CTY transactions are read-only after creation
  - Posts are publicly readable but only editable by authors

  ## Important Notes
  - CTY⚡ balance limits are enforced via Edge Functions
  - Monthly allowances are distributed via scheduled Edge Functions
  - All monetary transactions are logged for transparency
  - No user data is deleted, only soft-deleted via is_restricted flag
*/

-- Create user_profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  handle text UNIQUE NOT NULL,
  avatar_url text,
  cover_url text,
  plan_type text DEFAULT 'free' CHECK (plan_type IN ('free', 'personal', 'creator')),
  cty_balance integer DEFAULT 100 CHECK (cty_balance >= 0),
  is_verified boolean DEFAULT false,
  is_restricted boolean DEFAULT false,
  bio text,
  interests text[] DEFAULT '{}',
  background_music_title text,
  background_music_artist text,
  background_music_url text,
  followers_count integer DEFAULT 0,
  following_count integer DEFAULT 0,
  creations_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create posts table
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  image_url text,
  likes_count integer DEFAULT 0,
  comments_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create cty_transactions table
CREATE TABLE IF NOT EXISTS cty_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  transaction_type text NOT NULL CHECK (transaction_type IN ('earn', 'spend', 'purchase', 'monthly_allowance')),
  description text NOT NULL,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create user_subscriptions table
CREATE TABLE IF NOT EXISTS user_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  plan_type text NOT NULL CHECK (plan_type IN ('free', 'personal', 'creator')),
  status text DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired')),
  started_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create showcase_items table
CREATE TABLE IF NOT EXISTS showcase_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  media_url text NOT NULL,
  media_type text NOT NULL CHECK (media_type IN ('image', 'sound', 'video')),
  order_index integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create warehouse_items table
CREATE TABLE IF NOT EXISTS warehouse_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  file_url text NOT NULL,
  file_type text NOT NULL,
  file_size bigint NOT NULL,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create follows table
CREATE TABLE IF NOT EXISTS follows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  following_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

-- Create post_likes table
CREATE TABLE IF NOT EXISTS post_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, post_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_posts_user_id ON posts(user_id);
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_cty_transactions_user_id ON cty_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_cty_transactions_created_at ON cty_transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_follows_follower ON follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following ON follows(following_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_user ON post_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_post ON post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_warehouse_items_user ON warehouse_items(user_id);
CREATE INDEX IF NOT EXISTS idx_showcase_items_user ON showcase_items(user_id);

-- Enable Row Level Security
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE cty_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE showcase_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE warehouse_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_profiles
CREATE POLICY "Users can view all public profiles"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- RLS Policies for posts
CREATE POLICY "Anyone can view posts"
  ON posts FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create own posts"
  ON posts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own posts"
  ON posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own posts"
  ON posts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for cty_transactions
CREATE POLICY "Users can view own transactions"
  ON cty_transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own transactions"
  ON cty_transactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for user_subscriptions
CREATE POLICY "Users can view own subscriptions"
  ON user_subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for showcase_items
CREATE POLICY "Anyone can view showcase items"
  ON showcase_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage own showcase items"
  ON showcase_items FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for warehouse_items
CREATE POLICY "Users can view own warehouse items"
  ON warehouse_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own warehouse items"
  ON warehouse_items FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for follows
CREATE POLICY "Anyone can view follows"
  ON follows FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create own follows"
  ON follows FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "Users can delete own follows"
  ON follows FOR DELETE
  TO authenticated
  USING (auth.uid() = follower_id);

-- RLS Policies for post_likes
CREATE POLICY "Anyone can view post likes"
  ON post_likes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create own likes"
  ON post_likes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own likes"
  ON post_likes FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at triggers
CREATE TRIGGER update_user_profiles_updated_at
  BEFORE UPDATE ON user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_posts_updated_at
  BEFORE UPDATE ON posts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_profiles (id, username, handle)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'user_' || substring(NEW.id::text, 1, 8)),
    COALESCE(NEW.raw_user_meta_data->>'handle', '@user_' || substring(NEW.id::text, 1, 8))
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();