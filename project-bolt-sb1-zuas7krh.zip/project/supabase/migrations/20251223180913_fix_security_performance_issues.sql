/*
  # Fix Security and Performance Issues

  ## Overview
  This migration addresses critical security and performance issues identified by Supabase.

  ## Changes

  ### 1. Add Missing Foreign Key Index
  - **Issue**: Foreign key `energy_pack_purchases_pack_id_fkey` lacks covering index
  - **Fix**: Add index on `energy_pack_purchases.pack_id` for optimal query performance
  - **Impact**: Improves query performance for energy pack purchase lookups

  ### 2. Optimize RLS Policies for Performance
  - **Issue**: Multiple tables have RLS policies that re-evaluate `auth.uid()` for each row
  - **Fix**: Replace `auth.uid()` with `(select auth.uid())` to evaluate once per query
  - **Tables affected**: 
    - `user_blocks` (3 policies)
    - `hidden_posts` (3 policies)
    - `post_reports` (2 policies)
  - **Impact**: Significantly improves query performance at scale by reducing function calls

  ### 3. Remove Duplicate RLS Policies
  - **Issue**: `showcase_items` has overlapping permissive policies causing redundancy
  - **Fix**: Remove duplicate policies, keeping only necessary granular policies
  - **Impact**: Simplifies policy evaluation and prevents potential conflicts

  ## Performance Benefits
  - Faster foreign key lookups on energy pack purchases
  - Reduced CPU usage for RLS policy evaluation
  - Cleaner security model without policy duplication

  ## Security Notes
  - All changes maintain existing security guarantees
  - No data access patterns are altered
  - Users retain same access permissions
*/

-- ================================================
-- 1. ADD MISSING FOREIGN KEY INDEX
-- ================================================

-- Add index on energy_pack_purchases.pack_id to support foreign key lookups
CREATE INDEX IF NOT EXISTS idx_energy_pack_purchases_pack_id 
  ON energy_pack_purchases(pack_id);

-- ================================================
-- 2. OPTIMIZE USER_BLOCKS RLS POLICIES
-- ================================================

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view their own blocks" ON user_blocks;
DROP POLICY IF EXISTS "Users can create blocks" ON user_blocks;
DROP POLICY IF EXISTS "Users can delete their own blocks" ON user_blocks;

-- Recreate with optimized auth function calls
CREATE POLICY "Users can view their own blocks"
  ON user_blocks FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = blocker_id);

CREATE POLICY "Users can create blocks"
  ON user_blocks FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = blocker_id);

CREATE POLICY "Users can delete their own blocks"
  ON user_blocks FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = blocker_id);

-- ================================================
-- 3. OPTIMIZE HIDDEN_POSTS RLS POLICIES
-- ================================================

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view their own hidden posts" ON hidden_posts;
DROP POLICY IF EXISTS "Users can hide posts" ON hidden_posts;
DROP POLICY IF EXISTS "Users can unhide posts" ON hidden_posts;

-- Recreate with optimized auth function calls
CREATE POLICY "Users can view their own hidden posts"
  ON hidden_posts FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can hide posts"
  ON hidden_posts FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can unhide posts"
  ON hidden_posts FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- ================================================
-- 4. OPTIMIZE POST_REPORTS RLS POLICIES
-- ================================================

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view their own reports" ON post_reports;
DROP POLICY IF EXISTS "Users can create reports" ON post_reports;

-- Recreate with optimized auth function calls
CREATE POLICY "Users can view their own reports"
  ON post_reports FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = reporter_id);

CREATE POLICY "Users can create reports"
  ON post_reports FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = reporter_id);

-- ================================================
-- 5. REMOVE DUPLICATE SHOWCASE_ITEMS POLICIES
-- ================================================

-- Drop the "FOR ALL" policy that duplicates other policies
DROP POLICY IF EXISTS "Users can view and manage showcase items" ON showcase_items;

-- Keep only the specific granular policies which already exist:
-- - "Users can view all showcase items" (SELECT)
-- - "Users can manage own showcase items" (INSERT)
-- - "Users can update own showcase items" (UPDATE)
-- - "Users can delete own showcase items" (DELETE)
