/*
  # Add Messaging System and Default Profile Images

  ## Overview
  This migration adds a complete private messaging system for 1-to-1 communication
  between users, along with default avatar and cover images for new user profiles.

  ## New Tables

  ### 1. conversations
  Tracks 1-to-1 conversations between users
  - `id` (uuid, primary key)
  - `participant_one` (uuid, references user_profiles) - first participant
  - `participant_two` (uuid, references user_profiles) - second participant
  - `last_message_at` (timestamptz) - timestamp of last message
  - `created_at` (timestamptz)

  ### 2. messages
  Stores individual messages within conversations
  - `id` (uuid, primary key)
  - `conversation_id` (uuid, references conversations)
  - `sender_id` (uuid, references user_profiles)
  - `content` (text, required) - message text content
  - `created_at` (timestamptz)

  ### 3. message_requests
  Handles message requests between non-mutual-followers
  - `id` (uuid, primary key)
  - `sender_id` (uuid, references user_profiles)
  - `recipient_id` (uuid, references user_profiles)
  - `status` (text) - 'pending', 'accepted', 'declined'
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 4. message_reports
  For reporting inappropriate messages
  - `id` (uuid, primary key)
  - `reporter_id` (uuid, references user_profiles)
  - `message_id` (uuid, references messages)
  - `conversation_id` (uuid, references conversations)
  - `reason` (text)
  - `details` (text, optional)
  - `status` (text, default 'pending')
  - `created_at` (timestamptz)

  ## Changes to user_profiles
  - Updates trigger to set default avatar_url and cover_url on account creation

  ## Security
  - RLS enabled on all tables
  - Users can only access their own conversations
  - Blocked users cannot send messages
  - Message requests required for non-mutual-followers
*/

-- Create conversations table
CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  participant_one uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  participant_two uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  last_message_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(participant_one, participant_two),
  CHECK (participant_one != participant_two)
);

CREATE INDEX IF NOT EXISTS idx_conversations_participant_one ON conversations(participant_one);
CREATE INDEX IF NOT EXISTS idx_conversations_participant_two ON conversations(participant_two);
CREATE INDEX IF NOT EXISTS idx_conversations_last_message ON conversations(last_message_at DESC);

ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

-- Conversations policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'conversations' AND policyname = 'Users can view own conversations'
  ) THEN
    CREATE POLICY "Users can view own conversations"
      ON conversations FOR SELECT
      TO authenticated
      USING (auth.uid() = participant_one OR auth.uid() = participant_two);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'conversations' AND policyname = 'Users can create conversations'
  ) THEN
    CREATE POLICY "Users can create conversations"
      ON conversations FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = participant_one OR auth.uid() = participant_two);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'conversations' AND policyname = 'Users can update own conversations'
  ) THEN
    CREATE POLICY "Users can update own conversations"
      ON conversations FOR UPDATE
      TO authenticated
      USING (auth.uid() = participant_one OR auth.uid() = participant_two)
      WITH CHECK (auth.uid() = participant_one OR auth.uid() = participant_two);
  END IF;
END $$;

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Messages policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'messages' AND policyname = 'Users can view messages in own conversations'
  ) THEN
    CREATE POLICY "Users can view messages in own conversations"
      ON messages FOR SELECT
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM conversations c
          WHERE c.id = conversation_id
          AND (c.participant_one = auth.uid() OR c.participant_two = auth.uid())
        )
      );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'messages' AND policyname = 'Users can send messages to own conversations'
  ) THEN
    CREATE POLICY "Users can send messages to own conversations"
      ON messages FOR INSERT
      TO authenticated
      WITH CHECK (
        auth.uid() = sender_id
        AND EXISTS (
          SELECT 1 FROM conversations c
          WHERE c.id = conversation_id
          AND (c.participant_one = auth.uid() OR c.participant_two = auth.uid())
        )
      );
  END IF;
END $$;

-- Create message_requests table
CREATE TABLE IF NOT EXISTS message_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  status text DEFAULT 'pending' NOT NULL CHECK (status IN ('pending', 'accepted', 'declined')),
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(sender_id, recipient_id),
  CHECK (sender_id != recipient_id)
);

CREATE INDEX IF NOT EXISTS idx_message_requests_sender ON message_requests(sender_id);
CREATE INDEX IF NOT EXISTS idx_message_requests_recipient ON message_requests(recipient_id);
CREATE INDEX IF NOT EXISTS idx_message_requests_status ON message_requests(status);

ALTER TABLE message_requests ENABLE ROW LEVEL SECURITY;

-- Message requests policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'message_requests' AND policyname = 'Users can view own message requests'
  ) THEN
    CREATE POLICY "Users can view own message requests"
      ON message_requests FOR SELECT
      TO authenticated
      USING (auth.uid() = sender_id OR auth.uid() = recipient_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'message_requests' AND policyname = 'Users can send message requests'
  ) THEN
    CREATE POLICY "Users can send message requests"
      ON message_requests FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = sender_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'message_requests' AND policyname = 'Users can update own received requests'
  ) THEN
    CREATE POLICY "Users can update own received requests"
      ON message_requests FOR UPDATE
      TO authenticated
      USING (auth.uid() = recipient_id)
      WITH CHECK (auth.uid() = recipient_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'message_requests' AND policyname = 'Users can delete own sent requests'
  ) THEN
    CREATE POLICY "Users can delete own sent requests"
      ON message_requests FOR DELETE
      TO authenticated
      USING (auth.uid() = sender_id);
  END IF;
END $$;

-- Create message_reports table
CREATE TABLE IF NOT EXISTS message_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  message_id uuid REFERENCES messages(id) ON DELETE SET NULL,
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  reason text NOT NULL CHECK (reason IN ('spam', 'harassment', 'inappropriate', 'threats', 'other')),
  details text,
  status text DEFAULT 'pending' NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_message_reports_reporter ON message_reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_message_reports_conversation ON message_reports(conversation_id);
CREATE INDEX IF NOT EXISTS idx_message_reports_status ON message_reports(status);

ALTER TABLE message_reports ENABLE ROW LEVEL SECURITY;

-- Message reports policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'message_reports' AND policyname = 'Users can view own message reports'
  ) THEN
    CREATE POLICY "Users can view own message reports"
      ON message_reports FOR SELECT
      TO authenticated
      USING (auth.uid() = reporter_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'message_reports' AND policyname = 'Users can create message reports'
  ) THEN
    CREATE POLICY "Users can create message reports"
      ON message_reports FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = reporter_id);
  END IF;
END $$;

-- Update handle_new_user function to set default avatar and cover
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  default_avatar text := 'data:image/svg+xml,' || uri_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:#0d9488"/><stop offset="100%" style="stop-color:#10b981"/></linearGradient></defs><rect width="100" height="100" rx="20" fill="url(#bg)"/><text x="50" y="65" font-family="system-ui,-apple-system,sans-serif" font-size="48" font-weight="600" fill="white" text-anchor="middle">C</text></svg>');
  default_cover text := 'data:image/svg+xml,' || uri_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 400"><defs><linearGradient id="cover" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:#0f172a"/><stop offset="50%" style="stop-color:#134e4a"/><stop offset="100%" style="stop-color:#0f172a"/></linearGradient><filter id="noise"><feTurbulence baseFrequency="0.65" numOctaves="3" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/></filter></defs><rect width="1600" height="400" fill="url(#cover)"/><rect width="1600" height="400" filter="url(#noise)" opacity="0.03"/></svg>');
BEGIN
  INSERT INTO public.user_profiles (id, username, handle, avatar_url, cover_url, onboarding_completed)
  VALUES (
    NEW.id,
    COALESCE((NEW.raw_user_meta_data->>'username')::text, 'user_' || substring(NEW.id::text, 1, 8)),
    COALESCE((NEW.raw_user_meta_data->>'handle')::text, '@user_' || substring(NEW.id::text, 1, 8)),
    default_avatar,
    default_cover,
    false
  );
  RETURN NEW;
EXCEPTION
  WHEN unique_violation THEN
    RETURN NEW;
  WHEN OTHERS THEN
    RAISE WARNING 'Error creating user profile: %', SQLERRM;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Helper function for URI encoding
CREATE OR REPLACE FUNCTION public.uri_encode(input text)
RETURNS text
LANGUAGE sql
IMMUTABLE STRICT
SET search_path = public
AS $$
  SELECT string_agg(
    CASE
      WHEN ch ~ '[A-Za-z0-9_.~-]' THEN ch
      ELSE '%' || upper(encode(ch::bytea, 'hex'))
    END,
    ''
  )
  FROM regexp_split_to_table(input, '') AS ch;
$$;

-- Recreate trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Trigger to update last_message_at on conversations when a message is sent
CREATE OR REPLACE FUNCTION public.update_conversation_last_message()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.conversations
  SET last_message_at = NEW.created_at
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS on_message_sent ON messages;
CREATE TRIGGER on_message_sent
  AFTER INSERT ON messages
  FOR EACH ROW
  EXECUTE FUNCTION public.update_conversation_last_message();