/*
  # AI Content Protection System
  
  This migration implements creator protection for AI-generated content.
  
  1. New Tables
    - `ai_generated_content` - Tracks all AI-generated assets
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `content_type` (text) - 'image' or 'sound'
      - `content_url` (text) - URL to the content
      - `original_prompt` (text) - The prompt used to generate
      - `perceptual_hash` (text) - For duplicate detection
      - `metadata` (jsonb) - Additional metadata
      - `is_watermarked` (boolean) - Whether watermark is applied
      - `watermark_removed_at` (timestamptz) - When watermark was removed
      - `watermark_removal_reason` (text) - Why watermark was removed
      - `created_at` (timestamptz)
    
    - `content_similarity_flags` - Tracks potential duplicates
      - `id` (uuid, primary key)
      - `content_id` (uuid, references ai_generated_content)
      - `similar_content_id` (uuid, references ai_generated_content)
      - `similarity_score` (numeric) - 0-1 similarity percentage
      - `status` (text) - 'pending_review', 'cleared', 'confirmed_duplicate'
      - `selling_disabled` (boolean) - If selling is temporarily disabled
      - `reviewed_at` (timestamptz)
      - `reviewed_by` (uuid)
      - `created_at` (timestamptz)
    
    - `content_unlocks` - Tracks who has unlocked/purchased content
      - `id` (uuid, primary key)
      - `content_id` (uuid, references ai_generated_content)
      - `user_id` (uuid, references auth.users)
      - `unlock_type` (text) - 'purchase', 'creator_download', 'marketplace_sale'
      - `created_at` (timestamptz)
  
  2. Security
    - RLS enabled on all tables
    - Creators can view their own content
    - Users can view content they've unlocked
    - Only system can flag duplicates
  
  3. Indexes
    - Perceptual hash for fast duplicate lookup
    - User content queries
    - Similarity flag queries
*/

-- AI Generated Content tracking
CREATE TABLE IF NOT EXISTS ai_generated_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content_type text NOT NULL CHECK (content_type IN ('image', 'sound')),
  content_url text NOT NULL,
  original_prompt text,
  perceptual_hash text,
  metadata jsonb DEFAULT '{}'::jsonb,
  is_watermarked boolean DEFAULT true,
  watermark_removed_at timestamptz,
  watermark_removal_reason text CHECK (watermark_removal_reason IN ('creator_download', 'marketplace_sale', 'buyer_unlock')),
  created_at timestamptz DEFAULT now()
);

-- Content similarity flags for duplicate detection
CREATE TABLE IF NOT EXISTS content_similarity_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid NOT NULL REFERENCES ai_generated_content(id) ON DELETE CASCADE,
  similar_content_id uuid NOT NULL REFERENCES ai_generated_content(id) ON DELETE CASCADE,
  similarity_score numeric(5,4) NOT NULL CHECK (similarity_score >= 0 AND similarity_score <= 1),
  status text NOT NULL DEFAULT 'pending_review' CHECK (status IN ('pending_review', 'cleared', 'confirmed_duplicate')),
  selling_disabled boolean DEFAULT true,
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  CONSTRAINT different_content CHECK (content_id != similar_content_id)
);

-- Content unlocks tracking
CREATE TABLE IF NOT EXISTS content_unlocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid NOT NULL REFERENCES ai_generated_content(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  unlock_type text NOT NULL CHECK (unlock_type IN ('purchase', 'creator_download', 'marketplace_sale')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(content_id, user_id, unlock_type)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_ai_content_user ON ai_generated_content(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_content_hash ON ai_generated_content(perceptual_hash) WHERE perceptual_hash IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_ai_content_type ON ai_generated_content(content_type);
CREATE INDEX IF NOT EXISTS idx_ai_content_watermarked ON ai_generated_content(is_watermarked) WHERE is_watermarked = true;

CREATE INDEX IF NOT EXISTS idx_similarity_content ON content_similarity_flags(content_id);
CREATE INDEX IF NOT EXISTS idx_similarity_status ON content_similarity_flags(status) WHERE status = 'pending_review';

CREATE INDEX IF NOT EXISTS idx_unlocks_content ON content_unlocks(content_id);
CREATE INDEX IF NOT EXISTS idx_unlocks_user ON content_unlocks(user_id);

-- Enable RLS
ALTER TABLE ai_generated_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_similarity_flags ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_unlocks ENABLE ROW LEVEL SECURITY;

-- RLS Policies for ai_generated_content
CREATE POLICY "Users can view own AI content"
  ON ai_generated_content FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view AI content in feed"
  ON ai_generated_content FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM posts 
      WHERE posts.image_url = ai_generated_content.content_url
    )
  );

CREATE POLICY "Users can insert own AI content"
  ON ai_generated_content FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own AI content"
  ON ai_generated_content FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for content_similarity_flags
CREATE POLICY "Users can view flags for own content"
  ON content_similarity_flags FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ai_generated_content
      WHERE ai_generated_content.id = content_similarity_flags.content_id
      AND ai_generated_content.user_id = auth.uid()
    )
  );

-- RLS Policies for content_unlocks
CREATE POLICY "Users can view own unlocks"
  ON content_unlocks FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own unlocks"
  ON content_unlocks FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Creators can view who unlocked their content"
  ON content_unlocks FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ai_generated_content
      WHERE ai_generated_content.id = content_unlocks.content_id
      AND ai_generated_content.user_id = auth.uid()
    )
  );

-- Function to check if user has unlocked content (no watermark needed)
CREATE OR REPLACE FUNCTION public.user_has_unlocked_content(p_content_id uuid, p_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM content_unlocks
    WHERE content_id = p_content_id
    AND user_id = p_user_id
  )
  OR EXISTS (
    SELECT 1 FROM ai_generated_content
    WHERE id = p_content_id
    AND user_id = p_user_id
    AND is_watermarked = false
  );
$$;

-- Function to remove watermark when content is unlocked
CREATE OR REPLACE FUNCTION public.unlock_content(
  p_content_id uuid,
  p_unlock_type text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Insert unlock record
  INSERT INTO content_unlocks (content_id, user_id, unlock_type)
  VALUES (p_content_id, auth.uid(), p_unlock_type)
  ON CONFLICT (content_id, user_id, unlock_type) DO NOTHING;
  
  -- If creator is downloading their own content, remove watermark
  IF p_unlock_type = 'creator_download' THEN
    UPDATE ai_generated_content
    SET 
      is_watermarked = false,
      watermark_removed_at = now(),
      watermark_removal_reason = p_unlock_type
    WHERE id = p_content_id
    AND user_id = auth.uid();
  END IF;
END;
$$;
