/*
  # Fix Function Search Path Security Issue

  1. Security Fix
    - Set explicit search_path for handle_new_user() function
    - Prevents potential privilege escalation attacks
    - Ensures function only accesses intended schemas

  2. Notes
    - Functions with SECURITY DEFINER must have immutable search_path
    - This prevents malicious users from manipulating the search path
*/

-- Recreate handle_new_user function with secure search_path
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public, auth
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.user_profiles (id, username, handle, onboarding_completed)
  VALUES (
    NEW.id,
    COALESCE((NEW.raw_user_meta_data->>'username')::text, 'user_' || substring(NEW.id::text, 1, 8)),
    COALESCE((NEW.raw_user_meta_data->>'handle')::text, '@user_' || substring(NEW.id::text, 1, 8)),
    false
  );
  RETURN NEW;
EXCEPTION
  WHEN unique_violation THEN
    RETURN NEW;
  WHEN OTHERS THEN
    RAISE WARNING 'Error creating user profile: %', SQLERRM;
    RETURN NEW;
END;
$$;