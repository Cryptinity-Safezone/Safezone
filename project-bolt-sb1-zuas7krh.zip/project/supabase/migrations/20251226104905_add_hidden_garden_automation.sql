/*
  # Hidden Garden Automation System

  1. New Tables
    - `garden_themes` - Predefined themes with settings
      - `id` (uuid, primary key)
      - `name` (text) - Theme name
      - `background_gradient` (text) - CSS gradient for background
      - `mood_color` (text) - Primary mood color
      - `description` (text) - Theme description
      - `sort_order` (int) - Order in rotation
    
    - `garden_questions` - Reflection questions per theme
      - `id` (uuid, primary key)
      - `theme_id` (uuid) - Reference to theme
      - `question` (text) - The reflection question
      - `day_number` (int) - Day 1-7 within theme week
    
    - `garden_ambient_tracks` - Ambient music per theme
      - `id` (uuid, primary key)
      - `theme_id` (uuid) - Reference to theme
      - `track_name` (text) - Track display name
      - `track_url` (text) - Audio URL or identifier
      - `duration_seconds` (int) - Track duration
    
    - `garden_automation_state` - Current automation state
      - `id` (text, primary key) - Always 'current'
      - `current_theme_id` (uuid) - Active theme
      - `theme_started_at` (timestamptz) - When theme started
      - `current_question_id` (uuid) - Today's question
      - `question_changed_at` (timestamptz) - When question changed
      - `current_track_id` (uuid) - Today's track
      - `track_changed_at` (timestamptz) - When track changed
      - `theme_override` (boolean) - Admin override active
      - `question_override` (boolean) - Admin override active
      - `track_override` (boolean) - Admin override active
      - `track_paused` (boolean) - Music paused by admin

  2. Security
    - RLS enabled on all tables
    - Public read access for active content
    - Admin-only write access
*/

-- Create garden_themes table
CREATE TABLE IF NOT EXISTS garden_themes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  background_gradient text NOT NULL,
  mood_color text NOT NULL,
  description text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE garden_themes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view garden themes"
  ON garden_themes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage garden themes"
  ON garden_themes FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

-- Create garden_questions table
CREATE TABLE IF NOT EXISTS garden_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  theme_id uuid NOT NULL REFERENCES garden_themes(id) ON DELETE CASCADE,
  question text NOT NULL,
  day_number int NOT NULL CHECK (day_number >= 1 AND day_number <= 7),
  created_at timestamptz DEFAULT now(),
  UNIQUE(theme_id, day_number)
);

ALTER TABLE garden_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view garden questions"
  ON garden_questions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage garden questions"
  ON garden_questions FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

-- Create garden_ambient_tracks table
CREATE TABLE IF NOT EXISTS garden_ambient_tracks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  theme_id uuid NOT NULL REFERENCES garden_themes(id) ON DELETE CASCADE,
  track_name text NOT NULL,
  track_url text NOT NULL,
  duration_seconds int DEFAULT 180,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE garden_ambient_tracks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view garden tracks"
  ON garden_ambient_tracks FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage garden tracks"
  ON garden_ambient_tracks FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

-- Create garden_automation_state table
CREATE TABLE IF NOT EXISTS garden_automation_state (
  id text PRIMARY KEY DEFAULT 'current' CHECK (id = 'current'),
  current_theme_id uuid REFERENCES garden_themes(id),
  theme_started_at timestamptz DEFAULT now(),
  current_question_id uuid REFERENCES garden_questions(id),
  question_changed_at timestamptz DEFAULT now(),
  current_track_id uuid REFERENCES garden_ambient_tracks(id),
  track_changed_at timestamptz DEFAULT now(),
  theme_override boolean DEFAULT false,
  question_override boolean DEFAULT false,
  track_override boolean DEFAULT false,
  track_paused boolean DEFAULT false,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE garden_automation_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view automation state"
  ON garden_automation_state FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can update automation state"
  ON garden_automation_state FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

CREATE POLICY "Admins can insert automation state"
  ON garden_automation_state FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.id = auth.uid()
      AND user_profiles.is_admin = true
    )
  );

-- Insert predefined themes
INSERT INTO garden_themes (name, background_gradient, mood_color, description, sort_order)
VALUES 
  ('Stillness', 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)', '#4a6fa5', 'A space for quiet reflection and inner peace', 1),
  ('Night Thoughts', 'linear-gradient(135deg, #0d1b2a 0%, #1b263b 50%, #2d3142 100%)', '#7b8cde', 'Embrace the contemplative hours of darkness', 2),
  ('Healing', 'linear-gradient(135deg, #1a2f38 0%, #2d4a53 50%, #3d5a5a 100%)', '#7fb685', 'Nurturing restoration and gentle recovery', 3),
  ('Light', 'linear-gradient(135deg, #2c3e50 0%, #3498db 50%, #5dade2 100%)', '#f4d03f', 'Finding brightness in moments of clarity', 4)
ON CONFLICT DO NOTHING;

-- Insert questions for Stillness theme
INSERT INTO garden_questions (theme_id, question, day_number)
SELECT id, question, day_num
FROM garden_themes, 
  (VALUES 
    ('What moment today brought you unexpected peace?', 1),
    ('Where in your body do you feel tension right now?', 2),
    ('What sound would you like to hear more of in your life?', 3),
    ('When did you last feel truly present?', 4),
    ('What thought keeps returning to you lately?', 5),
    ('What small thing are you grateful for today?', 6),
    ('If your mind were a landscape, what would it look like right now?', 7)
  ) AS q(question, day_num)
WHERE garden_themes.name = 'Stillness'
ON CONFLICT DO NOTHING;

-- Insert questions for Night Thoughts theme
INSERT INTO garden_questions (theme_id, question, day_number)
SELECT id, question, day_num
FROM garden_themes, 
  (VALUES 
    ('What unfinished thought from today deserves attention?', 1),
    ('What dream or hope have you been quietly holding?', 2),
    ('What would you tell your younger self about tonight?', 3),
    ('What feels different in the quiet of this hour?', 4),
    ('What are you ready to let go of?', 5),
    ('What conversation do you wish you could have?', 6),
    ('What does your heart want to say that words cannot?', 7)
  ) AS q(question, day_num)
WHERE garden_themes.name = 'Night Thoughts'
ON CONFLICT DO NOTHING;

-- Insert questions for Healing theme
INSERT INTO garden_questions (theme_id, question, day_number)
SELECT id, question, day_num
FROM garden_themes, 
  (VALUES 
    ('What part of yourself needs gentle attention today?', 1),
    ('What would it feel like to fully accept where you are?', 2),
    ('What kindness can you offer yourself right now?', 3),
    ('What strength have you discovered through difficulty?', 4),
    ('What boundary would help you heal?', 5),
    ('What does your body need that you have been ignoring?', 6),
    ('What would healing look like for you today?', 7)
  ) AS q(question, day_num)
WHERE garden_themes.name = 'Healing'
ON CONFLICT DO NOTHING;

-- Insert questions for Light theme
INSERT INTO garden_questions (theme_id, question, day_number)
SELECT id, question, day_num
FROM garden_themes, 
  (VALUES 
    ('What sparked joy in you recently, however small?', 1),
    ('What possibility excites you about tomorrow?', 2),
    ('Who or what makes you feel most alive?', 3),
    ('What beauty did you notice today?', 4),
    ('What are you looking forward to?', 5),
    ('What would you create if fear was not a factor?', 6),
    ('What light do you bring to others?', 7)
  ) AS q(question, day_num)
WHERE garden_themes.name = 'Light'
ON CONFLICT DO NOTHING;

-- Insert ambient tracks for each theme (placeholder URLs - would be replaced with actual audio)
INSERT INTO garden_ambient_tracks (theme_id, track_name, track_url, duration_seconds)
SELECT id, track_name, track_url, duration
FROM garden_themes, 
  (VALUES 
    ('Gentle Rain', 'ambient://stillness/gentle-rain', 300),
    ('Forest Silence', 'ambient://stillness/forest-silence', 280),
    ('Soft Wind', 'ambient://stillness/soft-wind', 320)
  ) AS t(track_name, track_url, duration)
WHERE garden_themes.name = 'Stillness'
ON CONFLICT DO NOTHING;

INSERT INTO garden_ambient_tracks (theme_id, track_name, track_url, duration_seconds)
SELECT id, track_name, track_url, duration
FROM garden_themes, 
  (VALUES 
    ('Midnight Stars', 'ambient://night/midnight-stars', 360),
    ('Distant Ocean', 'ambient://night/distant-ocean', 300),
    ('Moonlit Garden', 'ambient://night/moonlit-garden', 340)
  ) AS t(track_name, track_url, duration)
WHERE garden_themes.name = 'Night Thoughts'
ON CONFLICT DO NOTHING;

INSERT INTO garden_ambient_tracks (theme_id, track_name, track_url, duration_seconds)
SELECT id, track_name, track_url, duration
FROM garden_themes, 
  (VALUES 
    ('Warm Embrace', 'ambient://healing/warm-embrace', 320),
    ('Gentle Stream', 'ambient://healing/gentle-stream', 280),
    ('Safe Harbor', 'ambient://healing/safe-harbor', 300)
  ) AS t(track_name, track_url, duration)
WHERE garden_themes.name = 'Healing'
ON CONFLICT DO NOTHING;

INSERT INTO garden_ambient_tracks (theme_id, track_name, track_url, duration_seconds)
SELECT id, track_name, track_url, duration
FROM garden_themes, 
  (VALUES 
    ('Morning Glow', 'ambient://light/morning-glow', 300),
    ('Sunlit Meadow', 'ambient://light/sunlit-meadow', 320),
    ('Hopeful Dawn', 'ambient://light/hopeful-dawn', 280)
  ) AS t(track_name, track_url, duration)
WHERE garden_themes.name = 'Light'
ON CONFLICT DO NOTHING;

-- Initialize automation state with first theme
INSERT INTO garden_automation_state (id, current_theme_id, theme_started_at)
SELECT 'current', id, now()
FROM garden_themes
WHERE sort_order = 1
ON CONFLICT (id) DO NOTHING;

-- Update automation state with first question and track
UPDATE garden_automation_state
SET 
  current_question_id = (
    SELECT gq.id FROM garden_questions gq
    WHERE gq.theme_id = garden_automation_state.current_theme_id
    AND gq.day_number = 1
    LIMIT 1
  ),
  current_track_id = (
    SELECT gt.id FROM garden_ambient_tracks gt
    WHERE gt.theme_id = garden_automation_state.current_theme_id
    ORDER BY random()
    LIMIT 1
  )
WHERE id = 'current';

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_garden_questions_theme ON garden_questions(theme_id);
CREATE INDEX IF NOT EXISTS idx_garden_tracks_theme ON garden_ambient_tracks(theme_id);
CREATE INDEX IF NOT EXISTS idx_garden_themes_sort ON garden_themes(sort_order);