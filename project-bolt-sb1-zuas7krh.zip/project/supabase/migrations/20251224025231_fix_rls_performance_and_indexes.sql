/*
  # Fix RLS Performance and Missing Indexes

  ## Overview
  This migration optimizes Row Level Security (RLS) policies and adds missing indexes
  to improve query performance at scale.

  ## Changes

  ### 1. Missing Index
  - Add index on `message_reports.message_id` for improved foreign key performance

  ### 2. RLS Performance Optimization
  All RLS policies are updated to use `(select auth.uid())` instead of `auth.uid()`.
  This prevents re-evaluation of the auth function for each row, significantly
  improving query performance at scale.

  **Tables Updated:**
  - `message_reports` (2 policies)
  - `conversations` (3 policies)
  - `messages` (2 policies)
  - `message_requests` (4 policies)

  ## Performance Impact
  - Foreign key queries on message_reports will use indexes
  - RLS policy evaluation will be cached per query instead of per row
  - Expected 10-100x performance improvement on large datasets

  ## Security
  - No changes to security logic, only performance optimizations
  - All existing access controls remain intact
*/

-- Add missing index for message_reports.message_id foreign key
CREATE INDEX IF NOT EXISTS idx_message_reports_message_id ON message_reports(message_id);

-- Drop existing policies to recreate them with optimized auth calls
DROP POLICY IF EXISTS "Users can view own message reports" ON message_reports;
DROP POLICY IF EXISTS "Users can create message reports" ON message_reports;
DROP POLICY IF EXISTS "Users can view own conversations" ON conversations;
DROP POLICY IF EXISTS "Users can create conversations" ON conversations;
DROP POLICY IF EXISTS "Users can update own conversations" ON conversations;
DROP POLICY IF EXISTS "Users can view messages in own conversations" ON messages;
DROP POLICY IF EXISTS "Users can send messages to own conversations" ON messages;
DROP POLICY IF EXISTS "Users can view own message requests" ON message_requests;
DROP POLICY IF EXISTS "Users can send message requests" ON message_requests;
DROP POLICY IF EXISTS "Users can update own received requests" ON message_requests;
DROP POLICY IF EXISTS "Users can delete own sent requests" ON message_requests;

-- Recreate message_reports policies with optimized auth calls
CREATE POLICY "Users can view own message reports"
  ON message_reports FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = reporter_id);

CREATE POLICY "Users can create message reports"
  ON message_reports FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = reporter_id);

-- Recreate conversations policies with optimized auth calls
CREATE POLICY "Users can view own conversations"
  ON conversations FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = participant_one OR (select auth.uid()) = participant_two);

CREATE POLICY "Users can create conversations"
  ON conversations FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = participant_one OR (select auth.uid()) = participant_two);

CREATE POLICY "Users can update own conversations"
  ON conversations FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = participant_one OR (select auth.uid()) = participant_two)
  WITH CHECK ((select auth.uid()) = participant_one OR (select auth.uid()) = participant_two);

-- Recreate messages policies with optimized auth calls
CREATE POLICY "Users can view messages in own conversations"
  ON messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_id
      AND (c.participant_one = (select auth.uid()) OR c.participant_two = (select auth.uid()))
    )
  );

CREATE POLICY "Users can send messages to own conversations"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (
    (select auth.uid()) = sender_id
    AND EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_id
      AND (c.participant_one = (select auth.uid()) OR c.participant_two = (select auth.uid()))
    )
  );

-- Recreate message_requests policies with optimized auth calls
CREATE POLICY "Users can view own message requests"
  ON message_requests FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = sender_id OR (select auth.uid()) = recipient_id);

CREATE POLICY "Users can send message requests"
  ON message_requests FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = sender_id);

CREATE POLICY "Users can update own received requests"
  ON message_requests FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = recipient_id)
  WITH CHECK ((select auth.uid()) = recipient_id);

CREATE POLICY "Users can delete own sent requests"
  ON message_requests FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = sender_id);
