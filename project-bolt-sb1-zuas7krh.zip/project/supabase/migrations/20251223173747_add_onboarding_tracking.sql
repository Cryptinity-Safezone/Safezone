/*
  # Add Onboarding Tracking

  1. Changes
    - Add `onboarding_completed` column to `user_profiles` table
      - Boolean field to track if user has completed onboarding
      - Defaults to false for new users
      - Set to true once onboarding is completed
  
  2. Purpose
    - Track which users have completed the initial onboarding flow
    - Show onboarding screens only to new users who haven't seen them
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'onboarding_completed'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN onboarding_completed boolean DEFAULT false NOT NULL;
  END IF;
END $$;