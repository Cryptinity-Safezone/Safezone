/*
  # Create Hidden Garden Audio Storage Bucket

  1. Storage Setup
    - Creates "hidden-garden-audio" bucket for AI-generated ambient sounds
    - Public access enabled for playback
    - Accepts .mp3 files only
  
  2. Security
    - Anyone can read/download files (public playback)
    - Only authenticated users can upload/delete files
*/

-- Create the hidden-garden-audio bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'hidden-garden-audio',
  'hidden-garden-audio',
  true,
  10485760,
  ARRAY['audio/mpeg', 'audio/mp3']
)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 10485760,
  allowed_mime_types = ARRAY['audio/mpeg', 'audio/mp3'];

-- Allow public read access for playback
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Public can read hidden garden audio'
  ) THEN
    EXECUTE 'CREATE POLICY "Public can read hidden garden audio"
      ON storage.objects FOR SELECT
      TO public
      USING (bucket_id = ''hidden-garden-audio'')';
  END IF;
END $$;

-- Allow authenticated users to upload
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Authenticated can upload hidden garden audio'
  ) THEN
    EXECUTE 'CREATE POLICY "Authenticated can upload hidden garden audio"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (bucket_id = ''hidden-garden-audio'')';
  END IF;
END $$;

-- Allow authenticated users to delete
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Authenticated can delete hidden garden audio'
  ) THEN
    EXECUTE 'CREATE POLICY "Authenticated can delete hidden garden audio"
      ON storage.objects FOR DELETE
      TO authenticated
      USING (bucket_id = ''hidden-garden-audio'')';
  END IF;
END $$;