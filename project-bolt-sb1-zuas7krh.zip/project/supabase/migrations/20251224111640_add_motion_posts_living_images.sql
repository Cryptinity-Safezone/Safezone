/*
  # Add Living Images (Motion Posts) Feature

  1. New Tables
    - `motion_generations`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `source_image_id` (uuid, references generated_images)
      - `source_image_url` (text) - URL of source image
      - `motion_type` (text) - breathing, drift, hair_cloth, particles, camera_pan
      - `video_url` (text) - generated video URL
      - `thumbnail_url` (text) - first frame thumbnail
      - `duration_seconds` (integer, default 10, max 10)
      - `format` (text) - mp4 or webm
      - `status` (text) - pending, processing, completed, failed
      - `cty_cost` (integer) - CTY spent on generation
      - `is_private` (boolean, default true) - privacy default
      - `error_message` (text, nullable)
      - `created_at` (timestamptz)
      - `completed_at` (timestamptz, nullable)

  2. Modified Tables
    - `posts` - Add motion content fields
      - `motion_url` (text, nullable) - URL to motion video
      - `motion_generation_id` (uuid, nullable) - Link to generation record
      - `is_motion_post` (boolean, default false)

  3. Security
    - Enable RLS on motion_generations
    - Users can only view/manage their own generations
    - Public can view motion in public posts

  4. Indexes
    - Index on user_id for fast lookups
    - Index on source_image_id for generation history
    - Index on status for processing queries
*/

-- Create motion_generations table
CREATE TABLE IF NOT EXISTS public.motion_generations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  source_image_id uuid REFERENCES public.generated_images(id) ON DELETE SET NULL,
  source_image_url text NOT NULL,
  motion_type text NOT NULL CHECK (motion_type IN ('breathing', 'drift', 'hair_cloth', 'particles', 'camera_pan')),
  video_url text,
  thumbnail_url text,
  duration_seconds integer NOT NULL DEFAULT 10 CHECK (duration_seconds > 0 AND duration_seconds <= 10),
  format text NOT NULL DEFAULT 'mp4' CHECK (format IN ('mp4', 'webm')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  cty_cost integer NOT NULL DEFAULT 0,
  is_private boolean NOT NULL DEFAULT true,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  metadata jsonb DEFAULT '{}'::jsonb
);

-- Add motion fields to posts table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'posts' AND column_name = 'motion_url'
  ) THEN
    ALTER TABLE public.posts ADD COLUMN motion_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'posts' AND column_name = 'motion_generation_id'
  ) THEN
    ALTER TABLE public.posts ADD COLUMN motion_generation_id uuid REFERENCES public.motion_generations(id) ON DELETE SET NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'posts' AND column_name = 'is_motion_post'
  ) THEN
    ALTER TABLE public.posts ADD COLUMN is_motion_post boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- Enable RLS on motion_generations
ALTER TABLE public.motion_generations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for motion_generations
CREATE POLICY "Users can view their own motion generations"
  ON public.motion_generations
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own motion generations"
  ON public.motion_generations
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own motion generations"
  ON public.motion_generations
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own motion generations"
  ON public.motion_generations
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_motion_generations_user_id 
  ON public.motion_generations(user_id);

CREATE INDEX IF NOT EXISTS idx_motion_generations_source_image 
  ON public.motion_generations(source_image_id);

CREATE INDEX IF NOT EXISTS idx_motion_generations_status 
  ON public.motion_generations(status);

CREATE INDEX IF NOT EXISTS idx_motion_generations_created_at 
  ON public.motion_generations(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_posts_is_motion_post 
  ON public.posts(is_motion_post) WHERE is_motion_post = true;

CREATE INDEX IF NOT EXISTS idx_posts_motion_generation_id 
  ON public.posts(motion_generation_id) WHERE motion_generation_id IS NOT NULL;

-- Grant permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON public.motion_generations TO authenticated;
