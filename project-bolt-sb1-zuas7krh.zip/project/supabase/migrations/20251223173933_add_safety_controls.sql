/*
  # Add User Safety Controls

  1. New Tables
    - `user_blocks`
      - `id` (uuid, primary key)
      - `blocker_id` (uuid, references user_profiles)
      - `blocked_id` (uuid, references user_profiles)
      - `created_at` (timestamptz)
    
    - `hidden_posts`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references user_profiles)
      - `post_id` (uuid, references posts)
      - `created_at` (timestamptz)
    
    - `post_reports`
      - `id` (uuid, primary key)
      - `reporter_id` (uuid, references user_profiles)
      - `post_id` (uuid, references posts)
      - `reason` (text)
      - `details` (text, optional)
      - `status` (text, default 'pending')
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for users to manage their own blocks, hidden posts, and reports
    - Prevent viewing blocked users' content

  3. Indexes
    - Add indexes for efficient querying
*/

CREATE TABLE IF NOT EXISTS user_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(blocker_id, blocked_id),
  CHECK (blocker_id != blocked_id)
);

CREATE INDEX IF NOT EXISTS idx_user_blocks_blocker ON user_blocks(blocker_id);
CREATE INDEX IF NOT EXISTS idx_user_blocks_blocked ON user_blocks(blocked_id);

ALTER TABLE user_blocks ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'user_blocks' AND policyname = 'Users can view their own blocks'
  ) THEN
    CREATE POLICY "Users can view their own blocks"
      ON user_blocks FOR SELECT
      TO authenticated
      USING (auth.uid() = blocker_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'user_blocks' AND policyname = 'Users can create blocks'
  ) THEN
    CREATE POLICY "Users can create blocks"
      ON user_blocks FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = blocker_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'user_blocks' AND policyname = 'Users can delete their own blocks'
  ) THEN
    CREATE POLICY "Users can delete their own blocks"
      ON user_blocks FOR DELETE
      TO authenticated
      USING (auth.uid() = blocker_id);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS hidden_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id, post_id)
);

CREATE INDEX IF NOT EXISTS idx_hidden_posts_user ON hidden_posts(user_id);
CREATE INDEX IF NOT EXISTS idx_hidden_posts_post ON hidden_posts(post_id);

ALTER TABLE hidden_posts ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'hidden_posts' AND policyname = 'Users can view their own hidden posts'
  ) THEN
    CREATE POLICY "Users can view their own hidden posts"
      ON hidden_posts FOR SELECT
      TO authenticated
      USING (auth.uid() = user_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'hidden_posts' AND policyname = 'Users can hide posts'
  ) THEN
    CREATE POLICY "Users can hide posts"
      ON hidden_posts FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = user_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'hidden_posts' AND policyname = 'Users can unhide posts'
  ) THEN
    CREATE POLICY "Users can unhide posts"
      ON hidden_posts FOR DELETE
      TO authenticated
      USING (auth.uid() = user_id);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS post_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  reason text NOT NULL,
  details text,
  status text DEFAULT 'pending' NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  CHECK (reason IN ('spam', 'harassment', 'inappropriate', 'misleading', 'other'))
);

CREATE INDEX IF NOT EXISTS idx_post_reports_reporter ON post_reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_post_reports_post ON post_reports(post_id);
CREATE INDEX IF NOT EXISTS idx_post_reports_status ON post_reports(status);

ALTER TABLE post_reports ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'post_reports' AND policyname = 'Users can view their own reports'
  ) THEN
    CREATE POLICY "Users can view their own reports"
      ON post_reports FOR SELECT
      TO authenticated
      USING (auth.uid() = reporter_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'post_reports' AND policyname = 'Users can create reports'
  ) THEN
    CREATE POLICY "Users can create reports"
      ON post_reports FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = reporter_id);
  END IF;
END $$;