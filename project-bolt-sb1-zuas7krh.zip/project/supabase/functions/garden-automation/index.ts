import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const THEME_DURATION_DAYS = 7;
const QUESTION_DURATION_HOURS = 24;
const TRACK_DURATION_HOURS = 24;

interface AutomationState {
  id: string;
  current_theme_id: string | null;
  theme_started_at: string;
  current_question_id: string | null;
  question_changed_at: string;
  current_track_id: string | null;
  track_changed_at: string;
  theme_override: boolean;
  question_override: boolean;
  track_override: boolean;
  track_paused: boolean;
  updated_at: string;
}

interface Theme {
  id: string;
  name: string;
  background_gradient: string;
  mood_color: string;
  description: string;
  sort_order: number;
}

interface Question {
  id: string;
  theme_id: string;
  question: string;
  day_number: number;
}

interface Track {
  id: string;
  theme_id: string;
  track_name: string;
  track_url: string;
  duration_seconds: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "No authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: stateData, error: stateError } = await supabase
      .from("garden_automation_state")
      .select("*")
      .eq("id", "current")
      .maybeSingle();

    if (stateError) throw stateError;

    const { data: themes, error: themesError } = await supabase
      .from("garden_themes")
      .select("*")
      .order("sort_order");

    if (themesError) throw themesError;

    if (!themes || themes.length === 0) {
      return new Response(JSON.stringify({ error: "No themes configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let state: AutomationState = stateData;
    const now = new Date();
    let needsUpdate = false;
    const updates: Partial<AutomationState> = {};

    if (!state) {
      const firstTheme = themes[0];
      const { data: questions } = await supabase
        .from("garden_questions")
        .select("*")
        .eq("theme_id", firstTheme.id)
        .eq("day_number", 1)
        .maybeSingle();

      const { data: tracks } = await supabase
        .from("garden_ambient_tracks")
        .select("*")
        .eq("theme_id", firstTheme.id);

      const randomTrack = tracks && tracks.length > 0 
        ? tracks[Math.floor(Math.random() * tracks.length)] 
        : null;

      const { data: newState, error: insertError } = await supabase
        .from("garden_automation_state")
        .insert({
          id: "current",
          current_theme_id: firstTheme.id,
          theme_started_at: now.toISOString(),
          current_question_id: questions?.id || null,
          question_changed_at: now.toISOString(),
          current_track_id: randomTrack?.id || null,
          track_changed_at: now.toISOString(),
        })
        .select()
        .single();

      if (insertError) throw insertError;
      state = newState;
    }

    const themeStarted = new Date(state.theme_started_at);
    const daysSinceThemeStart = Math.floor((now.getTime() - themeStarted.getTime()) / (1000 * 60 * 60 * 24));

    if (daysSinceThemeStart >= THEME_DURATION_DAYS && !state.theme_override) {
      const currentTheme = themes.find((t: Theme) => t.id === state.current_theme_id);
      const currentIndex = currentTheme ? themes.findIndex((t: Theme) => t.id === currentTheme.id) : -1;
      const nextIndex = (currentIndex + 1) % themes.length;
      const nextTheme = themes[nextIndex];

      updates.current_theme_id = nextTheme.id;
      updates.theme_started_at = now.toISOString();
      updates.question_override = false;
      updates.track_override = false;
      needsUpdate = true;

      const { data: firstQuestion } = await supabase
        .from("garden_questions")
        .select("*")
        .eq("theme_id", nextTheme.id)
        .eq("day_number", 1)
        .maybeSingle();

      if (firstQuestion) {
        updates.current_question_id = firstQuestion.id;
        updates.question_changed_at = now.toISOString();
      }

      const { data: themeTracks } = await supabase
        .from("garden_ambient_tracks")
        .select("*")
        .eq("theme_id", nextTheme.id);

      if (themeTracks && themeTracks.length > 0) {
        const randomTrack = themeTracks[Math.floor(Math.random() * themeTracks.length)];
        updates.current_track_id = randomTrack.id;
        updates.track_changed_at = now.toISOString();
      }
    } else {
      const questionChanged = new Date(state.question_changed_at);
      const hoursSinceQuestion = (now.getTime() - questionChanged.getTime()) / (1000 * 60 * 60);

      if (hoursSinceQuestion >= QUESTION_DURATION_HOURS && !state.question_override) {
        const themeId = updates.current_theme_id || state.current_theme_id;
        const dayInTheme = Math.floor((now.getTime() - themeStarted.getTime()) / (1000 * 60 * 60 * 24)) % 7 + 1;

        const { data: nextQuestion } = await supabase
          .from("garden_questions")
          .select("*")
          .eq("theme_id", themeId)
          .eq("day_number", dayInTheme)
          .maybeSingle();

        if (nextQuestion && nextQuestion.id !== state.current_question_id) {
          updates.current_question_id = nextQuestion.id;
          updates.question_changed_at = now.toISOString();
          needsUpdate = true;
        }
      }

      const trackChanged = new Date(state.track_changed_at);
      const hoursSinceTrack = (now.getTime() - trackChanged.getTime()) / (1000 * 60 * 60);

      if (hoursSinceTrack >= TRACK_DURATION_HOURS && !state.track_override) {
        const themeId = updates.current_theme_id || state.current_theme_id;

        const { data: themeTracks } = await supabase
          .from("garden_ambient_tracks")
          .select("*")
          .eq("theme_id", themeId);

        if (themeTracks && themeTracks.length > 0) {
          const availableTracks = themeTracks.filter((t: Track) => t.id !== state.current_track_id);
          const trackPool = availableTracks.length > 0 ? availableTracks : themeTracks;
          const randomTrack = trackPool[Math.floor(Math.random() * trackPool.length)];

          updates.current_track_id = randomTrack.id;
          updates.track_changed_at = now.toISOString();
          needsUpdate = true;
        }
      }
    }

    if (needsUpdate) {
      updates.updated_at = now.toISOString();

      const { error: updateError } = await supabase
        .from("garden_automation_state")
        .update(updates)
        .eq("id", "current");

      if (updateError) throw updateError;

      state = { ...state, ...updates };
    }

    const currentTheme = themes.find((t: Theme) => t.id === state.current_theme_id);

    const { data: currentQuestion } = await supabase
      .from("garden_questions")
      .select("*")
      .eq("id", state.current_question_id)
      .maybeSingle();

    const { data: currentTrack } = await supabase
      .from("garden_ambient_tracks")
      .select("*")
      .eq("id", state.current_track_id)
      .maybeSingle();

    const themeStartedDate = new Date(state.theme_started_at);
    const daysRemaining = THEME_DURATION_DAYS - Math.floor((now.getTime() - themeStartedDate.getTime()) / (1000 * 60 * 60 * 24));

    return new Response(
      JSON.stringify({
        success: true,
        state: {
          theme: currentTheme,
          question: currentQuestion,
          track: currentTrack,
          track_paused: state.track_paused,
          overrides: {
            theme: state.theme_override,
            question: state.question_override,
            track: state.track_override,
          },
          meta: {
            theme_days_remaining: Math.max(0, daysRemaining),
            theme_started_at: state.theme_started_at,
            question_changed_at: state.question_changed_at,
            track_changed_at: state.track_changed_at,
          },
        },
        all_themes: themes,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Garden automation error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});