import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const BUCKET_NAME = "hidden-garden-audio";

interface UploadRequest {
  audioData: string;
  title: string;
  mood?: string;
  durationSeconds: number;
  themeId?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "No authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: profile } = await supabase
      .from("user_profiles")
      .select("is_admin")
      .eq("id", user.id)
      .maybeSingle();

    if (!profile?.is_admin) {
      return new Response(
        JSON.stringify({ error: "Admin access required" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body: UploadRequest = await req.json();
    const { audioData, title, mood, durationSeconds, themeId } = body;

    if (!audioData || !title || !durationSeconds) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: audioData, title, durationSeconds" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (durationSeconds <= 0) {
      return new Response(
        JSON.stringify({ error: "Duration must be a positive number in seconds" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let audioBuffer: Uint8Array;
    try {
      const base64Data = audioData.replace(/^data:audio\/\w+;base64,/, "");
      const binaryString = atob(base64Data);
      audioBuffer = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        audioBuffer[i] = binaryString.charCodeAt(i);
      }
    } catch {
      return new Response(
        JSON.stringify({ error: "Invalid audio data format" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const timestamp = Date.now();
    const sanitizedTitle = title.toLowerCase().replace(/[^a-z0-9]/g, "-").substring(0, 50);
    const fileName = `${sanitizedTitle}-${timestamp}.mp3`;

    const { error: uploadError } = await supabase.storage
      .from(BUCKET_NAME)
      .upload(fileName, audioBuffer, {
        contentType: "audio/mpeg",
        upsert: false,
      });

    if (uploadError) {
      console.error("Upload error:", uploadError);
      return new Response(
        JSON.stringify({ error: "Failed to upload audio file", details: uploadError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: publicUrlData } = supabase.storage
      .from(BUCKET_NAME)
      .getPublicUrl(fileName);

    const publicUrl = publicUrlData.publicUrl;

    const { data: musicRecord, error: dbError } = await supabase
      .from("hidden_garden_music")
      .insert({
        title: title,
        mood: mood || "ambient",
        duration: durationSeconds,
        audio_url: publicUrl,
        is_ai_generated: true,
        is_active: true,
        loop_enabled: true,
        volume: 0.3,
        uploaded_by: user.id,
      })
      .select()
      .single();

    if (dbError) {
      console.error("Database error:", dbError);
      await supabase.storage.from(BUCKET_NAME).remove([fileName]);
      return new Response(
        JSON.stringify({ error: "Failed to save audio record", details: dbError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (themeId) {
      const { error: trackError } = await supabase
        .from("garden_ambient_tracks")
        .insert({
          theme_id: themeId,
          track_name: title,
          track_url: publicUrl,
          duration_seconds: durationSeconds,
        });

      if (trackError) {
        console.warn("Failed to add to theme tracks:", trackError);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: "Audio uploaded and saved successfully",
        data: {
          id: musicRecord.id,
          title: musicRecord.title,
          audio_url: publicUrl,
          duration: durationSeconds,
          is_ai_generated: true,
          is_active: true,
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Garden audio upload error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});