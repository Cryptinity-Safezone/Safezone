import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SimilarityRequest {
  content_id: string;
  content_url: string;
  content_type: 'image' | 'sound';
}

interface SimilarityResult {
  hasSimilar: boolean;
  similarContent?: {
    id: string;
    similarity_score: number;
  }[];
  message?: string;
}

const ALLOWED_CONTENT_HOSTS = [
  'images.pexels.com',
  'videos.pexels.com',
  'images.unsplash.com',
];

function validateUrl(urlString: string): { valid: boolean; error?: string } {
  try {
    const url = new URL(urlString);
    
    if (url.protocol !== 'https:') {
      return { valid: false, error: 'Only HTTPS URLs are allowed' };
    }
    
    const hostname = url.hostname.toLowerCase();
    
    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '0.0.0.0') {
      return { valid: false, error: 'Local URLs are not allowed' };
    }
    
    if (/^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.|169\.254\.)/.test(hostname)) {
      return { valid: false, error: 'Private IP addresses are not allowed' };
    }
    
    if (hostname.endsWith('.local') || hostname.endsWith('.internal')) {
      return { valid: false, error: 'Internal hostnames are not allowed' };
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    if (supabaseUrl) {
      const supabaseHost = new URL(supabaseUrl).hostname;
      if (hostname === supabaseHost || hostname.endsWith(`.${supabaseHost}`)) {
        return { valid: true };
      }
    }
    
    const isAllowed = ALLOWED_CONTENT_HOSTS.some(allowed => 
      hostname === allowed || hostname.endsWith(`.${allowed}`)
    );
    
    if (!isAllowed) {
      return { valid: false, error: 'Content host not in allowed list' };
    }
    
    return { valid: true };
  } catch {
    return { valid: false, error: 'Invalid URL format' };
  }
}

function validateUUID(id: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(id);
}

async function secureHash(input: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function calculateSimilarity(hash1: string, hash2: string): number {
  if (!hash1 || !hash2) return 0;
  if (hash1 === hash2) return 1;
  
  const len = Math.max(hash1.length, hash2.length);
  let matches = 0;
  for (let i = 0; i < Math.min(hash1.length, hash2.length); i++) {
    if (hash1[i] === hash2[i]) matches++;
  }
  return matches / len;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { data: { user }, error: authError } = await createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    ).auth.getUser();

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const body: SimilarityRequest = await req.json();
    const { content_id, content_url, content_type } = body;

    if (!content_id || typeof content_id !== 'string') {
      return new Response(
        JSON.stringify({ error: 'Content ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!validateUUID(content_id)) {
      return new Response(
        JSON.stringify({ error: 'Invalid content ID format' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!content_url || typeof content_url !== 'string') {
      return new Response(
        JSON.stringify({ error: 'Content URL is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const urlValidation = validateUrl(content_url);
    if (!urlValidation.valid) {
      return new Response(
        JSON.stringify({ error: urlValidation.error }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!content_type || !['image', 'sound'].includes(content_type)) {
      return new Response(
        JSON.stringify({ error: 'Invalid content type' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const contentHash = await secureHash(content_url + content_type + Date.now().toString());

    await supabase
      .from('ai_generated_content')
      .update({ perceptual_hash: contentHash })
      .eq('id', content_id);

    const { data: existingContent } = await supabase
      .from('ai_generated_content')
      .select('id, perceptual_hash, user_id')
      .eq('content_type', content_type)
      .neq('id', content_id)
      .not('perceptual_hash', 'is', null)
      .limit(1000);

    const similarContent: { id: string; similarity_score: number }[] = [];
    const SIMILARITY_THRESHOLD = 0.85;

    for (const existing of existingContent || []) {
      const similarity = calculateSimilarity(contentHash, existing.perceptual_hash);
      
      if (similarity >= SIMILARITY_THRESHOLD) {
        similarContent.push({
          id: existing.id,
          similarity_score: similarity,
        });

        await supabase
          .from('content_similarity_flags')
          .upsert({
            content_id: content_id,
            similar_content_id: existing.id,
            similarity_score: similarity,
            status: 'pending_review',
            selling_disabled: true,
          }, {
            onConflict: 'content_id,similar_content_id',
          });
      }
    }

    const result: SimilarityResult = {
      hasSimilar: similarContent.length > 0,
      similarContent: similarContent.length > 0 ? similarContent : undefined,
      message: similarContent.length > 0
        ? "We noticed some similarity with existing content. This has been flagged for review. You can still view and share your creation, but marketplace listing is temporarily paused until our team reviews it."
        : undefined,
    };

    return new Response(
      JSON.stringify(result),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ error: message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});