import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface GenerateMotionRequest {
  sourceImageId: string;
  sourceImageUrl: string;
  motionType: 'breathing' | 'drift' | 'hair_cloth' | 'particles' | 'camera_pan';
  duration?: number;
  isPrivate?: boolean;
}

const MOTION_COSTS = {
  basic: 75,
  premium: 150,
};

const MOTION_TYPES = ['breathing', 'drift', 'hair_cloth', 'particles', 'camera_pan'];

const MOTION_DESCRIPTIONS: Record<string, string> = {
  breathing: 'Subtle breathing effect with gentle expansion and contraction',
  drift: 'Light drifting motion with slow ambient movement',
  hair_cloth: 'Natural hair and fabric movement simulation',
  particles: 'Animated particles, stars, or floating elements',
  camera_pan: 'Gentle camera pan or zoom effect',
};

const BLOCKED_MOTION_CONTENT = [
  'deepfake',
  'face swap',
  'celebrity',
  'real person',
  'reenactment',
  'lip sync',
  'talking head',
];

const ALLOWED_IMAGE_HOSTS = [
  'images.pexels.com',
  'videos.pexels.com',
  'images.unsplash.com',
];

function validateUrl(urlString: string): { valid: boolean; error?: string } {
  try {
    const url = new URL(urlString);
    
    if (url.protocol !== 'https:') {
      return { valid: false, error: 'Only HTTPS URLs are allowed' };
    }
    
    const hostname = url.hostname.toLowerCase();
    
    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '0.0.0.0') {
      return { valid: false, error: 'Local URLs are not allowed' };
    }
    
    if (/^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.|169\.254\.)/.test(hostname)) {
      return { valid: false, error: 'Private IP addresses are not allowed' };
    }
    
    if (hostname.endsWith('.local') || hostname.endsWith('.internal')) {
      return { valid: false, error: 'Internal hostnames are not allowed' };
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    if (supabaseUrl) {
      const supabaseHost = new URL(supabaseUrl).hostname;
      if (hostname === supabaseHost || hostname.endsWith(`.${supabaseHost}`)) {
        return { valid: true };
      }
    }
    
    const isAllowed = ALLOWED_IMAGE_HOSTS.some(allowed => 
      hostname === allowed || hostname.endsWith(`.${allowed}`)
    );
    
    if (!isAllowed) {
      return { valid: false, error: 'Image host not in allowed list' };
    }
    
    return { valid: true };
  } catch {
    return { valid: false, error: 'Invalid URL format' };
  }
}

function validateUUID(id: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(id);
}

async function validateSourceImage(
  supabase: ReturnType<typeof createClient>,
  userId: string,
  sourceImageId: string
): Promise<{ valid: boolean; error?: string; imageData?: Record<string, unknown> }> {
  const { data: image, error } = await supabase
    .from('generated_images')
    .select('*')
    .eq('id', sourceImageId)
    .eq('user_id', userId)
    .eq('status', 'completed')
    .maybeSingle();

  if (error || !image) {
    return { valid: false, error: 'Source image not found or not owned by user' };
  }

  return { valid: true, imageData: image };
}

async function checkSafetyRules(
  sourceImage: Record<string, unknown>
): Promise<{ safe: boolean; reason?: string }> {
  const prompt = (String(sourceImage.prompt || '')).toLowerCase();
  const sanitizedPrompt = (String(sourceImage.sanitized_prompt || '')).toLowerCase();

  for (const blocked of BLOCKED_MOTION_CONTENT) {
    if (prompt.includes(blocked) || sanitizedPrompt.includes(blocked)) {
      return { safe: false, reason: 'This content type is not allowed for motion generation' };
    }
  }

  const metadata = (sourceImage.generation_metadata || {}) as Record<string, unknown>;
  if (metadata.contains_face === true) {
    return { safe: false, reason: 'Realistic face reenactment is not allowed' };
  }

  return { safe: true };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const url = new URL(req.url);
    const path = url.pathname;

    if (path.endsWith('/motion-types') && req.method === 'GET') {
      return new Response(
        JSON.stringify({
          types: MOTION_TYPES.map((type) => ({
            id: type,
            name: type
              .split('_')
              .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
              .join(' '),
            description: MOTION_DESCRIPTIONS[type],
          })),
          costs: MOTION_COSTS,
          maxDuration: 10,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/source-images') && req.method === 'GET') {
      const { data: images, error } = await supabase
        .from('generated_images')
        .select('id, image_url, thumbnail_url, prompt, style, created_at')
        .eq('user_id', user.id)
        .eq('status', 'completed')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      return new Response(JSON.stringify({ images: images || [] }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (path.endsWith('/history') && req.method === 'GET') {
      const { data: motions, error } = await supabase
        .from('motion_generations')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      return new Response(JSON.stringify({ motions: motions || [] }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (path.endsWith('/generate') && req.method === 'POST') {
      const body: GenerateMotionRequest = await req.json();
      const { sourceImageId, sourceImageUrl, motionType, duration = 10, isPrivate = true } = body;

      if (!sourceImageId || typeof sourceImageId !== 'string') {
        return new Response(JSON.stringify({ error: 'Source image ID is required' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      if (!validateUUID(sourceImageId)) {
        return new Response(JSON.stringify({ error: 'Invalid source image ID format' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      if (!sourceImageUrl || typeof sourceImageUrl !== 'string') {
        return new Response(JSON.stringify({ error: 'Source image URL is required' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const urlValidation = validateUrl(sourceImageUrl);
      if (!urlValidation.valid) {
        return new Response(JSON.stringify({ error: urlValidation.error }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      if (!MOTION_TYPES.includes(motionType)) {
        return new Response(JSON.stringify({ error: 'Invalid motion type' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const clampedDuration = Math.min(Math.max(Number(duration) || 10, 1), 10);

      const validation = await validateSourceImage(supabase, user.id, sourceImageId);
      if (!validation.valid) {
        return new Response(JSON.stringify({ error: validation.error }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const safetyCheck = await checkSafetyRules(validation.imageData!);
      if (!safetyCheck.safe) {
        return new Response(JSON.stringify({ error: safetyCheck.reason }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { data: profile } = await supabase
        .from('user_profiles')
        .select('cty_balance, plan_type')
        .eq('id', user.id)
        .maybeSingle();

      if (!profile) {
        throw new Error('Profile not found');
      }

      const cost = profile.plan_type === 'creator' ? MOTION_COSTS.premium : MOTION_COSTS.basic;

      if (profile.cty_balance < cost) {
        return new Response(
          JSON.stringify({
            error: 'Insufficient CTY balance',
            required: cost,
            current: profile.cty_balance,
          }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data: motionRecord, error: insertError } = await supabase
        .from('motion_generations')
        .insert({
          user_id: user.id,
          source_image_id: sourceImageId,
          source_image_url: sourceImageUrl,
          motion_type: motionType,
          duration_seconds: clampedDuration,
          format: 'mp4',
          status: 'processing',
          cty_cost: cost,
          is_private: isPrivate,
          metadata: {
            requested_at: new Date().toISOString(),
            plan: profile.plan_type,
            source_prompt: validation.imageData?.prompt,
          },
        })
        .select()
        .single();

      if (insertError) throw insertError;

      const { data: spendResult, error: spendError } = await supabase
        .rpc('spend_cty', {
          p_user_id: user.id,
          p_amount: cost,
          p_description: `Living Image Generation (${motionType})`,
          p_metadata: {
            motion_id: motionRecord.id,
            motion_type: motionType,
            duration: clampedDuration,
          },
        })
        .single();

      if (spendError || !spendResult.success) {
        await supabase.from('motion_generations').delete().eq('id', motionRecord.id);
        return new Response(
          JSON.stringify({ error: spendResult?.error_message || 'Failed to spend CTY' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const placeholderVideoUrl =
        'https://videos.pexels.com/video-files/3571264/3571264-sd_640_360_30fps.mp4';

      await supabase
        .from('motion_generations')
        .update({
          video_url: placeholderVideoUrl,
          thumbnail_url: sourceImageUrl,
          status: 'completed',
          completed_at: new Date().toISOString(),
          metadata: {
            ...motionRecord.metadata,
            completed_at: new Date().toISOString(),
            watermark: 'AI-generated - Cryptinity',
            note: 'Placeholder - integrate real AI video service',
          },
        })
        .eq('id', motionRecord.id);

      return new Response(
        JSON.stringify({
          success: true,
          motion: {
            id: motionRecord.id,
            videoUrl: placeholderVideoUrl,
            thumbnailUrl: sourceImageUrl,
            motionType,
            duration: clampedDuration,
            status: 'completed',
            isPrivate,
            cost,
            watermark: 'AI-generated - Cryptinity',
          },
          newBalance: spendResult.new_balance,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/share') && req.method === 'POST') {
      const body: { motionId: string } = await req.json();
      const { motionId } = body;

      if (!motionId || typeof motionId !== 'string' || !validateUUID(motionId)) {
        return new Response(JSON.stringify({ error: 'Invalid motion ID' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { data: motion, error: fetchError } = await supabase
        .from('motion_generations')
        .select('*')
        .eq('id', motionId)
        .eq('user_id', user.id)
        .maybeSingle();

      if (fetchError || !motion) {
        return new Response(JSON.stringify({ error: 'Motion not found' }), {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      await supabase.from('motion_generations').update({ is_private: false }).eq('id', motionId);

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Route not found' }), {
      status: 404,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error: unknown) {
    console.error('Motion Generator Error:', error);
    const message = error instanceof Error ? error.message : 'Internal server error';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});