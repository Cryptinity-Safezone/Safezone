import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface SpendRequest {
  amount: number;
  description: string;
  metadata?: Record<string, unknown>;
}

interface PurchaseRequest {
  amount: number;
}

interface AdminGrantRequest {
  amount: number;
}

interface TipRequest {
  recipientId: string;
  amount: number;
  message?: string;
  postId?: string;
}

const MAX_AMOUNT = 100000;
const MAX_ADMIN_GRANT = 10000;

function validateAmount(amount: unknown, max: number = MAX_AMOUNT): { valid: boolean; error?: string } {
  if (typeof amount !== 'number' || !Number.isInteger(amount)) {
    return { valid: false, error: 'Amount must be an integer' };
  }
  if (amount <= 0) {
    return { valid: false, error: 'Amount must be positive' };
  }
  if (amount > max) {
    return { valid: false, error: `Amount exceeds maximum of ${max}` };
  }
  return { valid: true };
}

function validateDescription(description: unknown): { valid: boolean; error?: string } {
  if (typeof description !== 'string') {
    return { valid: false, error: 'Description must be a string' };
  }
  if (description.length === 0 || description.length > 500) {
    return { valid: false, error: 'Description must be 1-500 characters' };
  }
  return { valid: true };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const url = new URL(req.url);
    const path = url.pathname;

    if (path.endsWith('/balance')) {
      const { data: profile, error } = await supabase
        .from('user_profiles')
        .select('cty_balance, plan_type')
        .eq('id', user.id)
        .maybeSingle();

      if (error) throw error;

      return new Response(
        JSON.stringify({ balance: profile?.cty_balance || 0, plan: profile?.plan_type || 'free' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/transactions')) {
      const { data: transactions, error } = await supabase
        .from('cty_transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      return new Response(
        JSON.stringify({ transactions }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/spend') && req.method === 'POST') {
      const body: SpendRequest = await req.json();
      const { amount, description, metadata } = body;

      const amountValidation = validateAmount(amount);
      if (!amountValidation.valid) {
        return new Response(
          JSON.stringify({ error: amountValidation.error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const descValidation = validateDescription(description);
      if (!descValidation.valid) {
        return new Response(
          JSON.stringify({ error: descValidation.error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data: result, error: spendError } = await supabase
        .rpc('spend_cty', {
          p_user_id: user.id,
          p_amount: amount,
          p_description: description,
          p_metadata: metadata || {},
        })
        .single();

      if (spendError) throw spendError;

      if (!result.success) {
        return new Response(
          JSON.stringify({ error: result.error_message || 'Insufficient CTY balance' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, newBalance: result.new_balance }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/earn') && req.method === 'POST') {
      const body: SpendRequest = await req.json();
      const { amount, description, metadata } = body;

      const amountValidation = validateAmount(amount);
      if (!amountValidation.valid) {
        return new Response(
          JSON.stringify({ error: amountValidation.error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const descValidation = validateDescription(description);
      if (!descValidation.valid) {
        return new Response(
          JSON.stringify({ error: descValidation.error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data: result, error: earnError } = await supabase
        .rpc('add_cty', {
          p_user_id: user.id,
          p_amount: amount,
          p_description: description,
          p_transaction_type: 'earn',
          p_metadata: metadata || {},
        })
        .single();

      if (earnError) throw earnError;

      if (!result.success) {
        return new Response(
          JSON.stringify({ error: result.error_message }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, newBalance: result.new_balance }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/purchase') && req.method === 'POST') {
      const body: PurchaseRequest = await req.json();
      const { amount } = body;

      const amountValidation = validateAmount(amount);
      if (!amountValidation.valid) {
        return new Response(
          JSON.stringify({ error: amountValidation.error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data: result, error: purchaseError } = await supabase
        .rpc('add_cty', {
          p_user_id: user.id,
          p_amount: amount,
          p_description: `Purchased ${amount} CTY Energy Pack`,
          p_transaction_type: 'purchase',
          p_metadata: {},
        })
        .single();

      if (purchaseError) throw purchaseError;

      if (!result.success) {
        return new Response(
          JSON.stringify({ error: result.error_message }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, newBalance: result.new_balance }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/admin-grant') && req.method === 'POST') {
      const { data: isAdmin } = await supabase
        .rpc('is_admin', { p_user_id: user.id });

      if (!isAdmin) {
        return new Response(
          JSON.stringify({ error: 'Unauthorized - Admin access required' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const body: AdminGrantRequest = await req.json();
      const { amount } = body;

      const amountValidation = validateAmount(amount, MAX_ADMIN_GRANT);
      if (!amountValidation.valid) {
        return new Response(
          JSON.stringify({ error: amountValidation.error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data: result, error: grantError } = await supabase
        .rpc('add_cty', {
          p_user_id: user.id,
          p_amount: amount,
          p_description: 'Admin test grant',
          p_transaction_type: 'admin_grant',
          p_metadata: { reason: 'admin_test_grant', granted_by: user.id },
        })
        .single();

      if (grantError) throw grantError;

      if (!result.success) {
        return new Response(
          JSON.stringify({ error: result.error_message }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, newBalance: result.new_balance }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/tip') && req.method === 'POST') {
      const body: TipRequest = await req.json();
      const { recipientId, amount, message, postId } = body;

      if (!recipientId || typeof recipientId !== 'string') {
        return new Response(
          JSON.stringify({ error: 'Valid recipient ID is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const amountValidation = validateAmount(amount, 1000);
      if (!amountValidation.valid) {
        return new Response(
          JSON.stringify({ error: amountValidation.error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (message && (typeof message !== 'string' || message.length > 200)) {
        return new Response(
          JSON.stringify({ error: 'Tip message must be 200 characters or less' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data: result, error: tipError } = await supabase
        .rpc('transfer_cty', {
          p_sender_id: user.id,
          p_recipient_id: recipientId,
          p_amount: amount,
          p_message: message || null,
          p_post_id: postId || null,
        })
        .single();

      if (tipError) throw tipError;

      if (!result.success) {
        return new Response(
          JSON.stringify({ error: result.error_message }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({
          success: true,
          newBalance: result.sender_new_balance,
          tipId: result.tip_id
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Route not found' }),
      { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    console.error('CTY Manager Error:', error);
    const message = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});