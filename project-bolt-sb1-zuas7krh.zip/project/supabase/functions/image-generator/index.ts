import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface GenerateRequest {
  prompt: string;
  style: string;
  quality: 'standard' | 'high';
  isPrivate: boolean;
}

const PLAN_DAILY_LIMITS: Record<string, number> = {
  free: 5,
  personal: 15,
  creator: 50,
};

const QUALITY_COSTS: Record<string, number> = {
  standard: 25,
  high: 40,
};

const SAFE_STYLES = [
  'abstract',
  'emotional',
  'dreamlike',
  'healing',
  'nature',
  'symbolic',
  'minimal',
  'inner-world',
];

const STYLE_MODIFIERS: Record<string, string> = {
  abstract: 'abstract art, flowing shapes, color gradients, modern minimalist style',
  emotional: 'emotional atmosphere, soft lighting, gentle tones, calm mood',
  dreamlike: 'surreal dreamscape, floating elements, ethereal glow, symbolic imagery',
  healing: 'soft natural light, peaceful scene, gentle colors, serene atmosphere',
  nature: 'natural landscape, organic forms, earth tones, peaceful environment',
  symbolic: 'symbolic imagery, metaphorical elements, meaningful composition',
  minimal: 'minimalist design, clean lines, simple forms, negative space',
  'inner-world': 'introspective visualization, abstract mind representation, flowing energy',
};

const PLACEHOLDER_IMAGES: Record<string, string> = {
  abstract: 'https://images.pexels.com/photos/3109807/pexels-photo-3109807.jpeg?auto=compress&cs=tinysrgb&w=800',
  emotional: 'https://images.pexels.com/photos/3052361/pexels-photo-3052361.jpeg?auto=compress&cs=tinysrgb&w=800',
  dreamlike: 'https://images.pexels.com/photos/1366919/pexels-photo-1366919.jpeg?auto=compress&cs=tinysrgb&w=800',
  healing: 'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=800',
  nature: 'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=800',
  symbolic: 'https://images.pexels.com/photos/2387793/pexels-photo-2387793.jpeg?auto=compress&cs=tinysrgb&w=800',
  minimal: 'https://images.pexels.com/photos/1103970/pexels-photo-1103970.jpeg?auto=compress&cs=tinysrgb&w=800',
  'inner-world': 'https://images.pexels.com/photos/2486168/pexels-photo-2486168.jpeg?auto=compress&cs=tinysrgb&w=800',
};

const MAX_PROMPT_LENGTH = 500;
const MIN_PROMPT_LENGTH = 10;
const REGEX_TIMEOUT_MS = 100;

function safeRegexTest(pattern: string, input: string): boolean {
  const start = Date.now();
  try {
    const safePattern = pattern.substring(0, 200);
    if (/[+*]{2,}|\(\?[^)]*\)|\{\d{3,}/.test(safePattern)) {
      return input.toLowerCase().includes(safePattern.toLowerCase());
    }
    const regex = new RegExp(safePattern, 'i');
    const result = regex.test(input);
    if (Date.now() - start > REGEX_TIMEOUT_MS) {
      console.warn('Regex took too long:', pattern);
    }
    return result;
  } catch {
    return false;
  }
}

async function checkBlockedPatterns(
  supabase: ReturnType<typeof createClient>,
  prompt: string
): Promise<{ blocked: boolean; reason?: string }> {
  const lowerPrompt = prompt.toLowerCase();

  const { data: patterns } = await supabase
    .from('blocked_prompts')
    .select('pattern, pattern_type, category')
    .eq('is_active', true)
    .limit(500);

  if (!patterns) return { blocked: false };

  for (const { pattern, pattern_type, category } of patterns) {
    const lowerPattern = pattern.toLowerCase();
    let matched = false;

    if (pattern_type === 'exact') {
      matched = lowerPrompt === lowerPattern;
    } else if (pattern_type === 'contains') {
      matched = lowerPrompt.includes(lowerPattern);
    } else if (pattern_type === 'regex') {
      matched = safeRegexTest(lowerPattern, lowerPrompt);
    }

    if (matched) {
      const reasons: Record<string, string> = {
        public_figure: 'Prompts referencing celebrities or public figures are not allowed',
        artist_imitation: 'Imitating artist styles is not allowed in SafeZone',
        copyright: 'Copyrighted characters or brands are not allowed',
        brand: 'Brand references are not allowed',
        photoreal_restriction: 'Photorealistic human faces are not allowed by default',
      };
      return { blocked: true, reason: reasons[category] || 'This prompt violates SafeZone guidelines' };
    }
  }

  return { blocked: false };
}

function sanitizePrompt(prompt: string, style: string): string {
  const sanitized = prompt
    .replace(/\b(nsfw|nude|naked|explicit|gore|violence|blood)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();

  const styleModifier = STYLE_MODIFIERS[style] || STYLE_MODIFIERS.abstract;
  return `${sanitized}, ${styleModifier}, artistic digital illustration, no text, no watermarks, safe for work`;
}

async function checkDailyLimit(
  supabase: ReturnType<typeof createClient>,
  userId: string,
  plan: string
): Promise<{ allowed: boolean; used: number; limit: number }> {
  const today = new Date().toISOString().split('T')[0];
  const limit = PLAN_DAILY_LIMITS[plan] || 5;

  const { data: existing } = await supabase
    .from('daily_generation_limits')
    .select('generations_used')
    .eq('user_id', userId)
    .eq('date', today)
    .maybeSingle();

  const used = existing?.generations_used || 0;
  return { allowed: used < limit, used, limit };
}

async function incrementDailyLimit(
  supabase: ReturnType<typeof createClient>,
  userId: string
): Promise<void> {
  const today = new Date().toISOString().split('T')[0];

  const { data: existing } = await supabase
    .from('daily_generation_limits')
    .select('id, generations_used')
    .eq('user_id', userId)
    .eq('date', today)
    .maybeSingle();

  if (existing) {
    await supabase
      .from('daily_generation_limits')
      .update({
        generations_used: existing.generations_used + 1,
        last_generation_at: new Date().toISOString(),
      })
      .eq('id', existing.id);
  } else {
    await supabase.from('daily_generation_limits').insert({
      user_id: userId,
      date: today,
      generations_used: 1,
      last_generation_at: new Date().toISOString(),
    });
  }
}

function validatePrompt(prompt: unknown): { valid: boolean; error?: string } {
  if (typeof prompt !== 'string') {
    return { valid: false, error: 'Prompt must be a string' };
  }
  if (prompt.trim().length < MIN_PROMPT_LENGTH) {
    return { valid: false, error: `Prompt must be at least ${MIN_PROMPT_LENGTH} characters` };
  }
  if (prompt.length > MAX_PROMPT_LENGTH) {
    return { valid: false, error: `Prompt must be under ${MAX_PROMPT_LENGTH} characters` };
  }
  return { valid: true };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const url = new URL(req.url);
    const path = url.pathname;

    if (path.endsWith('/limits') && req.method === 'GET') {
      const { data: profile } = await supabase
        .from('user_profiles')
        .select('plan_type')
        .eq('id', user.id)
        .maybeSingle();

      const plan = profile?.plan_type || 'free';
      const limitInfo = await checkDailyLimit(supabase, user.id, plan);

      return new Response(
        JSON.stringify({
          used: limitInfo.used,
          limit: limitInfo.limit,
          remaining: limitInfo.limit - limitInfo.used,
          plan,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/history') && req.method === 'GET') {
      const { data: images, error } = await supabase
        .from('generated_images')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      return new Response(JSON.stringify({ images }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (path.endsWith('/generate') && req.method === 'POST') {
      const body: GenerateRequest = await req.json();
      const { prompt, style, quality, isPrivate } = body;

      const promptValidation = validatePrompt(prompt);
      if (!promptValidation.valid) {
        return new Response(JSON.stringify({ error: promptValidation.error }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const selectedStyle = SAFE_STYLES.includes(style) ? style : 'abstract';
      const selectedQuality = quality === 'high' ? 'high' : 'standard';
      const cost = QUALITY_COSTS[selectedQuality];

      const blockCheck = await checkBlockedPatterns(supabase, prompt);
      if (blockCheck.blocked) {
        return new Response(JSON.stringify({ error: blockCheck.reason }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { data: profile } = await supabase
        .from('user_profiles')
        .select('cty_balance, plan_type')
        .eq('id', user.id)
        .maybeSingle();

      if (!profile) {
        throw new Error('Profile not found');
      }

      if (selectedQuality === 'high' && profile.plan_type === 'free') {
        return new Response(
          JSON.stringify({ error: 'High quality generation requires Personal or Creator plan' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (profile.cty_balance < cost) {
        return new Response(
          JSON.stringify({ error: 'Insufficient CTY balance', required: cost, current: profile.cty_balance }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const limitCheck = await checkDailyLimit(supabase, user.id, profile.plan_type);
      if (!limitCheck.allowed) {
        return new Response(
          JSON.stringify({
            error: 'Daily generation limit reached',
            used: limitCheck.used,
            limit: limitCheck.limit,
          }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const sanitizedPrompt = sanitizePrompt(prompt, selectedStyle);

      const { data: genRecord, error: insertError } = await supabase
        .from('generated_images')
        .insert({
          user_id: user.id,
          prompt: prompt.trim(),
          sanitized_prompt: sanitizedPrompt,
          style: selectedStyle,
          quality: selectedQuality,
          is_private: isPrivate !== false,
          cty_cost: cost,
          status: 'generating',
          generation_metadata: {
            requested_at: new Date().toISOString(),
            plan: profile.plan_type,
          },
        })
        .select()
        .single();

      if (insertError) throw insertError;

      const { data: spendResult, error: spendError } = await supabase
        .rpc('spend_cty', {
          p_user_id: user.id,
          p_amount: cost,
          p_description: `AI Image Generation (${selectedQuality})`,
          p_metadata: { generation_id: genRecord.id, style: selectedStyle },
        })
        .single();

      if (spendError || !spendResult.success) {
        await supabase.from('generated_images').delete().eq('id', genRecord.id);
        return new Response(
          JSON.stringify({ error: spendResult?.error_message || 'Failed to spend CTY' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      await incrementDailyLimit(supabase, user.id);

      const placeholderUrl = PLACEHOLDER_IMAGES[selectedStyle] || PLACEHOLDER_IMAGES.abstract;

      await supabase
        .from('generated_images')
        .update({
          image_url: placeholderUrl,
          thumbnail_url: placeholderUrl,
          status: 'completed',
          generation_metadata: {
            ...genRecord.generation_metadata,
            completed_at: new Date().toISOString(),
            mode: 'demo',
          },
        })
        .eq('id', genRecord.id);

      return new Response(
        JSON.stringify({
          success: true,
          generation: {
            id: genRecord.id,
            imageUrl: placeholderUrl,
            thumbnailUrl: placeholderUrl,
            status: 'completed',
            style: selectedStyle,
            quality: selectedQuality,
            isPrivate: isPrivate !== false,
            cost,
          },
          newBalance: spendResult.new_balance,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/share') && req.method === 'POST') {
      const body: { generationId: string } = await req.json();
      const { generationId } = body;

      if (!generationId || typeof generationId !== 'string') {
        return new Response(JSON.stringify({ error: 'Invalid generation ID' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { data: gen, error: fetchError } = await supabase
        .from('generated_images')
        .select('*')
        .eq('id', generationId)
        .eq('user_id', user.id)
        .maybeSingle();

      if (fetchError || !gen) {
        return new Response(JSON.stringify({ error: 'Generation not found' }), {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { error: updateError } = await supabase
        .from('generated_images')
        .update({ is_private: false, is_shared: true })
        .eq('id', generationId);

      if (updateError) throw updateError;

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Route not found' }), {
      status: 404,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error: unknown) {
    console.error('Image Generator Error:', error);
    const message = error instanceof Error ? error.message : 'Internal server error';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});