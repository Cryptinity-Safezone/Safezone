import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const ALLOWED_MIME_TYPES = {
  video: ["video/mp4"],
  image: ["image/png", "image/jpeg"],
  audio: ["audio/mpeg"],
};

const ALL_ALLOWED_TYPES = [
  ...ALLOWED_MIME_TYPES.video,
  ...ALLOWED_MIME_TYPES.image,
  ...ALLOWED_MIME_TYPES.audio,
];

const PLAN_VIDEO_LIMITS: Record<string, number> = {
  free: 10,
  personal: 25,
  creator: 45,
};

const MAX_FILE_SIZE = {
  video: 10 * 1024 * 1024,
  audio: 10 * 1024 * 1024,
  image: 10 * 1024 * 1024,
};

function sanitizeFilename(filename: string): string {
  const ext = filename.split(".").pop()?.toLowerCase() || "mp4";
  const baseName = filename
    .replace(/\.[^/.]+$/, "")
    .replace(/[^a-zA-Z0-9_-]/g, "_")
    .substring(0, 50);
  return `${baseName}.${ext}`;
}

function getFileCategory(mimeType: string): "video" | "image" | "audio" | null {
  if (ALLOWED_MIME_TYPES.video.includes(mimeType)) return "video";
  if (ALLOWED_MIME_TYPES.image.includes(mimeType)) return "image";
  if (ALLOWED_MIME_TYPES.audio.includes(mimeType)) return "audio";
  return null;
}

function errorResponse(message: string, status: number = 400) {
  return new Response(
    JSON.stringify({ error: message }),
    {
      status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    }
  );
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return errorResponse("Missing authorization header", 401);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return errorResponse("Unauthorized", 401);
    }

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    const { data: profile, error: profileError } = await adminClient
      .from("user_profiles")
      .select("plan_type")
      .eq("id", user.id)
      .maybeSingle();

    if (profileError) {
      return errorResponse("Could not fetch user profile", 500);
    }

    const planType = profile?.plan_type || "free";
    const maxVideoDuration = PLAN_VIDEO_LIMITS[planType] || PLAN_VIDEO_LIMITS.free;

    let formData: FormData;
    try {
      formData = await req.formData();
    } catch (e) {
      return errorResponse("Invalid form data", 400);
    }

    const file = formData.get("file") as File | null;
    const durationStr = formData.get("duration") as string | null;

    if (!file) {
      return errorResponse("No file provided");
    }

    const mimeType = file.type;
    if (!ALL_ALLOWED_TYPES.includes(mimeType)) {
      return errorResponse(
        "Video format not supported. Allowed formats: MP4 (video), PNG/JPEG (image), MP3 (audio)"
      );
    }

    const category = getFileCategory(mimeType);
    if (!category) {
      return errorResponse("File type not recognized");
    }

    const maxSize = MAX_FILE_SIZE[category];
    if (file.size > maxSize) {
      const maxSizeMB = Math.round(maxSize / 1024 / 1024);
      return errorResponse(`File size too large. Maximum size is ${maxSizeMB}MB`);
    }

    if (file.size < 1024) {
      return errorResponse("File too small or corrupted");
    }

    let duration: number | null = null;

    if (category === "video" || category === "audio") {
      if (!durationStr) {
        return errorResponse("Duration is required for video/audio uploads");
      }

      duration = parseFloat(durationStr);
      if (isNaN(duration) || duration <= 0) {
        return errorResponse("Invalid duration provided");
      }

      if (duration > 300) {
        return errorResponse("Duration cannot exceed 5 minutes");
      }

      if (category === "video" && duration > maxVideoDuration) {
        const planName = planType.charAt(0).toUpperCase() + planType.slice(1);
        return errorResponse(
          `Video exceeds plan limit. ${planName} plan allows up to ${maxVideoDuration} seconds. Upgrade for longer videos.`
        );
      }
    }

    const timestamp = Date.now();
    const randomSuffix = Math.random().toString(36).substring(2, 8);
    const sanitizedName = sanitizeFilename(file.name);
    const storagePath = `${user.id}/${timestamp}_${randomSuffix}_${sanitizedName}`;

    const bucket = category === "video" ? "videos" : category === "audio" ? "warehouse" : "posts";

    let fileBuffer: ArrayBuffer;
    try {
      fileBuffer = await file.arrayBuffer();
    } catch (e) {
      return errorResponse("Failed to read file data", 400);
    }

    const { error: uploadError } = await adminClient.storage
      .from(bucket)
      .upload(storagePath, fileBuffer, {
        contentType: mimeType,
        upsert: false,
      });

    if (uploadError) {
      console.error("Upload error:", uploadError);
      return errorResponse(`Upload failed: ${uploadError.message}`, 500);
    }

    const { data: { publicUrl } } = adminClient.storage
      .from(bucket)
      .getPublicUrl(storagePath);

    if (category === "video" && duration) {
      const { error: metaError } = await adminClient
        .from("video_uploads")
        .insert({
          user_id: user.id,
          video_url: publicUrl,
          storage_path: storagePath,
          duration: duration,
          file_size: file.size,
          mime_type: mimeType,
          is_ai_generated: false,
        });

      if (metaError) {
        console.error("Metadata insert error:", metaError);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        url: publicUrl,
        path: storagePath,
        bucket,
        category,
        duration,
        fileSize: file.size,
        mimeType,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Video upload error:", error);
    const message = error instanceof Error ? error.message : "An unexpected error occurred";
    return errorResponse(message, 500);
  }
});