import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useCTY } from './useCTY';
import { CTY_COSTS } from '../lib/cty-costs';

export const AMBIENT_SOUNDSCAPE_TYPES = [
  { id: 'deep_ocean', name: 'Deep Ocean', description: 'Underwater currents and distant whale songs' },
  { id: 'cosmic_drift', name: 'Cosmic Drift', description: 'Ethereal space ambience and stellar winds' },
  { id: 'rainforest', name: 'Rainforest', description: 'Gentle rain, rustling leaves, and distant thunder' },
  { id: 'crystal_caves', name: 'Crystal Caves', description: 'Resonant tones and dripping water echoes' },
  { id: 'aurora_winds', name: 'Aurora Winds', description: 'Northern lights translated to harmonic drones' },
  { id: 'zen_garden', name: 'Zen Garden', description: 'Bamboo fountains and wind through grass' },
] as const;

export type SoundscapeType = typeof AMBIENT_SOUNDSCAPE_TYPES[number]['id'];

interface AIGeneratedSound {
  id: string;
  user_id: string;
  name: string;
  soundscape_type: string;
  parameters: Record<string, unknown>;
  duration_seconds: number;
  is_private: boolean;
  cty_cost: number;
  created_at: string;
}

interface GenerationParams {
  soundscapeType: SoundscapeType;
  duration: 'short' | 'extended';
  name?: string;
}

export function useAISounds() {
  const { user } = useAuth();
  const { balance, spend } = useCTY();
  const [sounds, setSounds] = useState<AIGeneratedSound[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSounds = useCallback(async () => {
    if (!user) {
      setSounds([]);
      setLoading(false);
      return;
    }

    try {
      const { data, error: fetchError } = await supabase
        .from('ai_generated_sounds')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setSounds(data || []);
    } catch (err) {
      console.error('Failed to fetch AI sounds:', err);
      setError('Failed to load your generated sounds');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchSounds();
  }, [fetchSounds]);

  const generateSound = useCallback(async (params: GenerationParams): Promise<AIGeneratedSound | null> => {
    if (!user) {
      setError('You must be logged in to generate sounds');
      return null;
    }

    const cost = params.duration === 'extended'
      ? CTY_COSTS.AI_GENERATION.AMBIENT_EXTENDED
      : CTY_COSTS.AI_GENERATION.AMBIENT_BASIC;

    if (balance < cost) {
      setError(`Insufficient CTY balance. Need ${cost} CTY.`);
      return null;
    }

    setGenerating(true);
    setError(null);

    try {
      const spent = await spend(cost, `AI ambient sound generation: ${params.soundscapeType}`);
      if (!spent) {
        throw new Error('Failed to process CTY payment');
      }

      const durationSeconds = params.duration === 'extended' ? 120 : 30;
      const soundscapeInfo = AMBIENT_SOUNDSCAPE_TYPES.find(s => s.id === params.soundscapeType);
      const defaultName = soundscapeInfo ? `${soundscapeInfo.name} Soundscape` : 'AI Soundscape';

      const { data, error: insertError } = await supabase
        .from('ai_generated_sounds')
        .insert({
          user_id: user.id,
          name: params.name || defaultName,
          soundscape_type: params.soundscapeType,
          parameters: {
            duration: params.duration,
            generated_at: new Date().toISOString(),
          },
          duration_seconds: durationSeconds,
          is_private: true,
          cty_cost: cost,
        })
        .select()
        .single();

      if (insertError) throw insertError;

      setSounds(prev => [data, ...prev]);
      return data;
    } catch (err) {
      console.error('Failed to generate sound:', err);
      setError('Failed to generate sound. Please try again.');
      return null;
    } finally {
      setGenerating(false);
    }
  }, [user, balance, spend]);

  const deleteSound = useCallback(async (soundId: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const { error: deleteError } = await supabase
        .from('ai_generated_sounds')
        .delete()
        .eq('id', soundId)
        .eq('user_id', user.id);

      if (deleteError) throw deleteError;

      setSounds(prev => prev.filter(s => s.id !== soundId));
      return true;
    } catch (err) {
      console.error('Failed to delete sound:', err);
      setError('Failed to delete sound');
      return false;
    }
  }, [user]);

  const updateSoundName = useCallback(async (soundId: string, name: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const { error: updateError } = await supabase
        .from('ai_generated_sounds')
        .update({ name })
        .eq('id', soundId)
        .eq('user_id', user.id);

      if (updateError) throw updateError;

      setSounds(prev => prev.map(s => s.id === soundId ? { ...s, name } : s));
      return true;
    } catch (err) {
      console.error('Failed to update sound name:', err);
      return false;
    }
  }, [user]);

  const getCost = useCallback((duration: 'short' | 'extended') => {
    return duration === 'extended'
      ? CTY_COSTS.AI_GENERATION.AMBIENT_EXTENDED
      : CTY_COSTS.AI_GENERATION.AMBIENT_BASIC;
  }, []);

  return {
    sounds,
    loading,
    generating,
    error,
    generateSound,
    deleteSound,
    updateSoundName,
    getCost,
    clearError: () => setError(null),
  };
}
