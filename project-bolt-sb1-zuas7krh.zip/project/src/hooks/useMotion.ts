import { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { CTY_COSTS } from '../lib/cty-costs';

interface MotionType {
  id: string;
  name: string;
  description: string;
}

interface SourceImage {
  id: string;
  image_url: string;
  thumbnail_url: string;
  prompt: string;
  style: string;
  created_at: string;
}

interface MotionGeneration {
  id: string;
  source_image_id: string;
  source_image_url: string;
  motion_type: string;
  video_url: string | null;
  thumbnail_url: string | null;
  duration_seconds: number;
  format: string;
  status: string;
  cty_cost: number;
  is_private: boolean;
  created_at: string;
  completed_at: string | null;
}

interface GenerateMotionParams {
  sourceImageId: string;
  sourceImageUrl: string;
  motionType: string;
  duration?: number;
  isPrivate?: boolean;
}

export function useMotion() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sourceImages, setSourceImages] = useState<SourceImage[]>([]);
  const [motionHistory, setMotionHistory] = useState<MotionGeneration[]>([]);
  const [motionTypes] = useState<MotionType[]>([
    { id: 'breathing', name: 'Subtle Breathing', description: 'Gentle expansion and contraction effect' },
    { id: 'drift', name: 'Light Drift', description: 'Slow ambient drifting motion' },
    { id: 'hair_cloth', name: 'Hair & Cloth', description: 'Natural fabric and hair movement' },
    { id: 'particles', name: 'Particles', description: 'Animated stars, dust, or floating elements' },
    { id: 'camera_pan', name: 'Camera Pan', description: 'Gentle camera movement or zoom' },
  ]);

  const fetchSourceImages = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/motion-generator/source-images`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to fetch images');

      setSourceImages(data.images || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchMotionHistory = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/motion-generator/history`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to fetch history');

      setMotionHistory(data.motions || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const generateMotion = useCallback(async (params: GenerateMotionParams) => {
    setLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/motion-generator/generate`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(params),
        }
      );

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to generate motion');

      await fetchMotionHistory();
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [fetchMotionHistory]);

  const shareMotion = useCallback(async (motionId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/motion-generator/share`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ motionId }),
        }
      );

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to share motion');

      await fetchMotionHistory();
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, [fetchMotionHistory]);

  const getMotionCost = useCallback((planType: string = 'free') => {
    return planType === 'creator'
      ? CTY_COSTS.AI_GENERATION.MOTION_PREMIUM
      : CTY_COSTS.AI_GENERATION.MOTION_BASIC;
  }, []);

  return {
    loading,
    error,
    sourceImages,
    motionHistory,
    motionTypes,
    fetchSourceImages,
    fetchMotionHistory,
    generateMotion,
    shareMotion,
    getMotionCost,
  };
}
