import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { storage } from '../lib/storage';

interface UpdateProfileData {
  username?: string;
  handle?: string;
  bio?: string;
  avatar_url?: string;
  cover_url?: string;
  interests?: string[];
  background_music_title?: string;
  background_music_artist?: string;
  background_music_url?: string;
}

export function useProfile(userId?: string) {
  const { user, profile: currentUserProfile, refreshProfile } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const targetUserId = userId || user?.id;
  const isOwnProfile = !userId || userId === user?.id;

  useEffect(() => {
    if (isOwnProfile && currentUserProfile) {
      setProfile(currentUserProfile);
      setLoading(false);
      return;
    }

    if (targetUserId) {
      fetchProfile();
      checkFollowStatus();
    }
  }, [targetUserId, isOwnProfile, currentUserProfile]);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', targetUserId)
        .maybeSingle();

      if (error) throw error;
      setProfile(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const checkFollowStatus = async () => {
    if (!user || !targetUserId || isOwnProfile) return;

    try {
      const { data } = await supabase
        .from('follows')
        .select('id')
        .eq('follower_id', user.id)
        .eq('following_id', targetUserId)
        .maybeSingle();

      setIsFollowing(!!data);
    } catch (err) {
      console.error('Error checking follow status:', err);
    }
  };

  const toggleFollow = async () => {
    if (!user || !targetUserId || isOwnProfile) return;

    try {
      if (isFollowing) {
        await supabase
          .from('follows')
          .delete()
          .eq('follower_id', user.id)
          .eq('following_id', targetUserId);

        await Promise.all([
          supabase
            .from('user_profiles')
            .update({ followers_count: Math.max(0, (profile?.followers_count || 0) - 1) })
            .eq('id', targetUserId),
          supabase
            .from('user_profiles')
            .update({ following_count: Math.max(0, (currentUserProfile?.following_count || 0) - 1) })
            .eq('id', user.id),
        ]);

        setIsFollowing(false);
        if (profile) {
          setProfile({ ...profile, followers_count: Math.max(0, profile.followers_count - 1) });
        }
      } else {
        await supabase
          .from('follows')
          .insert({ follower_id: user.id, following_id: targetUserId });

        await Promise.all([
          supabase
            .from('user_profiles')
            .update({ followers_count: (profile?.followers_count || 0) + 1 })
            .eq('id', targetUserId),
          supabase
            .from('user_profiles')
            .update({ following_count: (currentUserProfile?.following_count || 0) + 1 })
            .eq('id', user.id),
        ]);

        setIsFollowing(true);
        if (profile) {
          setProfile({ ...profile, followers_count: profile.followers_count + 1 });
        }
      }

      await refreshProfile();
    } catch (err: any) {
      console.error('Error toggling follow:', err);
      throw err;
    }
  };

  const updateProfile = async (updates: UpdateProfileData) => {
    if (!user) throw new Error('Must be authenticated');

    try {
      const { error } = await supabase
        .from('user_profiles')
        .update(updates)
        .eq('id', user.id);

      if (error) throw error;

      await refreshProfile();
    } catch (err: any) {
      console.error('Error updating profile:', err);
      throw err;
    }
  };

  const uploadAvatar = useCallback(async (file: File) => {
    if (!user) throw new Error('Must be authenticated');

    try {
      const { url } = await storage.uploadFile('avatars', user.id, file, 'avatar');

      const { error } = await supabase
        .from('user_profiles')
        .update({ avatar_url: url })
        .eq('id', user.id);

      if (error) throw error;

      await refreshProfile();
    } catch (err: any) {
      console.error('Error uploading avatar:', err);
      throw err;
    }
  }, [user, refreshProfile]);

  const uploadCover = useCallback(async (file: File) => {
    if (!user) throw new Error('Must be authenticated');

    try {
      const { url } = await storage.uploadFile('covers', user.id, file, 'cover');

      const { error } = await supabase
        .from('user_profiles')
        .update({ cover_url: url })
        .eq('id', user.id);

      if (error) throw error;

      await refreshProfile();
    } catch (err: any) {
      console.error('Error uploading cover:', err);
      throw err;
    }
  }, [user, refreshProfile]);

  const removeAvatar = useCallback(async () => {
    if (!user) throw new Error('Must be authenticated');

    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({ avatar_url: null })
        .eq('id', user.id);

      if (error) throw error;

      await refreshProfile();
    } catch (err: any) {
      console.error('Error removing avatar:', err);
      throw err;
    }
  }, [user, refreshProfile]);

  const removeCover = useCallback(async () => {
    if (!user) throw new Error('Must be authenticated');

    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({ cover_url: null })
        .eq('id', user.id);

      if (error) throw error;

      await refreshProfile();
    } catch (err: any) {
      console.error('Error removing cover:', err);
      throw err;
    }
  }, [user, refreshProfile]);

  return {
    profile,
    isFollowing,
    loading,
    error,
    isOwnProfile,
    toggleFollow,
    updateProfile,
    uploadAvatar,
    uploadCover,
    removeAvatar,
    removeCover,
    refresh: fetchProfile,
  };
}
