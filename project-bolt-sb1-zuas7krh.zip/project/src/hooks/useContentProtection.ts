import { useState, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';

interface ContentProtectionState {
  isAIGenerated: boolean;
  isWatermarked: boolean;
  hasUnlocked: boolean;
  creatorId?: string;
}

const UNLOCKED_CONTENT_KEY = 'cryptinity_unlocked_content';

function getUnlockedContent(): Set<string> {
  try {
    const stored = localStorage.getItem(UNLOCKED_CONTENT_KEY);
    return stored ? new Set(JSON.parse(stored)) : new Set();
  } catch {
    return new Set();
  }
}

function saveUnlockedContent(contentIds: Set<string>): void {
  localStorage.setItem(UNLOCKED_CONTENT_KEY, JSON.stringify([...contentIds]));
}

export function useContentProtection() {
  const { user } = useAuth();
  const [unlockedContent, setUnlockedContent] = useState<Set<string>>(getUnlockedContent);

  const checkContentStatus = useCallback((
    contentUrl: string,
    isAIGenerated: boolean,
    creatorId?: string
  ): ContentProtectionState => {
    const isCreator = user?.id === creatorId;
    const hasUnlocked = unlockedContent.has(contentUrl) || isCreator;

    return {
      isAIGenerated,
      isWatermarked: isAIGenerated && !hasUnlocked,
      hasUnlocked,
      creatorId,
    };
  }, [user, unlockedContent]);

  const unlockContent = useCallback((
    contentUrl: string,
    reason: 'creator_download' | 'marketplace_sale' | 'buyer_unlock'
  ): void => {
    const updated = new Set(unlockedContent);
    updated.add(contentUrl);
    setUnlockedContent(updated);
    saveUnlockedContent(updated);
  }, [unlockedContent]);

  const isUnlocked = useCallback((contentUrl: string): boolean => {
    return unlockedContent.has(contentUrl);
  }, [unlockedContent]);

  const getAudioMetadata = useCallback((isAIGenerated: boolean): Record<string, string> => {
    if (!isAIGenerated) return {};
    return {
      generator: 'Cryptinity AI',
      copyright: 'Generated via Cryptinity AI',
      comment: 'This audio was generated using Cryptinity AI tools.',
    };
  }, []);

  return {
    checkContentStatus,
    unlockContent,
    isUnlocked,
    getAudioMetadata,
  };
}
