import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export interface Report {
  id: string;
  reason: string;
  details: string | null;
  status: string;
  created_at: string;
  type: 'post' | 'message';
  post?: {
    content: string;
  };
  conversation?: {
    id: string;
  };
}

export function useReports() {
  const { user } = useAuth();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadReports();
    }
  }, [user]);

  const loadReports = async () => {
    try {
      const [postReports, messageReports] = await Promise.all([
        supabase
          .from('post_reports')
          .select(`
            id,
            reason,
            details,
            status,
            created_at,
            post:posts(content)
          `)
          .eq('reporter_id', user!.id)
          .order('created_at', { ascending: false }),
        supabase
          .from('message_reports')
          .select(`
            id,
            reason,
            details,
            status,
            created_at,
            conversation:conversations(id)
          `)
          .eq('reporter_id', user!.id)
          .order('created_at', { ascending: false })
      ]);

      const allReports: Report[] = [
        ...(postReports.data || []).map(r => ({ ...r, type: 'post' as const })),
        ...(messageReports.data || []).map(r => ({ ...r, type: 'message' as const }))
      ].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

      setReports(allReports);
    } catch (error) {
      console.error('Error loading reports:', error);
    } finally {
      setLoading(false);
    }
  };

  return {
    reports,
    loading,
    refreshReports: loadReports
  };
}
