import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export interface GardenSettings {
  id: string;
  background_image: string;
  background_motion: boolean;
  color_mood: 'dark' | 'calm' | 'green' | 'night';
  pinned_content: string | null;
  pinned_type: 'quote' | 'message' | 'reflection' | 'question' | 'reminder' | null;
  pinned_at: string | null;
  pinned_by: string | null;
}

export interface DailyQuestion {
  id: string;
  question: string;
  active_date: string;
}

export interface UserState {
  id: string;
  user_id: string;
  answer_date: string;
  answer: string | null;
  question_id: string | null;
  edit_count: number;
  is_muted: boolean;
  muted_until: string | null;
  muted_reason: string | null;
}

export interface GardenMessage {
  id: string;
  user_id: string;
  content: string;
  is_reflection: boolean;
  created_at: string;
  user?: {
    username: string;
    avatar_url: string | null;
    handle: string;
  };
  user_answer?: string | null;
  reactions?: MessageReaction[];
}

export interface MessageReaction {
  reaction: 'heart' | 'leaf' | 'star' | 'peace' | 'hug';
  count: number;
  user_reacted: boolean;
}

export interface GardenMusic {
  id: string;
  title: string;
  mood: string;
  duration: number;
  audio_url: string;
  is_ai_generated: boolean;
  is_active: boolean;
  loop_enabled: boolean;
  volume: number;
}

export interface GardenTheme {
  id: string;
  name: string;
  background_gradient: string;
  mood_color: string;
  description: string;
  sort_order: number;
}

export interface GardenQuestion {
  id: string;
  theme_id: string;
  question: string;
  day_number: number;
}

export interface GardenTrack {
  id: string;
  theme_id: string;
  track_name: string;
  track_url: string;
  duration_seconds: number;
}

export interface AutomationState {
  theme: GardenTheme | null;
  question: GardenQuestion | null;
  track: GardenTrack | null;
  track_paused: boolean;
  overrides: {
    theme: boolean;
    question: boolean;
    track: boolean;
  };
  meta: {
    theme_days_remaining: number;
    theme_started_at: string;
    question_changed_at: string;
    track_changed_at: string;
  };
}

export function useHiddenGarden() {
  const { user, session } = useAuth();
  const [settings, setSettings] = useState<GardenSettings | null>(null);
  const [dailyQuestion, setDailyQuestion] = useState<DailyQuestion | null>(null);
  const [userState, setUserState] = useState<UserState | null>(null);
  const [messages, setMessages] = useState<GardenMessage[]>([]);
  const [activeMusic, setActiveMusic] = useState<GardenMusic | null>(null);
  const [allMusic, setAllMusic] = useState<GardenMusic[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  const [automation, setAutomation] = useState<AutomationState | null>(null);
  const [allThemes, setAllThemes] = useState<GardenTheme[]>([]);
  const [automationLoading, setAutomationLoading] = useState(true);

  const loadAutomation = useCallback(async () => {
    if (!session?.access_token) return;

    try {
      setAutomationLoading(true);
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/garden-automation`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      if (!response.ok) {
        throw new Error('Failed to load automation state');
      }

      const data = await response.json();

      if (data.success) {
        setAutomation(data.state);
        setAllThemes(data.all_themes || []);
      }
    } catch (err) {
      console.error('Error loading automation:', err);
    } finally {
      setAutomationLoading(false);
    }
  }, [session]);

  const loadSettings = useCallback(async () => {
    const { data, error } = await supabase
      .from('hidden_garden_settings')
      .select('*')
      .eq('id', '00000000-0000-0000-0000-000000000001')
      .maybeSingle();

    if (error) {
      console.error('Error loading garden settings:', error);
      return;
    }
    setSettings(data);
  }, []);

  const loadDailyQuestion = useCallback(async () => {
    const today = new Date().toISOString().split('T')[0];

    let { data, error } = await supabase
      .from('hidden_garden_daily_questions')
      .select('*')
      .eq('active_date', today)
      .maybeSingle();

    if (!data) {
      const defaultQuestions = [
        'How are you feeling today?',
        'Why are you here right now?',
        'What\'s heavy on your mind?',
        'One word for your mood?',
        'What do you need most right now?',
        'What brought you peace today?',
        'What are you grateful for?'
      ];
      const dayIndex = new Date().getDay();

      const { data: newData, error: insertError } = await supabase
        .from('hidden_garden_daily_questions')
        .insert({
          question: defaultQuestions[dayIndex],
          active_date: today,
          is_auto_generated: true
        })
        .select()
        .maybeSingle();

      if (insertError && !insertError.message.includes('duplicate')) {
        console.error('Error creating daily question:', insertError);
      }
      data = newData;
    }

    if (error && !error.message.includes('duplicate')) {
      console.error('Error loading daily question:', error);
    }

    setDailyQuestion(data);
    return data;
  }, []);

  const loadUserState = useCallback(async () => {
    if (!user) return null;

    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('hidden_garden_user_state')
      .select('*')
      .eq('user_id', user.id)
      .eq('answer_date', today)
      .maybeSingle();

    if (error) {
      console.error('Error loading user state:', error);
      return null;
    }

    setUserState(data);
    return data;
  }, [user]);

  const submitAnswer = useCallback(async (answer: string, questionId: string) => {
    if (!user) return { error: 'Not authenticated' };

    const today = new Date().toISOString().split('T')[0];

    const existing = await loadUserState();

    if (existing) {
      if (existing.edit_count >= 1) {
        return { error: 'You can only edit your answer once per day' };
      }

      const { data, error } = await supabase
        .from('hidden_garden_user_state')
        .update({
          answer,
          edit_count: existing.edit_count + 1,
          updated_at: new Date().toISOString()
        })
        .eq('id', existing.id)
        .select()
        .single();

      if (error) return { error: error.message };
      setUserState(data);
      return { data };
    }

    const { data, error } = await supabase
      .from('hidden_garden_user_state')
      .insert({
        user_id: user.id,
        answer_date: today,
        answer,
        question_id: questionId
      })
      .select()
      .single();

    if (error) return { error: error.message };
    setUserState(data);
    return { data };
  }, [user, loadUserState]);

  const loadMessages = useCallback(async (limit = 50) => {
    const { data, error } = await supabase
      .from('hidden_garden_messages')
      .select(`
        *,
        user:user_profiles!hidden_garden_messages_user_id_fkey(username, avatar_url, handle)
      `)
      .eq('is_removed', false)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Error loading messages:', error);
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    const userIds = [...new Set((data || []).map(m => m.user_id))];

    const { data: userStates } = await supabase
      .from('hidden_garden_user_state')
      .select('user_id, answer')
      .in('user_id', userIds)
      .eq('answer_date', today);

    const stateMap = new Map(userStates?.map(s => [s.user_id, s.answer]) || []);

    const { data: reactions } = await supabase
      .from('hidden_garden_reactions')
      .select('message_id, reaction, user_id')
      .in('message_id', (data || []).map(m => m.id));

    const messagesWithData = (data || []).map(msg => {
      const msgReactions = reactions?.filter(r => r.message_id === msg.id) || [];
      const reactionCounts: Record<string, { count: number; user_reacted: boolean }> = {};

      msgReactions.forEach(r => {
        if (!reactionCounts[r.reaction]) {
          reactionCounts[r.reaction] = { count: 0, user_reacted: false };
        }
        reactionCounts[r.reaction].count++;
        if (r.user_id === user?.id) {
          reactionCounts[r.reaction].user_reacted = true;
        }
      });

      return {
        ...msg,
        user_answer: stateMap.get(msg.user_id) || null,
        reactions: Object.entries(reactionCounts).map(([reaction, data]) => ({
          reaction: reaction as MessageReaction['reaction'],
          ...data
        }))
      };
    });

    setMessages(messagesWithData.reverse());
  }, [user]);

  const sendMessage = useCallback(async (content: string, isReflection = false) => {
    if (!user || !userState?.answer) {
      return { error: 'Must answer daily question first' };
    }

    if (userState.is_muted) {
      const mutedUntil = userState.muted_until ? new Date(userState.muted_until) : null;
      if (!mutedUntil || mutedUntil > new Date()) {
        return { error: `You are muted${userState.muted_reason ? `: ${userState.muted_reason}` : ''}` };
      }
    }

    const { data, error } = await supabase
      .from('hidden_garden_messages')
      .insert({
        user_id: user.id,
        content: content.trim(),
        is_reflection: isReflection
      })
      .select(`
        *,
        user:user_profiles!hidden_garden_messages_user_id_fkey(username, avatar_url, handle)
      `)
      .single();

    if (error) {
      if (error.message.includes('rate limited') || error.message.includes('muted')) {
        return { error: 'Sending too fast. Please wait a moment.' };
      }
      return { error: error.message };
    }

    const newMessage = {
      ...data,
      user_answer: userState.answer,
      reactions: []
    };

    setMessages(prev => [...prev, newMessage]);
    return { data: newMessage };
  }, [user, userState]);

  const toggleReaction = useCallback(async (messageId: string, reaction: MessageReaction['reaction']) => {
    if (!user) return;

    const { data: existing } = await supabase
      .from('hidden_garden_reactions')
      .select('id')
      .eq('message_id', messageId)
      .eq('user_id', user.id)
      .eq('reaction', reaction)
      .maybeSingle();

    if (existing) {
      await supabase
        .from('hidden_garden_reactions')
        .delete()
        .eq('id', existing.id);
    } else {
      await supabase
        .from('hidden_garden_reactions')
        .insert({
          message_id: messageId,
          user_id: user.id,
          reaction
        });
    }

    loadMessages();
  }, [user, loadMessages]);

  const loadMusic = useCallback(async () => {
    const { data, error } = await supabase
      .from('hidden_garden_music')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading music:', error);
      return;
    }

    setAllMusic(data || []);
    const active = data?.find(m => m.is_active);
    setActiveMusic(active || null);
  }, []);

  const setActiveTrack = useCallback(async (musicId: string | null) => {
    if (!isAdmin) return { error: 'Admin only' };

    await supabase
      .from('hidden_garden_music')
      .update({ is_active: false })
      .neq('id', '00000000-0000-0000-0000-000000000000');

    if (musicId) {
      await supabase
        .from('hidden_garden_music')
        .update({ is_active: true })
        .eq('id', musicId);
    }

    loadMusic();
    return { success: true };
  }, [isAdmin, loadMusic]);

  const updateSettings = useCallback(async (updates: Partial<GardenSettings>) => {
    if (!isAdmin || !user) return { error: 'Admin only' };

    const { data, error } = await supabase
      .from('hidden_garden_settings')
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
        updated_by: user.id
      })
      .eq('id', '00000000-0000-0000-0000-000000000001')
      .select()
      .single();

    if (error) return { error: error.message };
    setSettings(data);
    return { data };
  }, [isAdmin, user]);

  const setPinnedContent = useCallback(async (
    content: string | null,
    type: GardenSettings['pinned_type']
  ) => {
    if (!isAdmin || !user) return { error: 'Admin only' };

    return updateSettings({
      pinned_content: content,
      pinned_type: type,
      pinned_at: content ? new Date().toISOString() : null,
      pinned_by: content ? user.id : null
    });
  }, [isAdmin, user, updateSettings]);

  const muteUser = useCallback(async (userId: string, minutes: number, reason?: string) => {
    if (!isAdmin) return { error: 'Admin only' };

    const today = new Date().toISOString().split('T')[0];
    const mutedUntil = new Date(Date.now() + minutes * 60 * 1000).toISOString();

    const { error } = await supabase
      .from('hidden_garden_user_state')
      .upsert({
        user_id: userId,
        answer_date: today,
        is_muted: true,
        muted_until: mutedUntil,
        muted_reason: reason || 'Muted by moderator'
      }, {
        onConflict: 'user_id,answer_date'
      });

    if (error) return { error: error.message };
    return { success: true };
  }, [isAdmin]);

  const removeMessage = useCallback(async (messageId: string) => {
    if (!isAdmin || !user) return { error: 'Admin only' };

    const { error } = await supabase
      .from('hidden_garden_messages')
      .update({
        is_removed: true,
        removed_by: user.id,
        removed_at: new Date().toISOString()
      })
      .eq('id', messageId);

    if (error) return { error: error.message };

    setMessages(prev => prev.filter(m => m.id !== messageId));
    return { success: true };
  }, [isAdmin, user]);

  const clearChat = useCallback(async () => {
    if (!isAdmin || !user) return { error: 'Admin only' };

    const { error } = await supabase
      .from('hidden_garden_messages')
      .update({
        is_removed: true,
        removed_by: user.id,
        removed_at: new Date().toISOString()
      })
      .eq('is_removed', false);

    if (error) return { error: error.message };

    setMessages([]);
    return { success: true };
  }, [isAdmin, user]);

  const overrideTheme = useCallback(async (themeId: string) => {
    if (!isAdmin) return { error: 'Admin only' };

    const { data: questions } = await supabase
      .from('garden_questions')
      .select('*')
      .eq('theme_id', themeId)
      .eq('day_number', 1)
      .maybeSingle();

    const { data: tracks } = await supabase
      .from('garden_ambient_tracks')
      .select('*')
      .eq('theme_id', themeId);

    const randomTrack = tracks && tracks.length > 0
      ? tracks[Math.floor(Math.random() * tracks.length)]
      : null;

    const { error } = await supabase
      .from('garden_automation_state')
      .update({
        current_theme_id: themeId,
        theme_started_at: new Date().toISOString(),
        theme_override: true,
        current_question_id: questions?.id || null,
        question_changed_at: new Date().toISOString(),
        question_override: false,
        current_track_id: randomTrack?.id || null,
        track_changed_at: new Date().toISOString(),
        track_override: false,
        updated_at: new Date().toISOString()
      })
      .eq('id', 'current');

    if (error) return { error: error.message };

    await loadAutomation();
    return { success: true };
  }, [isAdmin, loadAutomation]);

  const overrideQuestion = useCallback(async (questionId: string) => {
    if (!isAdmin) return { error: 'Admin only' };

    const { error } = await supabase
      .from('garden_automation_state')
      .update({
        current_question_id: questionId,
        question_changed_at: new Date().toISOString(),
        question_override: true,
        updated_at: new Date().toISOString()
      })
      .eq('id', 'current');

    if (error) return { error: error.message };

    await loadAutomation();
    return { success: true };
  }, [isAdmin, loadAutomation]);

  const overrideTrack = useCallback(async (trackId: string | null) => {
    if (!isAdmin) return { error: 'Admin only' };

    const { error } = await supabase
      .from('garden_automation_state')
      .update({
        current_track_id: trackId,
        track_changed_at: new Date().toISOString(),
        track_override: trackId !== null,
        updated_at: new Date().toISOString()
      })
      .eq('id', 'current');

    if (error) return { error: error.message };

    await loadAutomation();
    return { success: true };
  }, [isAdmin, loadAutomation]);

  const toggleTrackPaused = useCallback(async (paused: boolean) => {
    if (!isAdmin) return { error: 'Admin only' };

    const { error } = await supabase
      .from('garden_automation_state')
      .update({
        track_paused: paused,
        updated_at: new Date().toISOString()
      })
      .eq('id', 'current');

    if (error) return { error: error.message };

    setAutomation(prev => prev ? { ...prev, track_paused: paused } : null);
    return { success: true };
  }, [isAdmin]);

  const clearOverride = useCallback(async (type: 'theme' | 'question' | 'track') => {
    if (!isAdmin) return { error: 'Admin only' };

    const updates: Record<string, unknown> = {
      updated_at: new Date().toISOString()
    };

    if (type === 'theme') {
      updates.theme_override = false;
    } else if (type === 'question') {
      updates.question_override = false;
    } else if (type === 'track') {
      updates.track_override = false;
    }

    const { error } = await supabase
      .from('garden_automation_state')
      .update(updates)
      .eq('id', 'current');

    if (error) return { error: error.message };

    await loadAutomation();
    return { success: true };
  }, [isAdmin, loadAutomation]);

  const getThemeQuestions = useCallback(async (themeId: string) => {
    const { data, error } = await supabase
      .from('garden_questions')
      .select('*')
      .eq('theme_id', themeId)
      .order('day_number');

    if (error) return [];
    return data || [];
  }, []);

  const getThemeTracks = useCallback(async (themeId: string) => {
    const { data, error } = await supabase
      .from('garden_ambient_tracks')
      .select('*')
      .eq('theme_id', themeId);

    if (error) return [];
    return data || [];
  }, []);

  const uploadAIAudio = useCallback(async (
    audioData: string,
    title: string,
    durationSeconds: number,
    mood?: string,
    themeId?: string
  ): Promise<{ success: boolean; error?: string; data?: { id: string; audio_url: string } }> => {
    if (!isAdmin || !session?.access_token) {
      return { success: false, error: 'Admin access required' };
    }

    if (!audioData || !title || durationSeconds <= 0) {
      return { success: false, error: 'Invalid parameters' };
    }

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/garden-audio-upload`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            audioData,
            title,
            durationSeconds,
            mood: mood || 'ambient',
            themeId,
          }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        return { success: false, error: result.error || 'Upload failed' };
      }

      await loadMusic();

      return {
        success: true,
        data: {
          id: result.data.id,
          audio_url: result.data.audio_url,
        },
      };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : 'Upload failed' };
    }
  }, [isAdmin, session, loadMusic]);

  useEffect(() => {
    const loadAll = async () => {
      setLoading(true);
      try {
        await Promise.all([
          loadSettings(),
          loadDailyQuestion(),
          loadUserState(),
          loadMessages(),
          loadMusic(),
          loadAutomation()
        ]);

        if (user) {
          const { data } = await supabase
            .from('user_profiles')
            .select('is_admin')
            .eq('id', user.id)
            .maybeSingle();
          setIsAdmin(data?.is_admin || false);
        }
      } catch (err) {
        setError('Failed to load garden');
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, [user, loadSettings, loadDailyQuestion, loadUserState, loadMessages, loadMusic, loadAutomation]);

  useEffect(() => {
    const channel = supabase
      .channel('garden-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'hidden_garden_messages'
        },
        () => {
          loadMessages();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'hidden_garden_messages'
        },
        () => {
          loadMessages();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'hidden_garden_settings'
        },
        () => {
          loadSettings();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'hidden_garden_music'
        },
        () => {
          loadMusic();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'garden_automation_state'
        },
        () => {
          loadAutomation();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [loadMessages, loadSettings, loadMusic, loadAutomation]);

  const hasAnswered = Boolean(userState?.answer);
  const canEdit = (userState?.edit_count || 0) < 1;
  const isMuted = userState?.is_muted &&
    (!userState.muted_until || new Date(userState.muted_until) > new Date());

  const currentThemeQuestion = automation?.question?.question || dailyQuestion?.question;

  return {
    settings,
    dailyQuestion,
    userState,
    messages,
    activeMusic,
    allMusic,
    loading,
    error,
    isAdmin,
    hasAnswered,
    canEdit,
    isMuted,
    submitAnswer,
    sendMessage,
    toggleReaction,
    setActiveTrack,
    updateSettings,
    setPinnedContent,
    muteUser,
    removeMessage,
    clearChat,
    refreshMessages: loadMessages,
    automation,
    automationLoading,
    allThemes,
    currentThemeQuestion,
    overrideTheme,
    overrideQuestion,
    overrideTrack,
    toggleTrackPaused,
    clearOverride,
    getThemeQuestions,
    getThemeTracks,
    refreshAutomation: loadAutomation,
    uploadAIAudio
  };
}
