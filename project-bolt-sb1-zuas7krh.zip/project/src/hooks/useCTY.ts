import { useState, useEffect } from 'react';
import { ctyManager, CTYTransaction } from '../lib/cty';
import { useAuth } from '../contexts/AuthContext';

export function useCTY() {
  const { user } = useAuth();
  const [balance, setBalance] = useState<number>(0);
  const [plan, setPlan] = useState<'free' | 'personal' | 'creator'>('free');
  const [transactions, setTransactions] = useState<CTYTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchBalance = async () => {
    if (!user) return;
    try {
      const data = await ctyManager.getBalance();
      setBalance(data.balance);
      setPlan(data.plan);
    } catch (error) {
      console.error('Failed to fetch CTY balance:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTransactions = async () => {
    if (!user) return;
    try {
      const data = await ctyManager.getTransactions();
      setTransactions(data);
    } catch (error) {
      console.error('Failed to fetch transactions:', error);
    }
  };

  useEffect(() => {
    fetchBalance();
    fetchTransactions();
  }, [user]);

  const spend = async (amount: number, description: string, metadata?: Record<string, any>) => {
    const result = await ctyManager.spend(amount, description, metadata);
    setBalance(result.newBalance);
    await fetchTransactions();
    return result;
  };

  const earn = async (amount: number, description: string, metadata?: Record<string, any>) => {
    const result = await ctyManager.earn(amount, description, metadata);
    setBalance(result.newBalance);
    await fetchTransactions();
    return result;
  };

  const purchase = async (amount: number) => {
    const result = await ctyManager.purchase(amount);
    setBalance(result.newBalance);
    await fetchTransactions();
    return result;
  };

  return {
    balance,
    plan,
    transactions,
    loading,
    spend,
    earn,
    purchase,
    refresh: fetchBalance,
  };
}
