import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import type { Conversation, Message, MessageRequest } from '../types';

export function useMessaging() {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messageRequests, setMessageRequests] = useState<MessageRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchConversations = useCallback(async () => {
    if (!user) return;

    try {
      const { data: convos, error: convosError } = await supabase
        .from('conversations')
        .select('*')
        .or(`participant_one.eq.${user.id},participant_two.eq.${user.id}`)
        .order('last_message_at', { ascending: false });

      if (convosError) throw convosError;

      const enrichedConvos = await Promise.all(
        (convos || []).map(async (convo) => {
          const otherUserId = convo.participant_one === user.id
            ? convo.participant_two
            : convo.participant_one;

          const [{ data: otherUser }, { data: lastMsg }] = await Promise.all([
            supabase
              .from('user_profiles')
              .select('id, username, handle, avatar_url')
              .eq('id', otherUserId)
              .maybeSingle(),
            supabase
              .from('messages')
              .select('*')
              .eq('conversation_id', convo.id)
              .order('created_at', { ascending: false })
              .limit(1)
              .maybeSingle(),
          ]);

          return {
            ...convo,
            other_user: otherUser || undefined,
            last_message: lastMsg || undefined,
          };
        })
      );

      setConversations(enrichedConvos);
    } catch (err: any) {
      setError(err.message);
    }
  }, [user]);

  const fetchMessageRequests = useCallback(async () => {
    if (!user) return;

    try {
      const { data, error: reqError } = await supabase
        .from('message_requests')
        .select('*')
        .eq('recipient_id', user.id)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (reqError) throw reqError;

      const enrichedRequests = await Promise.all(
        (data || []).map(async (req) => {
          const { data: sender } = await supabase
            .from('user_profiles')
            .select('id, username, handle, avatar_url')
            .eq('id', req.sender_id)
            .maybeSingle();

          return { ...req, sender: sender || undefined };
        })
      );

      setMessageRequests(enrichedRequests);
    } catch (err: any) {
      setError(err.message);
    }
  }, [user]);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchConversations(), fetchMessageRequests()]);
      setLoading(false);
    };

    loadData();
  }, [fetchConversations, fetchMessageRequests]);

  const checkCanMessage = async (targetUserId: string): Promise<{ canMessage: boolean; reason?: string; needsRequest?: boolean }> => {
    if (!user) return { canMessage: false, reason: 'Not authenticated' };

    const { data: blocked } = await supabase
      .from('user_blocks')
      .select('id')
      .or(`and(blocker_id.eq.${user.id},blocked_id.eq.${targetUserId}),and(blocker_id.eq.${targetUserId},blocked_id.eq.${user.id})`)
      .maybeSingle();

    if (blocked) return { canMessage: false, reason: 'User is blocked' };

    const [{ data: iFollow }, { data: theyFollow }] = await Promise.all([
      supabase
        .from('follows')
        .select('id')
        .eq('follower_id', user.id)
        .eq('following_id', targetUserId)
        .maybeSingle(),
      supabase
        .from('follows')
        .select('id')
        .eq('follower_id', targetUserId)
        .eq('following_id', user.id)
        .maybeSingle(),
    ]);

    if (iFollow && theyFollow) return { canMessage: true };

    const { data: acceptedRequest } = await supabase
      .from('message_requests')
      .select('id')
      .or(`and(sender_id.eq.${user.id},recipient_id.eq.${targetUserId}),and(sender_id.eq.${targetUserId},recipient_id.eq.${user.id})`)
      .eq('status', 'accepted')
      .maybeSingle();

    if (acceptedRequest) return { canMessage: true };

    return { canMessage: false, needsRequest: true };
  };

  const sendMessageRequest = async (targetUserId: string): Promise<void> => {
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase
      .from('message_requests')
      .insert({ sender_id: user.id, recipient_id: targetUserId });

    if (error) throw error;
  };

  const respondToRequest = async (requestId: string, accept: boolean): Promise<void> => {
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase
      .from('message_requests')
      .update({ status: accept ? 'accepted' : 'declined', updated_at: new Date().toISOString() })
      .eq('id', requestId);

    if (error) throw error;

    await fetchMessageRequests();
  };

  const getOrCreateConversation = async (targetUserId: string): Promise<string> => {
    if (!user) throw new Error('Not authenticated');

    const [p1, p2] = [user.id, targetUserId].sort();

    const { data: existing } = await supabase
      .from('conversations')
      .select('id')
      .or(`and(participant_one.eq.${p1},participant_two.eq.${p2}),and(participant_one.eq.${p2},participant_two.eq.${p1})`)
      .maybeSingle();

    if (existing) return existing.id;

    const { data: newConvo, error } = await supabase
      .from('conversations')
      .insert({ participant_one: p1, participant_two: p2 })
      .select('id')
      .single();

    if (error) throw error;
    return newConvo.id;
  };

  const sendMessage = async (conversationId: string, content: string): Promise<Message> => {
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase
      .from('messages')
      .insert({ conversation_id: conversationId, sender_id: user.id, content })
      .select()
      .single();

    if (error) throw error;
    return data;
  };

  const getMessages = useCallback(async (conversationId: string): Promise<Message[]> => {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data || [];
  }, []);

  const reportMessage = async (messageId: string, conversationId: string, reason: string, details?: string): Promise<void> => {
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase
      .from('message_reports')
      .insert({
        reporter_id: user.id,
        message_id: messageId,
        conversation_id: conversationId,
        reason,
        details,
      });

    if (error) throw error;
  };

  return {
    conversations,
    messageRequests,
    loading,
    error,
    checkCanMessage,
    sendMessageRequest,
    respondToRequest,
    getOrCreateConversation,
    sendMessage,
    getMessages,
    reportMessage,
    refresh: () => Promise.all([fetchConversations(), fetchMessageRequests()]),
  };
}
