import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export interface GeneratedImage {
  id: string;
  prompt: string;
  sanitized_prompt: string;
  style: string;
  quality: 'standard' | 'high';
  image_url: string;
  thumbnail_url: string;
  is_private: boolean;
  is_shared: boolean;
  cty_cost: number;
  status: 'pending' | 'generating' | 'completed' | 'failed';
  error_message?: string;
  created_at: string;
}

export interface GenerationLimits {
  used: number;
  limit: number;
  remaining: number;
  plan: string;
}

export interface GenerateOptions {
  prompt: string;
  style: string;
  quality: 'standard' | 'high';
  isPrivate: boolean;
}

export function useImageGeneration() {
  const { user } = useAuth();
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [limits, setLimits] = useState<GenerationLimits | null>(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.access_token) throw new Error('Not authenticated');
    return {
      'Authorization': `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
    };
  }, []);

  const fetchLimits = useCallback(async () => {
    if (!user) return;
    try {
      const headers = await getAuthHeaders();
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/image-generator/limits`,
        { headers }
      );

      if (!response.ok) throw new Error('Failed to fetch limits');
      const data = await response.json();
      setLimits(data);
    } catch (err: any) {
      console.error('Failed to fetch generation limits:', err);
    }
  }, [user, getAuthHeaders]);

  const fetchHistory = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/image-generator/history`,
        { headers }
      );

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        if (response.status === 404 || data.images?.length === 0) {
          setImages([]);
          return;
        }
        throw new Error('Failed to fetch history');
      }
      const data = await response.json();
      setImages(data.images || []);
    } catch (err: any) {
      console.error('Failed to fetch generation history:', err);
      setImages([]);
    } finally {
      setLoading(false);
    }
  }, [user, getAuthHeaders]);

  useEffect(() => {
    fetchLimits();
    fetchHistory();
  }, [fetchLimits, fetchHistory]);

  const generate = useCallback(async (options: GenerateOptions): Promise<GeneratedImage | null> => {
    if (!user) {
      setError('Please sign in to generate images');
      return null;
    }

    setGenerating(true);
    setError(null);

    try {
      const headers = await getAuthHeaders();
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/image-generator/generate`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify(options),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Generation failed');
      }

      const newImage: GeneratedImage = {
        id: data.generation.id,
        prompt: options.prompt,
        sanitized_prompt: '',
        style: data.generation.style,
        quality: data.generation.quality,
        image_url: data.generation.imageUrl,
        thumbnail_url: data.generation.thumbnailUrl,
        is_private: data.generation.isPrivate,
        is_shared: false,
        cty_cost: data.generation.cost,
        status: data.generation.status,
        created_at: new Date().toISOString(),
      };

      setImages(prev => [newImage, ...prev]);
      await fetchLimits();

      return newImage;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setGenerating(false);
    }
  }, [user, getAuthHeaders, fetchLimits]);

  const shareToFeed = useCallback(async (generationId: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const headers = await getAuthHeaders();
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/image-generator/share`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify({ generationId }),
        }
      );

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to share');
      }

      setImages(prev =>
        prev.map(img =>
          img.id === generationId
            ? { ...img, is_private: false, is_shared: true }
            : img
        )
      );

      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    }
  }, [user, getAuthHeaders]);

  const deleteImage = useCallback(async (generationId: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('generated_images')
        .delete()
        .eq('id', generationId)
        .eq('user_id', user.id);

      if (error) throw error;

      setImages(prev => prev.filter(img => img.id !== generationId));
      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    }
  }, [user]);

  return {
    images,
    limits,
    loading,
    generating,
    error,
    generate,
    shareToFeed,
    deleteImage,
    refresh: () => {
      fetchLimits();
      fetchHistory();
    },
    clearError: () => setError(null),
  };
}
