import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface TipResult {
  success: boolean;
  newBalance?: number;
  tipId?: string;
  error?: string;
}

interface Tip {
  id: string;
  sender_id: string;
  recipient_id: string;
  post_id: string | null;
  amount: number;
  message: string | null;
  created_at: string;
}

export function useTipping() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canTip = async (): Promise<{ allowed: boolean; reason?: string }> => {
    if (!user) {
      return { allowed: false, reason: 'Please sign in to tip' };
    }

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('plan_type')
      .eq('id', user.id)
      .maybeSingle();

    if (!profile || !['personal', 'creator'].includes(profile.plan_type)) {
      return { allowed: false, reason: 'Tipping requires a Personal or Creator subscription' };
    }

    return { allowed: true };
  };

  const sendTip = async (
    recipientId: string,
    amount: number,
    postId?: string,
    message?: string
  ): Promise<TipResult> => {
    if (!user) {
      return { success: false, error: 'Please sign in to tip' };
    }

    if (user.id === recipientId) {
      return { success: false, error: 'Cannot tip yourself' };
    }

    setLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('Not authenticated');
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/cty-manager/tip`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            recipientId,
            amount,
            postId: postId || null,
            message: message || null,
          }),
        }
      );

      const result = await response.json();

      if (!response.ok || !result.success) {
        const errorMsg = result.error || 'Failed to send tip';
        setError(errorMsg);
        return { success: false, error: errorMsg };
      }

      return {
        success: true,
        newBalance: result.newBalance,
        tipId: result.tipId,
      };
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Failed to send tip';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  const getTipsSent = async (): Promise<Tip[]> => {
    if (!user) return [];

    const { data, error: fetchError } = await supabase
      .from('tips')
      .select('*')
      .eq('sender_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50);

    if (fetchError) {
      console.error('Error fetching sent tips:', fetchError);
      return [];
    }

    return data || [];
  };

  const getTipsReceived = async (): Promise<Tip[]> => {
    if (!user) return [];

    const { data, error: fetchError } = await supabase
      .from('tips')
      .select('*')
      .eq('recipient_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50);

    if (fetchError) {
      console.error('Error fetching received tips:', fetchError);
      return [];
    }

    return data || [];
  };

  return {
    sendTip,
    canTip,
    getTipsSent,
    getTipsReceived,
    loading,
    error,
    clearError: () => setError(null),
  };
}
