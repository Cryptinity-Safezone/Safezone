import { useState, useCallback } from 'react';
import type { ImageOptimizeSettings, OptimizedImage } from '../types';

const DEFAULT_SETTINGS: ImageOptimizeSettings = {
  quality: 80,
  maxWidth: 1920,
  maxHeight: 1080,
  format: 'webp',
  preserveAspectRatio: true,
};

export const useImageOptimizer = () => {
  const [settings, setSettings] = useState<ImageOptimizeSettings>(DEFAULT_SETTINGS);
  const [images, setImages] = useState<OptimizedImage[]>([]);
  const [processing, setProcessing] = useState(false);

  const getImageDimensions = (file: File): Promise<{ width: number; height: number }> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        resolve({ width: img.naturalWidth, height: img.naturalHeight });
        URL.revokeObjectURL(img.src);
      };
      img.src = URL.createObjectURL(file);
    });
  };

  const optimizeImage = useCallback(async (file: File): Promise<OptimizedImage> => {
    const originalUrl = URL.createObjectURL(file);
    const { width: origWidth, height: origHeight } = await getImageDimensions(file);

    let targetWidth = origWidth;
    let targetHeight = origHeight;

    if (settings.preserveAspectRatio) {
      const ratio = Math.min(
        settings.maxWidth / origWidth,
        settings.maxHeight / origHeight,
        1
      );
      targetWidth = Math.round(origWidth * ratio);
      targetHeight = Math.round(origHeight * ratio);
    } else {
      targetWidth = Math.min(origWidth, settings.maxWidth);
      targetHeight = Math.min(origHeight, settings.maxHeight);
    }

    const canvas = document.createElement('canvas');
    canvas.width = targetWidth;
    canvas.height = targetHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get canvas context');

    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = reject;
      img.src = originalUrl;
    });

    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

    const mimeType = `image/${settings.format}`;
    const quality = settings.quality / 100;

    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (b) => (b ? resolve(b) : reject(new Error('Failed to create blob'))),
        mimeType,
        quality
      );
    });

    const optimizedUrl = URL.createObjectURL(blob);
    const savings = Math.round(((file.size - blob.size) / file.size) * 100);

    return {
      original: {
        file,
        url: originalUrl,
        size: file.size,
        width: origWidth,
        height: origHeight,
      },
      optimized: {
        blob,
        url: optimizedUrl,
        size: blob.size,
        width: targetWidth,
        height: targetHeight,
      },
      savings: Math.max(0, savings),
    };
  }, [settings]);

  const processImages = useCallback(async (files: File[]) => {
    setProcessing(true);
    const results: OptimizedImage[] = [];

    for (const file of files) {
      if (!file.type.startsWith('image/')) continue;
      try {
        const result = await optimizeImage(file);
        results.push(result);
      } catch (err) {
        console.error('Failed to optimize image:', err);
      }
    }

    setImages((prev) => [...prev, ...results]);
    setProcessing(false);
    return results;
  }, [optimizeImage]);

  const removeImage = useCallback((index: number) => {
    setImages((prev) => {
      const img = prev[index];
      if (img) {
        URL.revokeObjectURL(img.original.url);
        URL.revokeObjectURL(img.optimized.url);
      }
      return prev.filter((_, i) => i !== index);
    });
  }, []);

  const clearAll = useCallback(() => {
    images.forEach((img) => {
      URL.revokeObjectURL(img.original.url);
      URL.revokeObjectURL(img.optimized.url);
    });
    setImages([]);
  }, [images]);

  const downloadImage = useCallback((image: OptimizedImage) => {
    const link = document.createElement('a');
    link.href = image.optimized.url;
    const originalName = image.original.file.name.replace(/\.[^/.]+$/, '');
    link.download = `${originalName}_optimized.${settings.format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [settings.format]);

  const downloadAll = useCallback(() => {
    images.forEach((img) => downloadImage(img));
  }, [images, downloadImage]);

  const updateSettings = useCallback((updates: Partial<ImageOptimizeSettings>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
  }, []);

  const reprocessAll = useCallback(async () => {
    if (images.length === 0) return;

    setProcessing(true);
    const files = images.map((img) => img.original.file);

    images.forEach((img) => {
      URL.revokeObjectURL(img.original.url);
      URL.revokeObjectURL(img.optimized.url);
    });

    setImages([]);
    const results: OptimizedImage[] = [];

    for (const file of files) {
      try {
        const result = await optimizeImage(file);
        results.push(result);
      } catch (err) {
        console.error('Failed to reprocess image:', err);
      }
    }

    setImages(results);
    setProcessing(false);
  }, [images, optimizeImage]);

  return {
    settings,
    updateSettings,
    images,
    processing,
    processImages,
    removeImage,
    clearAll,
    downloadImage,
    downloadAll,
    reprocessAll,
  };
};
