import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export interface ShowcaseItem {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  media_url: string;
  media_type: 'image' | 'video' | 'audio' | 'motion';
  source_id: string | null;
  source_type: string | null;
  is_protected: boolean;
  order_index: number;
  created_at: string;
  updated_at: string;
}

export interface AddToShowcaseParams {
  title: string;
  description?: string;
  mediaUrl: string;
  mediaType: 'image' | 'video' | 'audio' | 'motion';
  sourceId?: string;
  sourceType?: 'generated_images' | 'motion_generations' | 'ai_generated_sounds';
}

export function useShowcase() {
  const { user } = useAuth();
  const [items, setItems] = useState<ShowcaseItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchItems = useCallback(async () => {
    if (!user) {
      setItems([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: fetchError } = await supabase
        .from('showcase_items')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setItems(data || []);
    } catch (err: unknown) {
      console.error('Failed to fetch showcase items:', err);
      setError('Failed to load your showcase');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  const addToShowcase = useCallback(async (params: AddToShowcaseParams): Promise<ShowcaseItem | null> => {
    if (!user) {
      setError('Please sign in to add items to your showcase');
      return null;
    }

    try {
      const existingItem = items.find(
        item => item.source_id === params.sourceId && item.source_type === params.sourceType
      );

      if (existingItem) {
        setError('This item is already in your showcase');
        return null;
      }

      const { data, error: insertError } = await supabase
        .from('showcase_items')
        .insert({
          user_id: user.id,
          title: params.title,
          description: params.description || null,
          media_url: params.mediaUrl,
          media_type: params.mediaType,
          source_id: params.sourceId || null,
          source_type: params.sourceType || null,
          is_protected: true,
          order_index: items.length,
        })
        .select()
        .single();

      if (insertError) throw insertError;

      setItems(prev => [data, ...prev]);
      return data;
    } catch (err: unknown) {
      console.error('Failed to add to showcase:', err);
      setError('Failed to add item to showcase');
      return null;
    }
  }, [user, items]);

  const removeFromShowcase = useCallback(async (itemId: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const { error: deleteError } = await supabase
        .from('showcase_items')
        .delete()
        .eq('id', itemId)
        .eq('user_id', user.id);

      if (deleteError) throw deleteError;

      setItems(prev => prev.filter(item => item.id !== itemId));
      return true;
    } catch (err: unknown) {
      console.error('Failed to remove from showcase:', err);
      setError('Failed to remove item from showcase');
      return false;
    }
  }, [user]);

  const updateItem = useCallback(async (
    itemId: string,
    updates: { title?: string; description?: string }
  ): Promise<boolean> => {
    if (!user) return false;

    try {
      const { error: updateError } = await supabase
        .from('showcase_items')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', itemId)
        .eq('user_id', user.id);

      if (updateError) throw updateError;

      setItems(prev => prev.map(item =>
        item.id === itemId ? { ...item, ...updates } : item
      ));
      return true;
    } catch (err: unknown) {
      console.error('Failed to update showcase item:', err);
      setError('Failed to update item');
      return false;
    }
  }, [user]);

  const isInShowcase = useCallback((sourceId: string, sourceType: string): boolean => {
    return items.some(item => item.source_id === sourceId && item.source_type === sourceType);
  }, [items]);

  const getItemsByType = useCallback((mediaType: ShowcaseItem['media_type']): ShowcaseItem[] => {
    return items.filter(item => item.media_type === mediaType);
  }, [items]);

  const groupedItems = {
    images: items.filter(i => i.media_type === 'image'),
    videos: items.filter(i => i.media_type === 'video'),
    motion: items.filter(i => i.media_type === 'motion'),
    audio: items.filter(i => i.media_type === 'audio'),
  };

  return {
    items,
    groupedItems,
    loading,
    error,
    addToShowcase,
    removeFromShowcase,
    updateItem,
    isInShowcase,
    getItemsByType,
    refresh: fetchItems,
    clearError: () => setError(null),
  };
}
