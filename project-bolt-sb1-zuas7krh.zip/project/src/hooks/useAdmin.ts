import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { ADMIN_CONFIG } from '../lib/admin-config';

export function useAdmin() {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminRole, setAdminRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function checkAdminStatus() {
      if (!user || !ADMIN_CONFIG.enableAdminFeatures) {
        setIsAdmin(false);
        setAdminRole(null);
        setLoading(false);
        return;
      }

      try {
        const { data: isAdminResult } = await supabase
          .rpc('is_admin', { p_user_id: user.id });

        if (isAdminResult) {
          const { data: role } = await supabase
            .rpc('get_admin_role', { p_user_id: user.id });
          setAdminRole(role);
        }

        setIsAdmin(isAdminResult === true);
      } catch {
        setIsAdmin(false);
        setAdminRole(null);
      } finally {
        setLoading(false);
      }
    }

    checkAdminStatus();
  }, [user]);

  return { isAdmin, adminRole, loading };
}
