import { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export interface Comment {
  id: string;
  post_id: string;
  user_id: string;
  content: string;
  created_at: string;
  user_profile?: {
    username: string;
    avatar_url: string | null;
    is_verified: boolean;
  };
}

export function useComments(postId: string) {
  const { user } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchComments = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fetchError } = await supabase
        .from('comments')
        .select('*')
        .eq('post_id', postId)
        .order('created_at', { ascending: true });

      if (fetchError) throw fetchError;

      const commentsWithProfiles = await Promise.all(
        (data || []).map(async (comment) => {
          const { data: profileData } = await supabase
            .from('user_profiles')
            .select('username, avatar_url, is_verified')
            .eq('id', comment.user_id)
            .maybeSingle();

          return {
            ...comment,
            user_profile: profileData || undefined,
          };
        })
      );

      setComments(commentsWithProfiles);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [postId]);

  const addComment = useCallback(async (content: string): Promise<Comment | null> => {
    if (!user) {
      setError('Must be authenticated');
      return null;
    }

    if (!content.trim() || content.length > 500) {
      setError('Comment must be 1-500 characters');
      return null;
    }

    try {
      const { data, error: insertError } = await supabase
        .from('comments')
        .insert({
          post_id: postId,
          user_id: user.id,
          content: content.trim(),
        })
        .select('*')
        .single();

      if (insertError) throw insertError;

      const { data: profileData } = await supabase
        .from('user_profiles')
        .select('username, avatar_url, is_verified')
        .eq('id', user.id)
        .maybeSingle();

      const newComment: Comment = {
        ...data,
        user_profile: profileData || undefined,
      };

      setComments(prev => [...prev, newComment]);
      return newComment;
    } catch (err: any) {
      setError(err.message);
      return null;
    }
  }, [user, postId]);

  const deleteComment = useCallback(async (commentId: string): Promise<boolean> => {
    if (!user) return false;

    try {
      const { error: deleteError } = await supabase
        .from('comments')
        .delete()
        .eq('id', commentId)
        .eq('user_id', user.id);

      if (deleteError) throw deleteError;

      setComments(prev => prev.filter(c => c.id !== commentId));
      return true;
    } catch (err: any) {
      setError(err.message);
      return false;
    }
  }, [user]);

  return {
    comments,
    loading,
    error,
    fetchComments,
    addComment,
    deleteComment,
    clearError: () => setError(null),
  };
}
