import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export interface MutedUser {
  id: string;
  muted_user_id: string;
  mute_mentions: boolean;
  created_at: string;
  muted_user: {
    id: string;
    username: string;
    avatar_url: string | null;
    handle: string;
  };
}

export function useMutedUsers() {
  const { user } = useAuth();
  const [mutedUsers, setMutedUsers] = useState<MutedUser[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMutedUsers = useCallback(async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('muted_users')
        .select(`
          id, muted_user_id, mute_mentions, created_at,
          muted_user:muted_user_id(id, username, avatar_url, handle)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formatted = (data || []).map(m => ({
        ...m,
        muted_user: Array.isArray(m.muted_user) ? m.muted_user[0] : m.muted_user,
      }));

      setMutedUsers(formatted);
    } catch (error) {
      console.error('Error fetching muted users:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchMutedUsers();
  }, [fetchMutedUsers]);

  const muteUser = async (mutedUserId: string, muteMentions = true) => {
    if (!user || mutedUserId === user.id) return;

    try {
      const { data, error } = await supabase
        .from('muted_users')
        .upsert({
          user_id: user.id,
          muted_user_id: mutedUserId,
          mute_mentions: muteMentions,
        }, {
          onConflict: 'user_id,muted_user_id'
        })
        .select(`
          id, muted_user_id, mute_mentions, created_at,
          muted_user:muted_user_id(id, username, avatar_url, handle)
        `)
        .single();

      if (error) throw error;

      const formatted = {
        ...data,
        muted_user: Array.isArray(data.muted_user) ? data.muted_user[0] : data.muted_user,
      };

      setMutedUsers(prev => {
        const existing = prev.findIndex(m => m.muted_user_id === mutedUserId);
        if (existing >= 0) {
          const updated = [...prev];
          updated[existing] = formatted;
          return updated;
        }
        return [formatted, ...prev];
      });

      return formatted;
    } catch (error) {
      console.error('Error muting user:', error);
      throw error;
    }
  };

  const unmuteUser = async (muteId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('muted_users')
        .delete()
        .eq('id', muteId)
        .eq('user_id', user.id);

      if (error) throw error;

      setMutedUsers(prev => prev.filter(m => m.id !== muteId));
    } catch (error) {
      console.error('Error unmuting user:', error);
      throw error;
    }
  };

  const toggleMentions = async (muteId: string, muteMentions: boolean) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('muted_users')
        .update({ mute_mentions: muteMentions })
        .eq('id', muteId)
        .eq('user_id', user.id);

      if (error) throw error;

      setMutedUsers(prev =>
        prev.map(m => m.id === muteId ? { ...m, mute_mentions: muteMentions } : m)
      );
    } catch (error) {
      console.error('Error toggling mention mute:', error);
      throw error;
    }
  };

  const isUserMuted = (userId: string): boolean => {
    return mutedUsers.some(m => m.muted_user_id === userId);
  };

  const areMentionsMuted = (userId: string): boolean => {
    const muted = mutedUsers.find(m => m.muted_user_id === userId);
    return muted?.mute_mentions ?? false;
  };

  return {
    mutedUsers,
    loading,
    muteUser,
    unmuteUser,
    toggleMentions,
    isUserMuted,
    areMentionsMuted,
    refresh: fetchMutedUsers,
  };
}
