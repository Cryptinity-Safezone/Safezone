import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export interface BlockedUser {
  id: string;
  blocked_id: string;
  created_at: string;
  blocked_user: {
    username: string;
    handle: string;
    avatar_url: string;
  };
}

export function useBlockedUsers() {
  const { user } = useAuth();
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadBlockedUsers();
    }
  }, [user]);

  const loadBlockedUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('user_blocks')
        .select(`
          id,
          blocked_id,
          created_at,
          blocked_user:user_profiles!user_blocks_blocked_id_fkey(
            username,
            handle,
            avatar_url
          )
        `)
        .eq('blocker_id', user!.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBlockedUsers(data || []);
    } catch (error) {
      console.error('Error loading blocked users:', error);
    } finally {
      setLoading(false);
    }
  };

  const unblockUser = async (blockId: string) => {
    try {
      const { error } = await supabase
        .from('user_blocks')
        .delete()
        .eq('id', blockId);

      if (error) throw error;

      setBlockedUsers(prev => prev.filter(b => b.id !== blockId));
    } catch (error) {
      console.error('Error unblocking user:', error);
      throw error;
    }
  };

  return {
    blockedUsers,
    loading,
    unblockUser,
    refreshBlockedUsers: loadBlockedUsers
  };
}
