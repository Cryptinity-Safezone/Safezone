import { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';

export function useAdminGrant() {
  const [granting, setGranting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const grantCTY = useCallback(async (amount: number) => {
    setGranting(true);
    setError(null);
    setSuccess(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('Not authenticated');
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/cty-manager/admin-grant`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ amount }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to grant CTY');
      }

      setSuccess(`Successfully granted ${amount} CTY! New balance: ${data.newBalance}`);
      return data.newBalance;
    } catch (err: any) {
      setError(err.message);
      return null;
    } finally {
      setGranting(false);
    }
  }, []);

  const clearMessages = useCallback(() => {
    setError(null);
    setSuccess(null);
  }, []);

  return {
    grantCTY,
    granting,
    error,
    success,
    clearMessages,
  };
}
