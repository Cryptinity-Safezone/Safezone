import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export interface UserSettings {
  messaging_preference: 'mutual_followers' | 'message_requests';
  post_visibility: 'everyone' | 'followers_only';
  background_sound_enabled: boolean;
  autoplay_sound: boolean;
  master_volume: number;
  reduce_motion: boolean;
}

export function useSettings() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      loadSettings();
    }
  }, [user]);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('messaging_preference, post_visibility, background_sound_enabled, autoplay_sound, master_volume, reduce_motion')
        .eq('id', user!.id)
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setSettings(data as UserSettings);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (updates: Partial<UserSettings>) => {
    if (!user) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from('user_profiles')
        .update(updates)
        .eq('id', user.id);

      if (error) throw error;

      setSettings(prev => prev ? { ...prev, ...updates } : null);
    } catch (error) {
      console.error('Error updating settings:', error);
      throw error;
    } finally {
      setSaving(false);
    }
  };

  return {
    settings,
    loading,
    saving,
    updateSettings,
    refreshSettings: loadSettings
  };
}
