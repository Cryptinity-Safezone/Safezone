import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { extractHashtags, extractMentions } from '../lib/post-parser';

interface Post {
  id: string;
  user_id: string;
  content: string;
  image_url: string | null;
  motion_url: string | null;
  motion_generation_id: string | null;
  is_motion_post: boolean;
  video_url: string | null;
  video_duration: number | null;
  is_video_post: boolean;
  likes_count: number;
  comments_count: number;
  created_at: string;
  user_profiles: {
    username: string;
    avatar_url: string | null;
    is_verified: boolean;
  };
  is_liked?: boolean;
}

export function usePosts() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPosts = async () => {
    try {
      setLoading(true);

      let query = supabase
        .from('posts')
        .select(`
          *,
          user_profiles!inner(username, avatar_url, is_verified)
        `)
        .order('created_at', { ascending: false })
        .limit(50);

      if (user) {
        const { data: blockedUsers } = await supabase
          .from('user_blocks')
          .select('blocked_id')
          .eq('blocker_id', user.id);

        const blockedIds = (blockedUsers || []).map((b) => b.blocked_id);

        const { data: hiddenPosts } = await supabase
          .from('hidden_posts')
          .select('post_id')
          .eq('user_id', user.id);

        const hiddenIds = (hiddenPosts || []).map((h) => h.post_id);

        const { data, error } = await query;

        if (error) throw error;

        let filteredData = (data || []).filter(
          (post) => !blockedIds.includes(post.user_id) && !hiddenIds.includes(post.id)
        );

        const postsWithLikes = await Promise.all(
          filteredData.map(async (post) => {
            const { data: likeData } = await supabase
              .from('post_likes')
              .select('id')
              .eq('post_id', post.id)
              .eq('user_id', user.id)
              .maybeSingle();

            return {
              ...post,
              is_liked: !!likeData,
            };
          })
        );
        setPosts(postsWithLikes);
      } else {
        const { data, error } = await query;
        if (error) throw error;
        setPosts(data || []);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, [user]);

  const createPost = async (
    content: string,
    options?: {
      imageUrl?: string;
      videoUrl?: string;
      videoDuration?: number;
    }
  ) => {
    if (!user) throw new Error('Must be authenticated');

    const insertData: Record<string, unknown> = {
      user_id: user.id,
      content,
    };

    if (options?.imageUrl) {
      insertData.image_url = options.imageUrl;
    }

    if (options?.videoUrl && options?.videoDuration) {
      insertData.video_url = options.videoUrl;
      insertData.video_duration = options.videoDuration;
      insertData.is_video_post = true;
    }

    const { data, error } = await supabase
      .from('posts')
      .insert(insertData)
      .select(`
        *,
        user_profiles!inner(username, avatar_url, is_verified)
      `)
      .single();

    if (error) throw error;

    const hashtags = extractHashtags(content);
    for (const tag of hashtags) {
      const { data: existingTag } = await supabase
        .from('hashtags')
        .select('id')
        .eq('name', tag)
        .maybeSingle();

      let hashtagId: string;
      if (existingTag) {
        hashtagId = existingTag.id;
      } else {
        const { data: newTag } = await supabase
          .from('hashtags')
          .insert({ name: tag })
          .select('id')
          .single();
        hashtagId = newTag?.id;
      }

      if (hashtagId) {
        await supabase.from('post_hashtags').insert({
          post_id: data.id,
          hashtag_id: hashtagId,
        });
      }
    }

    const mentions = extractMentions(content);
    for (const handle of mentions) {
      const { data: mentionedUser } = await supabase
        .from('user_profiles')
        .select('id')
        .eq('handle', handle)
        .maybeSingle();

      if (mentionedUser) {
        await supabase.from('mentions').insert({
          post_id: data.id,
          mentioned_user_id: mentionedUser.id,
          mentioner_id: user.id,
        });
      }
    }

    setPosts([{ ...data, is_liked: false }, ...posts]);
    return data;
  };

  const toggleLike = async (postId: string) => {
    if (!user) throw new Error('Must be authenticated');

    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    if (post.is_liked) {
      const { error } = await supabase
        .from('post_likes')
        .delete()
        .eq('post_id', postId)
        .eq('user_id', user.id);

      if (error) throw error;

      const { error: updateError } = await supabase
        .from('posts')
        .update({ likes_count: Math.max(0, post.likes_count - 1) })
        .eq('id', postId);

      if (updateError) throw updateError;

      setPosts(
        posts.map((p) =>
          p.id === postId
            ? { ...p, is_liked: false, likes_count: Math.max(0, p.likes_count - 1) }
            : p
        )
      );
    } else {
      const { error } = await supabase
        .from('post_likes')
        .insert({ post_id: postId, user_id: user.id });

      if (error) throw error;

      const { error: updateError } = await supabase
        .from('posts')
        .update({ likes_count: post.likes_count + 1 })
        .eq('id', postId);

      if (updateError) throw updateError;

      setPosts(
        posts.map((p) =>
          p.id === postId ? { ...p, is_liked: true, likes_count: p.likes_count + 1 } : p
        )
      );
    }
  };

  const deletePost = async (postId: string) => {
    if (!user) throw new Error('Must be authenticated');

    const { error } = await supabase.from('posts').delete().eq('id', postId).eq('user_id', user.id);

    if (error) throw error;

    setPosts(posts.filter((p) => p.id !== postId));
  };

  return {
    posts,
    loading,
    error,
    createPost,
    toggleLike,
    deletePost,
    refresh: fetchPosts,
  };
}
