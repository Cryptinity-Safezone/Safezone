export type ViewState = 'feed' | 'explore' | 'optimizer' | 'warehouse' | 'profile' | 'about' | 'upgrade' | 'messages' | 'settings' | 'help' | 'create';
export type AuthView = 'login' | 'register' | 'forgot';
export type PlanType = 'free' | 'personal' | 'creator';
export type ProfileTab = 'posts' | 'showcase' | 'store' | 'about';

export interface UserProfile {
  uid: string;
  username: string;
  handle: string;
  avatar: string;
  cover: string | null;
  plan: PlanType;
  ctyBalance: number;
  isVerified: boolean;
  isRestricted: boolean;
  followers: number;
  following: number;
  creations: number;
  bio?: string;
  interests: string[];
  backgroundMusic?: {
    title: string;
    artist: string;
    url: string;
  };
}

export interface Post {
  id: number;
  author: string;
  avatar: string;
  content: string;
  image?: string;
  time: string;
  likes: number;
  comments: number;
  isLiked?: boolean;
}

export interface ImageOptimizeSettings {
  quality: number;
  maxWidth: number;
  maxHeight: number;
  format: 'jpeg' | 'png' | 'webp';
  preserveAspectRatio: boolean;
}

export interface OptimizedImage {
  original: {
    file: File;
    url: string;
    size: number;
    width: number;
    height: number;
  };
  optimized: {
    blob: Blob;
    url: string;
    size: number;
    width: number;
    height: number;
  };
  savings: number;
}

export interface RoadmapPhase {
  phase: number;
  title: string;
  status: 'active' | 'upcoming' | 'completed';
  features: string[];
}

export interface Conversation {
  id: string;
  participant_one: string;
  participant_two: string;
  last_message_at: string;
  created_at: string;
  other_user?: {
    id: string;
    username: string;
    handle: string;
    avatar_url: string;
  };
  last_message?: Message;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  created_at: string;
}

export interface MessageRequest {
  id: string;
  sender_id: string;
  recipient_id: string;
  status: 'pending' | 'accepted' | 'declined';
  created_at: string;
  sender?: {
    id: string;
    username: string;
    handle: string;
    avatar_url: string;
  };
}
