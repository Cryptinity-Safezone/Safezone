import { supabase } from './supabase';

const CTY_API_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/cty-manager`;

export interface CTYBalance {
  balance: number;
  plan: 'free' | 'personal' | 'creator';
}

export interface CTYTransaction {
  id: string;
  user_id: string;
  amount: number;
  transaction_type: 'earn' | 'spend' | 'purchase' | 'monthly_allowance';
  description: string;
  metadata: Record<string, any>;
  created_at: string;
}

const getAuthHeaders = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error('Not authenticated');

  return {
    'Authorization': `Bearer ${session.access_token}`,
    'Content-Type': 'application/json',
  };
};

export const ctyManager = {
  async getBalance(): Promise<CTYBalance> {
    const headers = await getAuthHeaders();
    const response = await fetch(`${CTY_API_URL}/balance`, { headers });
    if (!response.ok) throw new Error('Failed to fetch balance');
    return response.json();
  },

  async getTransactions(): Promise<CTYTransaction[]> {
    const headers = await getAuthHeaders();
    const response = await fetch(`${CTY_API_URL}/transactions`, { headers });
    if (!response.ok) throw new Error('Failed to fetch transactions');
    const data = await response.json();
    return data.transactions;
  },

  async spend(amount: number, description: string, metadata?: Record<string, any>): Promise<{ success: boolean; newBalance: number }> {
    const headers = await getAuthHeaders();
    const response = await fetch(`${CTY_API_URL}/spend`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ amount, description, metadata }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to spend CTY');
    }

    return response.json();
  },

  async earn(amount: number, description: string, metadata?: Record<string, any>): Promise<{ success: boolean; newBalance: number }> {
    const headers = await getAuthHeaders();
    const response = await fetch(`${CTY_API_URL}/earn`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ amount, description, metadata }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to earn CTY');
    }

    return response.json();
  },

  async purchase(amount: number): Promise<{ success: boolean; newBalance: number }> {
    const headers = await getAuthHeaders();
    const response = await fetch(`${CTY_API_URL}/purchase`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ amount }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to purchase CTY');
    }

    return response.json();
  },
};
