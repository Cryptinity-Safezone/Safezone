export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string
          username: string
          handle: string
          avatar_url: string | null
          cover_url: string | null
          plan_type: 'free' | 'personal' | 'creator'
          cty_balance: number
          is_verified: boolean
          is_restricted: boolean
          bio: string | null
          interests: string[]
          background_music_title: string | null
          background_music_artist: string | null
          background_music_url: string | null
          followers_count: number
          following_count: number
          creations_count: number
          onboarding_completed: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          username: string
          handle: string
          avatar_url?: string | null
          cover_url?: string | null
          plan_type?: 'free' | 'personal' | 'creator'
          cty_balance?: number
          is_verified?: boolean
          is_restricted?: boolean
          bio?: string | null
          interests?: string[]
          background_music_title?: string | null
          background_music_artist?: string | null
          background_music_url?: string | null
          followers_count?: number
          following_count?: number
          creations_count?: number
          onboarding_completed?: boolean
        }
        Update: {
          username?: string
          handle?: string
          avatar_url?: string | null
          cover_url?: string | null
          plan_type?: 'free' | 'personal' | 'creator'
          cty_balance?: number
          is_verified?: boolean
          is_restricted?: boolean
          bio?: string | null
          interests?: string[]
          background_music_title?: string | null
          background_music_artist?: string | null
          background_music_url?: string | null
          followers_count?: number
          following_count?: number
          creations_count?: number
          onboarding_completed?: boolean
        }
      }
      posts: {
        Row: {
          id: string
          user_id: string
          content: string
          image_url: string | null
          likes_count: number
          comments_count: number
          created_at: string
          updated_at: string
        }
        Insert: {
          user_id: string
          content: string
          image_url?: string | null
        }
        Update: {
          content?: string
          image_url?: string | null
        }
      }
      cty_transactions: {
        Row: {
          id: string
          user_id: string
          amount: number
          transaction_type: 'earn' | 'spend' | 'purchase' | 'monthly_allowance'
          description: string
          metadata: Json
          created_at: string
        }
        Insert: {
          user_id: string
          amount: number
          transaction_type: 'earn' | 'spend' | 'purchase' | 'monthly_allowance'
          description: string
          metadata?: Json
        }
        Update: never
      }
      user_subscriptions: {
        Row: {
          id: string
          user_id: string
          plan_type: 'free' | 'personal' | 'creator'
          status: 'active' | 'cancelled' | 'expired'
          started_at: string
          expires_at: string | null
          created_at: string
        }
        Insert: {
          user_id: string
          plan_type: 'free' | 'personal' | 'creator'
          status?: 'active' | 'cancelled' | 'expired'
          expires_at?: string | null
        }
        Update: {
          status?: 'active' | 'cancelled' | 'expired'
          expires_at?: string | null
        }
      }
      showcase_items: {
        Row: {
          id: string
          user_id: string
          title: string
          description: string | null
          media_url: string
          media_type: 'image' | 'sound' | 'video'
          order_index: number
          created_at: string
        }
        Insert: {
          user_id: string
          title: string
          description?: string | null
          media_url: string
          media_type: 'image' | 'sound' | 'video'
          order_index?: number
        }
        Update: {
          title?: string
          description?: string | null
          media_url?: string
          order_index?: number
        }
      }
      warehouse_items: {
        Row: {
          id: string
          user_id: string
          name: string
          file_url: string
          file_type: string
          file_size: number
          metadata: Json
          created_at: string
        }
        Insert: {
          user_id: string
          name: string
          file_url: string
          file_type: string
          file_size: number
          metadata?: Json
        }
        Update: {
          name?: string
        }
      }
      follows: {
        Row: {
          id: string
          follower_id: string
          following_id: string
          created_at: string
        }
        Insert: {
          follower_id: string
          following_id: string
        }
        Update: never
      }
      post_likes: {
        Row: {
          id: string
          user_id: string
          post_id: string
          created_at: string
        }
        Insert: {
          user_id: string
          post_id: string
        }
        Update: never
      }
      user_blocks: {
        Row: {
          id: string
          blocker_id: string
          blocked_id: string
          created_at: string
        }
        Insert: {
          blocker_id: string
          blocked_id: string
        }
        Update: never
      }
      hidden_posts: {
        Row: {
          id: string
          user_id: string
          post_id: string
          created_at: string
        }
        Insert: {
          user_id: string
          post_id: string
        }
        Update: never
      }
      post_reports: {
        Row: {
          id: string
          reporter_id: string
          post_id: string
          reason: 'spam' | 'harassment' | 'inappropriate' | 'misleading' | 'other'
          details: string | null
          status: string
          created_at: string
        }
        Insert: {
          reporter_id: string
          post_id: string
          reason: 'spam' | 'harassment' | 'inappropriate' | 'misleading' | 'other'
          details?: string | null
        }
        Update: {
          status?: string
        }
      }
      conversations: {
        Row: {
          id: string
          participant_one: string
          participant_two: string
          last_message_at: string
          created_at: string
        }
        Insert: {
          participant_one: string
          participant_two: string
          last_message_at?: string
        }
        Update: {
          last_message_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          conversation_id: string
          sender_id: string
          content: string
          created_at: string
        }
        Insert: {
          conversation_id: string
          sender_id: string
          content: string
        }
        Update: never
      }
      message_requests: {
        Row: {
          id: string
          sender_id: string
          recipient_id: string
          status: 'pending' | 'accepted' | 'declined'
          created_at: string
          updated_at: string
        }
        Insert: {
          sender_id: string
          recipient_id: string
          status?: 'pending' | 'accepted' | 'declined'
        }
        Update: {
          status?: 'pending' | 'accepted' | 'declined'
          updated_at?: string
        }
      }
      message_reports: {
        Row: {
          id: string
          reporter_id: string
          message_id: string | null
          conversation_id: string
          reason: 'spam' | 'harassment' | 'inappropriate' | 'threats' | 'other'
          details: string | null
          status: string
          created_at: string
        }
        Insert: {
          reporter_id: string
          message_id?: string | null
          conversation_id: string
          reason: 'spam' | 'harassment' | 'inappropriate' | 'threats' | 'other'
          details?: string | null
        }
        Update: {
          status?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
