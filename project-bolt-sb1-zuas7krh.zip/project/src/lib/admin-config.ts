export const ADMIN_CONFIG = {
  enableAdminFeatures: true,
};
