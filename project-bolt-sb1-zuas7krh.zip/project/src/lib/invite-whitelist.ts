const WHITELISTED_EMAILS = [
  'admin@cryptinity.com',
  'test@example.com',
];

export const isEmailWhitelisted = (email: string): boolean => {
  const normalizedEmail = email.toLowerCase().trim();
  return WHITELISTED_EMAILS.some(
    whitelistedEmail => whitelistedEmail.toLowerCase() === normalizedEmail
  );
};
