interface KnowledgeEntry {
  keywords: string[];
  response: string;
  followUp?: string;
}

const knowledgeBase: KnowledgeEntry[] = [
  {
    keywords: ['cty', 'what is cty', 'creative energy', 'credits', 'tokens', 'currency'],
    response: `CTY (pronounced "city") is your creative energy on Cryptinity. Think of it as the spark that powers everything you make here - images, sounds, and more.

It's not money, and it's not meant to be. It's simply a gentle way to keep things balanced so everyone gets to create and explore at their own pace. No rush, no pressure.`,
    followUp: 'Would you like to know how to earn more CTY?',
  },
  {
    keywords: ['earn cty', 'get cty', 'more cty', 'how to earn', 'free cty'],
    response: `There are a few natural ways CTY flows your way:

Just being here and creating earns you some. When others appreciate what you make, that can bring more too. If you ever want a boost, upgrade plans give you a monthly allowance - but plenty of creators thrive on what they earn naturally.

Take your time. There's no race here.`,
  },
  {
    keywords: ['watermark', 'why watermark', 'remove watermark', 'protection', 'watermarked'],
    response: `The soft watermark on AI-generated content is there to help, not limit you. It's a quiet way of saying "this was made here" - which actually builds trust and credibility.

Here's the good part: it vanishes when you download your own work, when someone unlocks your creation, or when you sell it. The watermark is only for previews - never for what you actually own.`,
  },
  {
    keywords: ['ownership', 'who owns', 'my content', 'rights', 'copyright', 'mine'],
    response: `What you create is genuinely yours. When you bring an image or sound to life with our AI, you're the creator and owner - full stop.

The watermark is just a display thing, like a frame in a gallery. It doesn't touch your ownership. Download it, use it, sell it - it's your work to do with as you please.`,
  },
  {
    keywords: ['sell', 'selling', 'marketplace', 'how to sell', 'make money', 'unlock'],
    response: `Selling here is simple: you set a CTY price for your creation, and others can unlock it by spending their CTY.

When someone unlocks your work, they get the clean version - no watermark. You receive CTY that you can use to create more or explore others' work. It's a creative exchange, not a cash transaction - and that's kind of the point.`,
  },
  {
    keywords: ['flagged', 'flag', 'content flagged', 'why flagged', 'similarity', 'similar'],
    response: `If something you made gets flagged, take a breath - it's not a punishment or accusation. Our system sometimes notices when content looks similar to something else and pauses selling just to be careful.

This actually protects you too. Most flags get cleared up quickly once we take a look. In the meantime, your content is still yours to view and use.`,
  },
  {
    keywords: ['safe', 'safety', 'rules', 'community', 'guidelines', 'allowed', 'terms'],
    response: `The basics: be kind, be original, be respectful. Cryptinity is built for genuine creativity, so we just ask that everyone treats each other and the space with care.

Anything harmful, hateful, or meant to deceive doesn't belong here. Everything else? Create freely. Explore openly. That's what this place is for.`,
  },
  {
    keywords: ['safezone', 'safe zone', 'what is safezone', 'zone'],
    response: `SafeZone is the heart of what makes Cryptinity feel different. It's our commitment to keeping this a calm, supportive space where you can create without worry.

No aggressive tactics, no hidden catches. Just a place where your creativity comes first. We handle the technical stuff so you can focus on making things.`,
  },
  {
    keywords: ['block', 'blocked', 'report', 'harassment', 'someone bothering', 'bother'],
    response: `You're always in control of your space here. If someone makes you uncomfortable, you can block them - they won't be able to see your content or reach you anymore.

For more serious concerns, you can report. We look at every report carefully and take action when needed. We don't share details back to protect everyone's privacy, but know that we take this seriously.`,
  },
  {
    keywords: ['account', 'delete', 'leave', 'close account', 'deactivate'],
    response: `If you need a break or decide to leave, that's completely okay. Account options are in your settings whenever you're ready.

Just know that deleting is permanent - your content and CTY won't come back. Take your time with that choice. There's no countdown or pressure.`,
  },
  {
    keywords: ['ai', 'how does ai work', 'artificial intelligence', 'generation', 'generate'],
    response: `Our AI is here to help turn your ideas into something real. You describe what you're imagining - an image, a sound, a vibe - and the AI creates based on your words.

Each creation uses a bit of CTY, which keeps things fair. The more specific you are, the closer the result will match what's in your head. Experiment freely - that's part of the fun.`,
  },
  {
    keywords: ['private', 'privacy', 'who can see', 'public', 'hidden'],
    response: `Everything you create starts private - only you can see it until you decide to share. When you're ready, posting makes it visible to others.

You stay in control of what's public and what's just for you. Your profile, your content, your choice.`,
  },
  {
    keywords: ['upgrade', 'plans', 'subscription', 'pro', 'premium', 'pay'],
    response: `Upgrade plans are there if you want more CTY each month or some extra capabilities. But they're truly optional - not a gate you have to pass through.

Start with what you have and see how it feels. Many creators do amazing work without ever upgrading. There's no wrong path here.`,
  },
  {
    keywords: ['help', 'support', 'contact', 'human', 'real person', 'talk to someone'],
    response: `I'm here for questions about how Cryptinity works - the everyday stuff. For anything more specific, like account issues or complex situations, real humans on the team can help.

Just describe what you need. I'll point you the right way, or help directly if I can.`,
  },
  {
    keywords: ['moderation', 'banned', 'suspended', 'why banned', 'account issue', 'decision'],
    response: `I can explain how things work here, but I can't make moderation decisions or change anything about accounts. Those decisions are made carefully by the team, not by me.

If you have concerns about your account, the team can look into it - I'm just here to help you understand how things work in general.`,
  },
  {
    keywords: ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good evening'],
    response: `Hey! Good to see you here. I'm around to help you understand how Cryptinity works - whether it's about CTY, your content, selling, or just finding your way around.

What's on your mind?`,
  },
  {
    keywords: ['thank', 'thanks', 'appreciate', 'helpful', 'great'],
    response: `Happy to help! If more questions come up as you explore, just come back. I'll be here.

Go make something wonderful.`,
  },
  {
    keywords: ['country', 'available', 'worldwide', 'global', 'region', 'location', 'restricted', 'access', 'where'],
    response: `Cryptinity is available everywhere - no country restrictions, no regional blocks. Creativity doesn't need borders.

SafeZone protections and everything else work the same wherever you are. Everyone's welcome here.`,
  },
  {
    keywords: ['audio', 'sound', 'music', 'audio protection', 'sound watermark'],
    response: `AI-generated sounds play clean in the app - no audible watermark interrupting your experience. We embed quiet metadata that says "Generated via Cryptinity AI" for reference.

When you export sounds you own, they're fully yours. For shared previews, there's a gentle 0.5-second signature - just enough to show where it came from.`,
  },
  {
    keywords: ['download', 'save', 'export', 'get my content'],
    response: `Downloading your own creations is simple - just tap download and you get the clean version, no watermark. It's your work.

If you've unlocked someone else's creation, same thing - you get the clean version. The watermark only appears in public previews.`,
  },
  {
    keywords: ['buy', 'purchase', 'unlock content', 'how to buy'],
    response: `To unlock someone's creation, you spend CTY - the amount they set. Once unlocked, it's yours to download clean, without the watermark.

Think of it less like buying and more like supporting a fellow creator while getting access to their work. The CTY flows to them, and they can use it to create more.`,
  },
  {
    keywords: ['confused', 'dont understand', 'what', 'explain', 'how'],
    response: `No worries - I'm here to help make sense of things. Cryptinity can have a lot going on at first.

Could you tell me a bit more about what's confusing? I'll explain it as simply as I can.`,
  },
  {
    keywords: ['bug', 'broken', 'not working', 'error', 'problem', 'issue'],
    response: `That sounds frustrating. Technical issues happen sometimes, and the team works to fix them.

I can't fix bugs directly, but I can help you understand if what you're seeing is expected behavior or something to report. What's happening?`,
  },
  {
    keywords: ['why', 'reason', 'purpose'],
    response: `Good question. Could you tell me a bit more about what you're asking about?

I want to give you a helpful answer, not just a guess.`,
  },
];

const fallbackResponse = `I want to make sure I understand what you're asking. Could you tell me a bit more?

I can help with things like:
- CTY (creative energy) and how it works
- Content ownership and watermarks
- Selling and unlocking creations
- SafeZone and community guidelines
- Privacy and account questions

What would you like to know?`;

export function findAnswer(question: string): { response: string; followUp?: string } {
  const normalizedQuestion = question.toLowerCase().trim();

  let bestMatch: KnowledgeEntry | null = null;
  let bestScore = 0;

  for (const entry of knowledgeBase) {
    let score = 0;
    for (const keyword of entry.keywords) {
      if (normalizedQuestion.includes(keyword.toLowerCase())) {
        score += keyword.split(' ').length;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = entry;
    }
  }

  if (bestMatch && bestScore > 0) {
    return { response: bestMatch.response, followUp: bestMatch.followUp };
  }

  return { response: fallbackResponse };
}

export const quickQuestions = [
  'What is CTY?',
  'Why are images watermarked?',
  'Who owns my content?',
  'How do I sell my work?',
  'What is SafeZone?',
  'Why was my content flagged?',
];
