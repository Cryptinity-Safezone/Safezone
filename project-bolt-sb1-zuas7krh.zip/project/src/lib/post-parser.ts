export interface ParsedSegment {
  type: 'text' | 'hashtag' | 'mention';
  content: string;
  value?: string;
}

const HASHTAG_REGEX = /#([a-zA-Z][a-zA-Z0-9_]{0,29})/g;
const MENTION_REGEX = /@([a-zA-Z][a-zA-Z0-9_]{0,29})/g;
const MAX_HASHTAGS = 5;

export function parsePostContent(content: string): ParsedSegment[] {
  const segments: ParsedSegment[] = [];
  const combinedRegex = /(?:#([a-zA-Z][a-zA-Z0-9_]{0,29}))|(?:@([a-zA-Z][a-zA-Z0-9_]{0,29}))/g;

  let lastIndex = 0;
  let match;

  while ((match = combinedRegex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      segments.push({
        type: 'text',
        content: content.slice(lastIndex, match.index),
      });
    }

    if (match[1]) {
      segments.push({
        type: 'hashtag',
        content: match[0],
        value: match[1].toLowerCase(),
      });
    } else if (match[2]) {
      segments.push({
        type: 'mention',
        content: match[0],
        value: match[2].toLowerCase(),
      });
    }

    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < content.length) {
    segments.push({
      type: 'text',
      content: content.slice(lastIndex),
    });
  }

  return segments;
}

export function extractHashtags(content: string): string[] {
  const hashtags: string[] = [];
  let match;

  HASHTAG_REGEX.lastIndex = 0;
  while ((match = HASHTAG_REGEX.exec(content)) !== null) {
    const tag = match[1].toLowerCase();
    if (!hashtags.includes(tag)) {
      hashtags.push(tag);
    }
    if (hashtags.length >= MAX_HASHTAGS) break;
  }

  return hashtags;
}

export function extractMentions(content: string): string[] {
  const mentions: string[] = [];
  let match;

  MENTION_REGEX.lastIndex = 0;
  while ((match = MENTION_REGEX.exec(content)) !== null) {
    const mention = match[1].toLowerCase();
    if (!mentions.includes(mention)) {
      mentions.push(mention);
    }
  }

  return mentions;
}

export function validateHashtagCount(content: string): { valid: boolean; count: number } {
  const hashtags = extractHashtags(content);
  return {
    valid: hashtags.length <= MAX_HASHTAGS,
    count: hashtags.length,
  };
}

export function getHashtagsRemaining(content: string): number {
  const { count } = validateHashtagCount(content);
  return Math.max(0, MAX_HASHTAGS - count);
}
