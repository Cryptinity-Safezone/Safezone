export const CTY_COSTS = {
  AI_GENERATION: {
    IMAGE_BASIC: 25,
    IMAGE_ENHANCED: 50,
    IMAGE_PREMIUM: 100,
    SOUND_SHORT: 30,
    SOUND_LONG: 60,
    AMBIENT_BASIC: 20,
    AMBIENT_EXTENDED: 45,
    ABSTRACT_ART: 40,
    MOTION_BASIC: 75,
    MOTION_PREMIUM: 150,
  },

  PROFILE_CUSTOMIZATION: {
    PREMIUM_AVATAR: 50,
    PREMIUM_COVER: 75,
    BACKGROUND_MUSIC: 30,
    THEME_CHANGE: 20,
  },

  STORAGE: {
    WAREHOUSE_ITEM: 5,
    SHOWCASE_ITEM: 10,
  },

  ENGAGEMENT: {
    POST_CREATION: 0,
    COMMENT: 0,
    LIKE: 0,
    FOLLOW: 0,
  },
} as const;

export const CTY_EARNINGS = {
  PROFILE_COMPLETION: 10,
  FIRST_POST: 25,
  DAILY_LOGIN: 5,
  HELPFUL_CONTENT: 15,
} as const;

export const CTY_PACKS = [
  { amount: 250, price: 2 },
  { amount: 600, price: 5 },
  { amount: 1500, price: 10 },
  { amount: 4000, price: 25 },
] as const;

export const PLAN_ALLOWANCES = {
  free: 100,
  personal: 500,
  creator: 1500,
} as const;

export const PLAN_LIMITS = {
  free: {
    warehouse_gb: 1,
    showcase_slots: 2,
    ai_quality: 'standard',
    video_min_duration: 6,
    video_max_duration: 10,
  },
  personal: {
    warehouse_gb: 5,
    showcase_slots: 5,
    ai_quality: 'enhanced',
    video_min_duration: 6,
    video_max_duration: 25,
  },
  creator: {
    warehouse_gb: 20,
    showcase_slots: -1,
    ai_quality: 'premium',
    video_min_duration: 6,
    video_max_duration: 45,
  },
} as const;

export function getVideoDurationLimits(plan: 'free' | 'personal' | 'creator') {
  return {
    min: PLAN_LIMITS[plan].video_min_duration,
    max: PLAN_LIMITS[plan].video_max_duration,
  };
}

export function canAfford(balance: number, cost: number): boolean {
  return balance >= cost;
}

export function getCostDescription(action: string): string {
  switch (action) {
    case 'AI_IMAGE_BASIC':
      return 'Generate AI image (standard quality)';
    case 'AI_IMAGE_ENHANCED':
      return 'Generate AI image (enhanced quality)';
    case 'AI_IMAGE_PREMIUM':
      return 'Generate AI image (premium quality)';
    case 'MOTION_BASIC':
      return 'Generate Living Image (10s motion)';
    case 'MOTION_PREMIUM':
      return 'Generate Living Image (premium quality)';
    case 'PREMIUM_AVATAR':
      return 'Apply premium avatar';
    case 'PREMIUM_COVER':
      return 'Apply premium cover photo';
    default:
      return action;
  }
}
