import { supabase } from './supabase';

export type BucketName = 'avatars' | 'covers' | 'posts' | 'warehouse' | 'showcase';

export const storage = {
  async uploadFile(
    bucket: BucketName,
    userId: string,
    file: File,
    filePrefix?: string
  ): Promise<{ url: string; path: string }> {
    const fileExt = file.name.split('.').pop() || 'jpg';
    const timestamp = Date.now();
    const randomSuffix = Math.random().toString(36).substring(2, 8);
    const baseName = filePrefix || 'file';
    const path = `${userId}/${baseName}_${timestamp}_${randomSuffix}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from(bucket)
      .upload(path, file, {
        upsert: false,
        contentType: file.type,
        cacheControl: '3600',
      });

    if (uploadError) throw uploadError;

    const { data: { publicUrl } } = supabase.storage
      .from(bucket)
      .getPublicUrl(path);

    const urlWithCacheBust = `${publicUrl}?v=${timestamp}`;

    return { url: urlWithCacheBust, path };
  },

  async deleteFile(bucket: BucketName, path: string): Promise<void> {
    const { error } = await supabase.storage.from(bucket).remove([path]);
    if (error) throw error;
  },

  getPublicUrl(bucket: BucketName, path: string): string {
    const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(path);
    return publicUrl;
  },

  async listFiles(bucket: BucketName, userId: string): Promise<any[]> {
    const { data, error } = await supabase.storage.from(bucket).list(userId);
    if (error) throw error;
    return data || [];
  },
};
