import { useEffect, useRef, useCallback, useState } from 'react';
import {
  Home, Compass, MessageCircle, User, Lock, Bookmark, Settings,
  HelpCircle, Zap, MoreHorizontal, LogOut, X, Sparkles, Flower2
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCTY } from '../hooks/useCTY';
import type { ViewState } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
}

const DEFAULT_AVATAR = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cdefs%3E%3ClinearGradient id='bg' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%230d9488'/%3E%3Cstop offset='100%25' style='stop-color:%2310b981'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='100' height='100' rx='20' fill='url(%23bg)'/%3E%3Ctext x='50' y='65' font-family='system-ui,-apple-system,sans-serif' font-size='48' font-weight='600' fill='white' text-anchor='middle'%3EC%3C/text%3E%3C/svg%3E";

interface NavItemProps {
  icon: typeof Home;
  label: string;
  active?: boolean;
  onClick: () => void;
}

const NavItem = ({ icon: Icon, label, active, onClick }: NavItemProps) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl transition-all duration-200 group ${
      active
        ? 'bg-accent-500/15 text-accent-400'
        : 'text-surface-400 hover:bg-white/[0.04] hover:text-surface-200'
    }`}
  >
    <Icon
      size={20}
      strokeWidth={active ? 2.2 : 1.8}
      className={`transition-colors ${active ? 'text-accent-400' : 'text-accent-500/70 group-hover:text-accent-400/80'}`}
    />
    <span className={`text-sm font-medium ${active ? 'text-accent-300' : ''}`}>{label}</span>
  </button>
);

export function Sidebar({ isOpen, onClose, currentView, onNavigate }: SidebarProps) {
  const { profile, signOut } = useAuth();
  const { balance } = useCTY();
  const sidebarRef = useRef<HTMLDivElement>(null);
  const touchStartX = useRef(0);
  const touchCurrentX = useRef(0);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleTouchStart = useCallback((e: TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchCurrentX.current = e.touches[0].clientX;
  }, []);

  const handleTouchMove = useCallback((e: TouchEvent) => {
    touchCurrentX.current = e.touches[0].clientX;
  }, []);

  const handleTouchEnd = useCallback(() => {
    const diff = touchStartX.current - touchCurrentX.current;
    if (diff > 80 && isOpen) {
      onClose();
    }
  }, [isOpen, onClose]);

  useEffect(() => {
    const sidebar = sidebarRef.current;
    if (!sidebar) return;

    sidebar.addEventListener('touchstart', handleTouchStart, { passive: true });
    sidebar.addEventListener('touchmove', handleTouchMove, { passive: true });
    sidebar.addEventListener('touchend', handleTouchEnd, { passive: true });

    return () => {
      sidebar.removeEventListener('touchstart', handleTouchStart);
      sidebar.removeEventListener('touchmove', handleTouchMove);
      sidebar.removeEventListener('touchend', handleTouchEnd);
    };
  }, [handleTouchStart, handleTouchMove, handleTouchEnd]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const handleNavigate = (view: ViewState) => {
    onNavigate(view);
    onClose();
  };

  const handleSignOut = async () => {
    await signOut();
    onClose();
  };

  const handleOpenGarden = () => {
    window.dispatchEvent(new CustomEvent('open-garden'));
    onClose();
  };

  const avatarUrl = profile?.avatar_url || DEFAULT_AVATAR;
  const displayName = profile?.username || 'User';
  const handle = profile?.handle || 'user';
  const planType = profile?.plan_type || 'free';

  const getPlanLabel = () => {
    switch (planType) {
      case 'creator': return 'Creator';
      case 'personal': return 'Personal';
      default: return 'Member';
    }
  };

  return (
    <>
      <div
        className={`fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
        aria-hidden="true"
      />

      <aside
        ref={sidebarRef}
        className={`fixed top-0 left-0 z-[70] h-full w-[280px] bg-[#0c0c0d] border-r border-white/[0.06] flex flex-col transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        aria-label="Main navigation"
      >
        <div className="flex items-center justify-between p-4 border-b border-white/[0.04]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl overflow-hidden">
              <img src="/711-removebg-preview.png" alt="Cryptinity" className="w-full h-full object-contain" />
            </div>
            <span className="font-semibold text-white/90 text-base">Cryptinity</span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-surface-500 hover:text-white hover:bg-white/[0.06] transition-all"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-4 border-b border-white/[0.04]">
          <div className="flex items-start gap-3.5">
            <div className="relative">
              <div className="w-14 h-14 rounded-full overflow-hidden ring-2 ring-accent-500/20">
                <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-accent-500 rounded-full border-2 border-[#0c0c0d]" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-white truncate">{displayName}</div>
              <div className="text-sm text-surface-500 truncate">@{handle}</div>
              <div className="flex items-center gap-1.5 mt-2">
                <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-gradient-to-r from-amber-500/10 to-yellow-500/10 border border-amber-500/20">
                  <Zap size={12} className="text-amber-400 fill-amber-400" />
                  <span className="text-xs font-bold text-amber-300">{balance.toLocaleString()}</span>
                  <span className="text-[10px] text-amber-400/70">CTY</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-3 px-3">
          <div className="space-y-0.5">
            <NavItem
              icon={Home}
              label="Home / Feed"
              active={currentView === 'feed'}
              onClick={() => handleNavigate('feed')}
            />
            <NavItem
              icon={Compass}
              label="Explore"
              active={currentView === 'explore'}
              onClick={() => handleNavigate('explore')}
            />
            <NavItem
              icon={Sparkles}
              label="Create"
              active={currentView === 'create'}
              onClick={() => handleNavigate('create')}
            />
            <NavItem
              icon={MessageCircle}
              label="Messages"
              active={currentView === 'messages'}
              onClick={() => handleNavigate('messages')}
            />
            <button
              onClick={handleOpenGarden}
              className="w-full flex items-center gap-3.5 px-4 py-3 rounded-xl transition-all duration-200 group text-emerald-400/80 hover:bg-emerald-500/10 hover:text-emerald-300 relative"
            >
              <Flower2
                size={20}
                strokeWidth={1.8}
                className="text-emerald-500/70 group-hover:text-emerald-400"
              />
              <span className="text-sm font-medium">Hidden Garden</span>
              <span className="absolute right-3 top-1/2 -translate-y-1/2 px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                LIVE
              </span>
            </button>
            <NavItem
              icon={User}
              label="Profile"
              active={currentView === 'profile'}
              onClick={() => handleNavigate('profile')}
            />
            <NavItem
              icon={Lock}
              label="My Warehouse"
              active={currentView === 'warehouse'}
              onClick={() => handleNavigate('warehouse')}
            />
            <NavItem
              icon={Bookmark}
              label="Saved / Wishlist"
              active={false}
              onClick={() => {}}
            />
          </div>

          <div className="my-4 mx-2 h-px bg-gradient-to-r from-transparent via-white/[0.06] to-transparent" />

          <div className="space-y-0.5">
            <NavItem
              icon={Settings}
              label="Settings"
              active={currentView === 'settings'}
              onClick={() => handleNavigate('settings')}
            />
            <NavItem
              icon={HelpCircle}
              label="Help Center"
              active={currentView === 'help'}
              onClick={() => handleNavigate('help')}
            />
          </div>
        </nav>

        <div className="p-3 border-t border-white/[0.04]">
          <div className="relative">
            <button
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:bg-white/[0.04] transition-all"
            >
              <div className="w-10 h-10 rounded-full overflow-hidden ring-1 ring-white/10">
                <img src={avatarUrl} alt={displayName} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0 text-left">
                <div className="text-sm font-medium text-white truncate">{displayName}</div>
                <div className="text-xs text-accent-400/80">{getPlanLabel()}</div>
              </div>
              <MoreHorizontal size={18} className="text-surface-500" />
            </button>

            {showProfileMenu && (
              <div className="absolute bottom-full left-0 right-0 mb-2 py-1.5 bg-[#141415] rounded-xl border border-white/[0.08] shadow-xl overflow-hidden">
                <button
                  onClick={handleSignOut}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-left text-red-400 hover:bg-red-500/10 transition-colors"
                >
                  <LogOut size={16} />
                  <span className="text-sm font-medium">Sign Out</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
}
