import { useState } from 'react';
import { MoreHorizontal, EyeOff, Flag, UserX, X, BellOff } from 'lucide-react';
import { useMutedUsers } from '../../hooks/useMutedUsers';

interface PostActionsProps {
  postId: string;
  authorId: string;
  onHide: (postId: string) => void;
  onReport: (postId: string, reason: string, details?: string) => void;
  onBlock: (userId: string) => void;
}

type ReportReason = 'spam' | 'harassment' | 'inappropriate' | 'misleading' | 'other';

const reportReasons: { value: ReportReason; label: string }[] = [
  { value: 'spam', label: 'Spam or misleading' },
  { value: 'harassment', label: 'Harassment or hate' },
  { value: 'inappropriate', label: 'Inappropriate content' },
  { value: 'misleading', label: 'False information' },
  { value: 'other', label: 'Something else' },
];

export const PostActions = ({ postId, authorId, onHide, onReport, onBlock }: PostActionsProps) => {
  const { areMentionsMuted, muteUser, unmuteUser, mutedUsers } = useMutedUsers();
  const [showMenu, setShowMenu] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [showReportConfirmation, setShowReportConfirmation] = useState(false);
  const [showBlockConfirmation, setShowBlockConfirmation] = useState(false);
  const [showMuteConfirmation, setShowMuteConfirmation] = useState(false);
  const [selectedReason, setSelectedReason] = useState<ReportReason>('spam');
  const [reportDetails, setReportDetails] = useState('');

  const isMuted = areMentionsMuted(authorId);

  const handleToggleMute = async () => {
    try {
      if (isMuted) {
        const muteEntry = mutedUsers.find(m => m.muted_user_id === authorId);
        if (muteEntry) {
          await unmuteUser(muteEntry.id);
        }
      } else {
        await muteUser(authorId, true);
      }
      setShowMenu(false);
      setShowMuteConfirmation(true);
      setTimeout(() => setShowMuteConfirmation(false), 3000);
    } catch (error) {
      console.error('Failed to toggle mute:', error);
    }
  };

  const handleHide = () => {
    onHide(postId);
    setShowMenu(false);
  };

  const handleReportSubmit = () => {
    onReport(postId, selectedReason, reportDetails || undefined);
    setShowReportModal(false);
    setShowMenu(false);
    setReportDetails('');
    setShowReportConfirmation(true);
    setTimeout(() => setShowReportConfirmation(false), 3000);
  };

  const handleBlockSubmit = () => {
    onBlock(authorId);
    setShowBlockModal(false);
    setShowMenu(false);
    setShowBlockConfirmation(true);
    setTimeout(() => setShowBlockConfirmation(false), 3000);
  };

  return (
    <>
      <div className="relative">
        <button
          onClick={() => setShowMenu(!showMenu)}
          className="w-9 h-9 flex items-center justify-center rounded-xl text-surface-500/70 hover:text-white/80 hover:bg-white/[0.03] transition-all duration-200"
        >
          <MoreHorizontal size={18} />
        </button>

        {showMenu && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setShowMenu(false)}
            />
            <div className="absolute right-0 top-full mt-2 w-52 card p-2 z-50 animate-fade-in">
              <button
                onClick={handleHide}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-surface-300/80 hover:text-white/90 hover:bg-white/[0.04] transition-all duration-200 text-left"
              >
                <EyeOff size={16} />
                <span className="text-sm font-medium">Hide post</span>
              </button>
              <button
                onClick={handleToggleMute}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-surface-300/80 hover:text-white/90 hover:bg-white/[0.04] transition-all duration-200 text-left"
              >
                <BellOff size={16} />
                <span className="text-sm font-medium">{isMuted ? 'Unmute mentions' : 'Mute mentions'}</span>
              </button>
              <button
                onClick={() => {
                  setShowReportModal(true);
                  setShowMenu(false);
                }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-surface-300/80 hover:text-white/90 hover:bg-white/[0.04] transition-all duration-200 text-left"
              >
                <Flag size={16} />
                <span className="text-sm font-medium">Report</span>
              </button>
              <button
                onClick={() => {
                  setShowBlockModal(true);
                  setShowMenu(false);
                }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-red-400/80 hover:text-red-400 hover:bg-red-500/5 transition-all duration-200 text-left"
              >
                <UserX size={16} />
                <span className="text-sm font-medium">Block user</span>
              </button>
            </div>
          </>
        )}
      </div>

      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4 animate-fade-in">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowReportModal(false)}
          />
          <div className="relative w-full max-w-md card p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white/95">Report Post</h3>
              <button
                onClick={() => setShowReportModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-xl text-surface-400/80 hover:text-white/80 hover:bg-white/[0.04] transition-all duration-200"
              >
                <X size={18} />
              </button>
            </div>

            <p className="text-sm text-white/60 mb-6 font-light leading-[1.7]">
              Help us understand what's wrong. Your report is anonymous and helps keep Cryptinity safe.
            </p>

            <div className="space-y-2 mb-6">
              {reportReasons.map((reason) => (
                <button
                  key={reason.value}
                  onClick={() => setSelectedReason(reason.value)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 text-left ${
                    selectedReason === reason.value
                      ? 'bg-accent-500/10 border border-accent-500/30 text-white/90'
                      : 'bg-white/[0.02] border border-white/[0.04] text-surface-300/80 hover:bg-white/[0.04] hover:border-white/[0.08]'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full border-2 flex items-center justify-center transition-colors ${
                      selectedReason === reason.value
                        ? 'border-accent-400 bg-accent-400'
                        : 'border-surface-500/50'
                    }`}
                  >
                    {selectedReason === reason.value && (
                      <div className="w-2 h-2 bg-white rounded-full" />
                    )}
                  </div>
                  <span className="text-sm font-medium">{reason.label}</span>
                </button>
              ))}
            </div>

            <textarea
              value={reportDetails}
              onChange={(e) => setReportDetails(e.target.value)}
              placeholder="Additional details (optional)"
              className="w-full px-4 py-3 bg-white/[0.02] border border-white/[0.06] rounded-xl text-white/90 placeholder-surface-600/60 resize-none outline-none text-sm leading-[1.7] mb-6 focus:border-accent-500/30 focus:bg-white/[0.03] transition-all"
              rows={3}
            />

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowReportModal(false)}
                className="flex-1 px-5 py-3 text-sm text-surface-400/80 hover:text-white/80 transition-colors duration-200 font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleReportSubmit}
                className="flex-1 px-5 py-3 bg-gradient-to-r from-accent-500/90 to-teal-600/90 text-white text-sm font-medium rounded-xl hover:from-accent-500 hover:to-teal-600 transition-all duration-200 shadow-lg shadow-accent-500/10"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}

      {showBlockModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4 animate-fade-in">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowBlockModal(false)}
          />
          <div className="relative w-full max-w-md card p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white/95">Block User</h3>
              <button
                onClick={() => setShowBlockModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-xl text-surface-400/80 hover:text-white/80 hover:bg-white/[0.04] transition-all duration-200"
              >
                <X size={18} />
              </button>
            </div>

            <p className="text-sm text-white/70 mb-6 font-light leading-[1.7]">
              When you block someone:
            </p>

            <ul className="space-y-3 mb-6">
              <li className="flex items-start gap-3 text-sm text-white/60 font-light leading-[1.7]">
                <span className="text-accent-400/60">•</span>
                They won't see your posts or profile
              </li>
              <li className="flex items-start gap-3 text-sm text-white/60 font-light leading-[1.7]">
                <span className="text-accent-400/60">•</span>
                You won't see their content
              </li>
              <li className="flex items-start gap-3 text-sm text-white/60 font-light leading-[1.7]">
                <span className="text-accent-400/60">•</span>
                You can unblock them anytime from settings
              </li>
            </ul>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowBlockModal(false)}
                className="flex-1 px-5 py-3 text-sm text-surface-400/80 hover:text-white/80 transition-colors duration-200 font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleBlockSubmit}
                className="flex-1 px-5 py-3 bg-red-500/10 border border-red-500/20 text-red-400 text-sm font-medium rounded-xl hover:bg-red-500/15 hover:border-red-500/30 transition-all duration-200"
              >
                Block User
              </button>
            </div>
          </div>
        </div>
      )}

      {showReportConfirmation && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
          <div className="px-6 py-4 bg-surface-900/95 border border-accent-500/20 rounded-2xl backdrop-blur-xl shadow-2xl text-center max-w-sm">
            <p className="text-white/90 font-medium mb-1">Thank you for helping keep Cryptinity safe.</p>
            <p className="text-sm text-surface-400">We'll review this with care.</p>
          </div>
        </div>
      )}

      {showBlockConfirmation && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
          <div className="px-6 py-4 bg-surface-900/95 border border-red-500/20 rounded-2xl backdrop-blur-xl shadow-2xl text-center max-w-sm">
            <p className="text-white/90 font-medium mb-1">This user is now blocked.</p>
            <p className="text-sm text-surface-400">You won't see each other anymore.</p>
          </div>
        </div>
      )}

      {showMuteConfirmation && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
          <div className="px-6 py-4 bg-surface-900/95 border border-accent-500/20 rounded-2xl backdrop-blur-xl shadow-2xl text-center max-w-sm">
            <p className="text-white/90 font-medium mb-1">
              {isMuted ? 'Mentions unmuted' : 'Mentions muted'}
            </p>
            <p className="text-sm text-surface-400">
              {isMuted ? "You'll now receive notifications from this user." : "You won't be notified when this user mentions you."}
            </p>
          </div>
        </div>
      )}
    </>
  );
};
