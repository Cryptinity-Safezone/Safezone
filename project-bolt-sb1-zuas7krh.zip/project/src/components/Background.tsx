export const Background = () => (
  <div className="fixed inset-0 z-[-1] bg-[#0a0a0b] overflow-hidden pointer-events-none">
    <div className="absolute top-[-20%] left-[-10%] w-[800px] h-[800px] bg-accent-900/5 rounded-full blur-[180px] opacity-20 animate-pulse" style={{ animationDuration: '8s' }} />
    <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-teal-900/5 rounded-full blur-[160px] opacity-15 animate-pulse" style={{ animationDuration: '10s' }} />
    <div className="absolute top-[40%] right-[20%] w-[400px] h-[400px] bg-accent-800/3 rounded-full blur-[120px] opacity-10" />
    <div className="absolute inset-0 opacity-[0.02] mix-blend-overlay noise-overlay" />
    <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0b] via-[#0a0a0b]/80 to-[#0a0a0b]" />
  </div>
);
