import { useState } from 'react';
import { FolderPlus, Check, Loader2 } from 'lucide-react';
import { useShowcase, AddToShowcaseParams } from '../../hooks/useShowcase';

interface AddToShowcaseButtonProps {
  title: string;
  description?: string;
  mediaUrl: string;
  mediaType: 'image' | 'video' | 'audio' | 'motion';
  sourceId: string;
  sourceType: 'generated_images' | 'motion_generations' | 'ai_generated_sounds';
  variant?: 'button' | 'icon' | 'compact';
  className?: string;
  onSuccess?: () => void;
}

export function AddToShowcaseButton({
  title,
  description,
  mediaUrl,
  mediaType,
  sourceId,
  sourceType,
  variant = 'button',
  className = '',
  onSuccess
}: AddToShowcaseButtonProps) {
  const { addToShowcase, isInShowcase } = useShowcase();
  const [adding, setAdding] = useState(false);
  const [success, setSuccess] = useState(false);

  const alreadyAdded = isInShowcase(sourceId, sourceType);

  const handleAdd = async () => {
    if (adding || alreadyAdded || success) return;

    setAdding(true);
    const params: AddToShowcaseParams = {
      title,
      description,
      mediaUrl,
      mediaType,
      sourceId,
      sourceType,
    };

    const result = await addToShowcase(params);
    setAdding(false);

    if (result) {
      setSuccess(true);
      onSuccess?.();
    }
  };

  const isDisabled = adding || alreadyAdded || success;
  const showCheck = alreadyAdded || success;

  if (variant === 'icon') {
    return (
      <button
        onClick={handleAdd}
        disabled={isDisabled}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
          showCheck
            ? 'bg-teal-500/20 text-teal-400'
            : 'bg-surface-800/80 text-surface-400 hover:text-accent-400 hover:bg-accent-500/10'
        } ${className}`}
        title={showCheck ? 'In Showcase' : 'Add to Showcase'}
      >
        {adding ? (
          <Loader2 size={16} className="animate-spin" />
        ) : showCheck ? (
          <Check size={16} />
        ) : (
          <FolderPlus size={16} />
        )}
      </button>
    );
  }

  if (variant === 'compact') {
    return (
      <button
        onClick={handleAdd}
        disabled={isDisabled}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
          showCheck
            ? 'bg-teal-500/20 text-teal-400'
            : 'bg-surface-800/80 text-surface-400 hover:text-accent-400 hover:bg-accent-500/10'
        } ${className}`}
      >
        {adding ? (
          <Loader2 size={12} className="animate-spin" />
        ) : showCheck ? (
          <Check size={12} />
        ) : (
          <FolderPlus size={12} />
        )}
        <span>{showCheck ? 'In Showcase' : 'Showcase'}</span>
      </button>
    );
  }

  return (
    <button
      onClick={handleAdd}
      disabled={isDisabled}
      className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
        showCheck
          ? 'bg-teal-500/20 text-teal-400 border border-teal-500/30'
          : 'glass text-surface-300 hover:text-accent-400 hover:border-accent-500/30'
      } ${className}`}
    >
      {adding ? (
        <Loader2 size={16} className="animate-spin" />
      ) : showCheck ? (
        <Check size={16} />
      ) : (
        <FolderPlus size={16} />
      )}
      <span>{showCheck ? 'In Showcase' : 'Add to Showcase'}</span>
    </button>
  );
}
