import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, User, X, Minimize2, Maximize2 } from 'lucide-react';
import { findAnswer, quickQuestions } from '../../lib/assistant-knowledge';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AskCryptinityProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuestion?: string;
  variant?: 'modal' | 'embedded';
}

export function AskCryptinity({
  isOpen,
  onClose,
  initialQuestion,
  variant = 'modal'
}: AskCryptinityProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage: Message = {
        id: 'welcome',
        role: 'assistant',
        content: `Hey! I'm here to help you understand how Cryptinity works. Ask me anything about CTY, content ownership, selling, or just how to get around.

What would you like to know?`,
        timestamp: new Date(),
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen, messages.length]);

  useEffect(() => {
    if (isOpen && initialQuestion && messages.length === 1) {
      handleSend(initialQuestion);
    }
  }, [isOpen, initialQuestion, messages.length]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (isOpen && !isMinimized) {
      inputRef.current?.focus();
    }
  }, [isOpen, isMinimized]);

  const handleSend = async (text?: string) => {
    const messageText = text || input.trim();
    if (!messageText) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: messageText,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    await new Promise(resolve => setTimeout(resolve, 600 + Math.random() * 400));

    const { response, followUp } = findAnswer(messageText);

    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: followUp ? `${response}\n\n${followUp}` : response,
      timestamp: new Date(),
    };

    setIsTyping(false);
    setMessages(prev => [...prev, assistantMessage]);
  };

  const handleQuickQuestion = (question: string) => {
    handleSend(question);
  };

  if (!isOpen) return null;

  if (variant === 'embedded') {
    return (
      <div className="flex flex-col h-full">
        <ChatContent
          messages={messages}
          isTyping={isTyping}
          messagesEndRef={messagesEndRef}
          showQuickQuestions={messages.length <= 1}
          onQuickQuestion={handleQuickQuestion}
        />
        <ChatInput
          input={input}
          setInput={setInput}
          onSend={() => handleSend()}
          inputRef={inputRef}
        />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      <div
        className={`relative w-full max-w-lg bg-surface-900 border border-white/[0.08] rounded-2xl shadow-2xl overflow-hidden transition-all duration-300 ${
          isMinimized ? 'h-14' : 'h-[600px] max-h-[80vh]'
        }`}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/[0.06] bg-surface-800/50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-accent-500 to-teal-600 flex items-center justify-center">
              <Sparkles size={16} className="text-white" />
            </div>
            <div>
              <h3 className="text-sm font-medium text-white">Ask Cryptinity</h3>
              <p className="text-[10px] text-surface-500">Here to help</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              className="p-2 rounded-lg hover:bg-white/[0.06] text-surface-400 hover:text-white transition-colors"
            >
              {isMinimized ? <Maximize2 size={16} /> : <Minimize2 size={16} />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-white/[0.06] text-surface-400 hover:text-white transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {!isMinimized && (
          <>
            <ChatContent
              messages={messages}
              isTyping={isTyping}
              messagesEndRef={messagesEndRef}
              showQuickQuestions={messages.length <= 1}
              onQuickQuestion={handleQuickQuestion}
            />
            <ChatInput
              input={input}
              setInput={setInput}
              onSend={() => handleSend()}
              inputRef={inputRef}
            />
          </>
        )}
      </div>
    </div>
  );
}

function ChatContent({
  messages,
  isTyping,
  messagesEndRef,
  showQuickQuestions,
  onQuickQuestion,
}: {
  messages: Message[];
  isTyping: boolean;
  messagesEndRef: React.RefObject<HTMLDivElement>;
  showQuickQuestions: boolean;
  onQuickQuestion: (q: string) => void;
}) {
  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.map((message) => (
        <div
          key={message.id}
          className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
        >
          <div
            className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${
              message.role === 'assistant'
                ? 'bg-gradient-to-br from-accent-500 to-teal-600'
                : 'bg-surface-700'
            }`}
          >
            {message.role === 'assistant' ? (
              <Sparkles size={12} className="text-white" />
            ) : (
              <User size={12} className="text-surface-300" />
            )}
          </div>
          <div
            className={`max-w-[80%] px-4 py-3 rounded-2xl ${
              message.role === 'assistant'
                ? 'bg-surface-800/80 text-surface-200 rounded-tl-md'
                : 'bg-accent-500/20 text-white rounded-tr-md'
            }`}
          >
            <p className="text-sm leading-relaxed whitespace-pre-line">
              {message.content}
            </p>
          </div>
        </div>
      ))}

      {isTyping && (
        <div className="flex gap-3">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-accent-500 to-teal-600 flex items-center justify-center">
            <Sparkles size={12} className="text-white" />
          </div>
          <div className="px-4 py-3 rounded-2xl rounded-tl-md bg-surface-800/80">
            <div className="flex gap-1.5">
              <span className="w-2 h-2 rounded-full bg-surface-500 animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-2 h-2 rounded-full bg-surface-500 animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-2 h-2 rounded-full bg-surface-500 animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        </div>
      )}

      {showQuickQuestions && !isTyping && (
        <div className="pt-2">
          <p className="text-xs text-surface-500 mb-3">Quick questions:</p>
          <div className="flex flex-wrap gap-2">
            {quickQuestions.map((question) => (
              <button
                key={question}
                onClick={() => onQuickQuestion(question)}
                className="px-3 py-1.5 rounded-full bg-surface-800/60 border border-white/[0.06] text-xs text-surface-300 hover:text-white hover:bg-surface-700/60 transition-colors"
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
}

function ChatInput({
  input,
  setInput,
  onSend,
  inputRef,
}: {
  input: string;
  setInput: (v: string) => void;
  onSend: () => void;
  inputRef: React.RefObject<HTMLInputElement>;
}) {
  return (
    <div className="p-4 border-t border-white/[0.06] bg-surface-800/30">
      <div className="flex gap-2">
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && onSend()}
          placeholder="Ask me anything..."
          className="flex-1 px-4 py-2.5 rounded-xl bg-surface-800/80 border border-white/[0.06] text-white text-sm placeholder:text-surface-500 focus:outline-none focus:border-accent-500/50 transition-colors"
        />
        <button
          onClick={onSend}
          disabled={!input.trim()}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-accent-500 to-teal-600 text-white font-medium text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-accent-500/20 transition-all"
        >
          <Send size={16} />
        </button>
      </div>
      <p className="text-[10px] text-surface-600 text-center mt-2">
        I provide general guidance only, not account decisions.
      </p>
    </div>
  );
}
