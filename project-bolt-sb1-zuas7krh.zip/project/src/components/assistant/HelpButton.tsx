import { HelpCircle } from 'lucide-react';

interface HelpButtonProps {
  question?: string;
  onClick: (question?: string) => void;
  size?: 'sm' | 'md';
  className?: string;
}

export function HelpButton({
  question,
  onClick,
  size = 'sm',
  className = '',
}: HelpButtonProps) {
  const sizeClasses = {
    sm: 'w-5 h-5',
    md: 'w-6 h-6',
  };

  const iconSize = size === 'sm' ? 12 : 14;

  return (
    <button
      onClick={() => onClick(question)}
      className={`${sizeClasses[size]} rounded-full bg-surface-800/60 border border-white/[0.06] flex items-center justify-center text-surface-500 hover:text-accent-400 hover:border-accent-500/30 hover:bg-accent-500/10 transition-all ${className}`}
      title={question ? `Ask: ${question}` : 'Get help'}
    >
      <HelpCircle size={iconSize} />
    </button>
  );
}
