import { Zap, Settings, Menu } from 'lucide-react';
import { useCTY } from '../hooks/useCTY';
import { NotificationsDropdown } from './notifications';

interface HeaderProps {
  onUpgradeClick?: () => void;
  onSettingsClick?: () => void;
  onMenuClick?: () => void;
}

export const Header = ({ onUpgradeClick, onSettingsClick, onMenuClick }: HeaderProps) => {
  const { balance } = useCTY();

  return (
    <header className="fixed top-0 left-0 right-0 z-40 px-3 sm:px-4 h-16 sm:h-20 flex items-center justify-between bg-gradient-to-b from-[#0a0a0b] via-[#0a0a0b]/98 to-transparent backdrop-blur-xl">
      <div className="flex items-center gap-2">
        <button
          onClick={onMenuClick}
          className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl bg-white/[0.03] border border-white/[0.06] text-surface-400 hover:text-white/90 hover:bg-white/[0.05] transition-all duration-200"
          aria-label="Open menu"
        >
          <Menu size={18} />
        </button>
        <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center overflow-hidden">
          <img src="/711-removebg-preview.png" alt="Cryptinity" className="w-full h-full object-contain" />
        </div>
        <div className="hidden xs:flex flex-col">
          <span className="font-semibold text-white/95 tracking-tight text-sm sm:text-base">
            Cryptinity<span className="text-accent-400/80">.</span>
          </span>
          <span className="text-[8px] sm:text-[9px] text-surface-500/70 font-medium tracking-widest uppercase">SafeZone</span>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        <div className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl bg-white/[0.03] border border-white/[0.06]">
          <NotificationsDropdown />
        </div>

        <button
          onClick={onSettingsClick}
          className="relative w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl bg-white/[0.03] border border-white/[0.06] text-surface-400 hover:text-white/90 hover:bg-white/[0.05] transition-all duration-200"
        >
          <Settings size={18} />
        </button>

        <button
          onClick={onUpgradeClick}
          className="relative flex items-center gap-1.5 sm:gap-2.5 px-3 sm:px-5 py-2 sm:py-2.5 bg-gradient-to-br from-accent-500/10 via-teal-500/10 to-accent-500/10 border border-accent-500/20 rounded-xl sm:rounded-2xl backdrop-blur-xl hover:border-accent-500/30 transition-all duration-300 group overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-accent-500/0 via-accent-500/5 to-accent-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <div className="relative w-5 h-5 rounded-lg bg-gradient-to-br from-yellow-400 to-amber-500 flex items-center justify-center shadow-[0_0_12px_rgba(251,191,36,0.3)] group-hover:shadow-[0_0_16px_rgba(251,191,36,0.5)] transition-all">
            <Zap size={13} className="text-amber-950 fill-amber-950" />
          </div>
          <span className="relative text-xs sm:text-sm font-bold text-white/95 tabular-nums tracking-tight">{balance.toLocaleString()}</span>
          <span className="relative text-[10px] sm:text-xs font-medium text-accent-400/70">CTY</span>
        </button>
      </div>
    </header>
  );
};
