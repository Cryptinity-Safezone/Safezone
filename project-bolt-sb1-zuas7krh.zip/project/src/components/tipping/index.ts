export { TipModal } from './TipModal';
