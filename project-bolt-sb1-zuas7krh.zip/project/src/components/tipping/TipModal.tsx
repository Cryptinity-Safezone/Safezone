import { useState, useEffect } from 'react';
import { X, Zap, AlertCircle, Check, Crown } from 'lucide-react';
import { useTipping } from '../../hooks/useTipping';
import { useCTY } from '../../hooks/useCTY';

interface TipModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipientId: string;
  recipientName: string;
  postId?: string;
}

const TIP_PRESETS = [5, 10, 25, 50, 100];

export function TipModal({ isOpen, onClose, recipientId, recipientName, postId }: TipModalProps) {
  const [amount, setAmount] = useState(10);
  const [customAmount, setCustomAmount] = useState('');
  const [message, setMessage] = useState('');
  const [canTipStatus, setCanTipStatus] = useState<{ allowed: boolean; reason?: string } | null>(null);
  const [success, setSuccess] = useState(false);
  const { sendTip, canTip, loading, error, clearError } = useTipping();
  const { balance, refreshBalance } = useCTY();

  useEffect(() => {
    if (isOpen) {
      setAmount(10);
      setCustomAmount('');
      setMessage('');
      setSuccess(false);
      clearError();
      checkCanTip();
    }
  }, [isOpen]);

  const checkCanTip = async () => {
    const result = await canTip();
    setCanTipStatus(result);
  };

  const handlePresetClick = (preset: number) => {
    setAmount(preset);
    setCustomAmount('');
  };

  const handleCustomChange = (value: string) => {
    const num = parseInt(value, 10);
    if (value === '' || (!isNaN(num) && num >= 1 && num <= 1000)) {
      setCustomAmount(value);
      if (value !== '' && !isNaN(num)) {
        setAmount(num);
      }
    }
  };

  const handleSendTip = async () => {
    const result = await sendTip(recipientId, amount, postId, message || undefined);
    if (result.success) {
      setSuccess(true);
      refreshBalance();
      setTimeout(() => {
        onClose();
      }, 2000);
    }
  };

  if (!isOpen) return null;

  const insufficientBalance = balance < amount;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-surface-900 border border-white/10 rounded-3xl overflow-hidden shadow-2xl animate-slide-up">
        <div className="p-6 border-b border-white/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-yellow-500/10 flex items-center justify-center">
                <Zap size={20} className="text-yellow-400 fill-yellow-400" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-white">Send a Tip</h2>
                <p className="text-sm text-surface-500">to {recipientName}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-white/5 flex items-center justify-center text-surface-400 hover:text-white hover:bg-white/10 transition-all"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="p-6">
          {success ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-green-500/10 border border-green-500/20 flex items-center justify-center mx-auto mb-4">
                <Check size={32} className="text-green-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Tip Sent!</h3>
              <p className="text-surface-400">
                You sent {amount} CTY to {recipientName}
              </p>
            </div>
          ) : canTipStatus && !canTipStatus.allowed ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center mx-auto mb-4">
                <Crown size={32} className="text-yellow-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Subscription Required</h3>
              <p className="text-surface-400 mb-6">{canTipStatus.reason}</p>
              <button
                onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'upgrade' }))}
                className="px-6 py-3 bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-semibold rounded-xl hover:from-yellow-400 hover:to-orange-400 transition-all"
              >
                View Plans
              </button>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <label className="block text-sm text-surface-400 mb-3">Select Amount</label>
                <div className="flex flex-wrap gap-2">
                  {TIP_PRESETS.map((preset) => (
                    <button
                      key={preset}
                      onClick={() => handlePresetClick(preset)}
                      className={`flex-1 min-w-[60px] py-3 rounded-xl font-semibold text-sm transition-all ${
                        amount === preset && customAmount === ''
                          ? 'bg-yellow-500/20 border-2 border-yellow-500 text-yellow-400'
                          : 'bg-white/5 border border-white/10 text-surface-300 hover:border-yellow-500/30'
                      }`}
                    >
                      {preset} CTY
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm text-surface-400 mb-2">Custom Amount</label>
                <div className="relative">
                  <input
                    type="number"
                    value={customAmount}
                    onChange={(e) => handleCustomChange(e.target.value)}
                    placeholder="1-1000"
                    min="1"
                    max="1000"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-surface-600 focus:outline-none focus:border-yellow-500/50 transition-colors"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-surface-500 text-sm">CTY</span>
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm text-surface-400 mb-2">Message (optional)</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value.slice(0, 200))}
                  placeholder="Say something nice..."
                  rows={2}
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-surface-600 focus:outline-none focus:border-yellow-500/50 transition-colors resize-none"
                />
                <p className="text-xs text-surface-600 text-right mt-1">{message.length}/200</p>
              </div>

              <div className="p-4 bg-white/5 rounded-xl mb-6">
                <div className="flex items-center justify-between">
                  <span className="text-surface-400">Your Balance</span>
                  <div className="flex items-center gap-1.5">
                    <Zap size={14} className="text-teal-400 fill-teal-400" />
                    <span className="font-semibold text-white">{balance.toLocaleString()} CTY</span>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
                  <span className="text-surface-400">Tip Amount</span>
                  <span className={`font-semibold ${insufficientBalance ? 'text-red-400' : 'text-yellow-400'}`}>
                    -{amount} CTY
                  </span>
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-xl mb-4 text-red-400 text-sm">
                  <AlertCircle size={16} />
                  {error}
                </div>
              )}

              {insufficientBalance && (
                <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-xl mb-4 text-red-400 text-sm">
                  <AlertCircle size={16} />
                  Insufficient CTY balance
                </div>
              )}

              <button
                onClick={handleSendTip}
                disabled={loading || insufficientBalance || amount < 1}
                className="w-full py-4 bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-semibold rounded-xl hover:from-yellow-400 hover:to-orange-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? (
                  'Sending...'
                ) : (
                  <>
                    <Zap size={18} className="fill-white" />
                    Send {amount} CTY
                  </>
                )}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
