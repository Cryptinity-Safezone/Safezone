import { useState, useRef, useEffect } from 'react';
import { Bell, AtSign, Heart, MessageCircle, UserPlus, Check, X } from 'lucide-react';
import { useNotifications, Notification } from '../../hooks/useNotifications';

interface NotificationsDropdownProps {
  onNavigateToPost?: (postId: string) => void;
}

export function NotificationsDropdown({ onNavigateToPost }: NotificationsDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { notifications, unreadCount, markAsRead, markAllAsRead, clearNotification } = useNotifications();

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'mention':
        return <AtSign size={14} className="text-teal-400" />;
      case 'like':
        return <Heart size={14} className="text-red-400" />;
      case 'comment':
        return <MessageCircle size={14} className="text-accent-400" />;
      case 'follow':
        return <UserPlus size={14} className="text-green-400" />;
      default:
        return <Bell size={14} className="text-surface-400" />;
    }
  };

  const getTitle = (notification: Notification) => {
    const actor = notification.actor?.username || 'Someone';
    switch (notification.type) {
      case 'mention':
        return `${actor} mentioned you`;
      case 'like':
        return `${actor} liked your post`;
      case 'comment':
        return `${actor} commented on your post`;
      case 'follow':
        return `${actor} started following you`;
      default:
        return notification.content || 'New notification';
    }
  };

  const timeAgo = (date: string) => {
    const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
    if (seconds < 60) return 'now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    return `${Math.floor(seconds / 86400)}d`;
  };

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.is_read) {
      markAsRead(notification.id);
    }
    if (notification.post_id && onNavigateToPost) {
      onNavigateToPost(notification.post_id);
    }
    setIsOpen(false);
  };

  return (
    <div ref={dropdownRef} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative w-9 h-9 flex items-center justify-center rounded-xl text-surface-400 hover:text-white hover:bg-white/[0.06] transition-all"
      >
        <Bell size={18} />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 rounded-full text-[10px] font-bold text-white flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-80 max-h-96 overflow-hidden bg-[#0c0c0d] border border-white/[0.08] rounded-2xl shadow-2xl z-50">
          <div className="flex items-center justify-between p-4 border-b border-white/[0.06]">
            <h3 className="font-semibold text-white">Notifications</h3>
            {unreadCount > 0 && (
              <button
                onClick={() => markAllAsRead()}
                className="text-xs text-accent-400 hover:text-accent-300 flex items-center gap-1"
              >
                <Check size={12} />
                Mark all read
              </button>
            )}
          </div>

          <div className="overflow-y-auto max-h-72">
            {notifications.length === 0 ? (
              <div className="p-8 text-center">
                <Bell size={24} className="text-surface-600 mx-auto mb-3" />
                <p className="text-sm text-surface-500">No notifications yet</p>
                <p className="text-xs text-surface-600 mt-1">When someone mentions you, you'll see it here</p>
              </div>
            ) : (
              <div className="divide-y divide-white/[0.04]">
                {notifications.slice(0, 20).map((notification) => (
                  <div
                    key={notification.id}
                    onClick={() => handleNotificationClick(notification)}
                    className={`flex items-start gap-3 p-4 cursor-pointer transition-colors ${
                      notification.is_read
                        ? 'bg-transparent hover:bg-white/[0.02]'
                        : 'bg-accent-500/5 hover:bg-accent-500/10'
                    }`}
                  >
                    <div className="relative flex-shrink-0">
                      {notification.actor?.avatar_url ? (
                        <img
                          src={notification.actor.avatar_url}
                          alt={notification.actor.username}
                          className="w-9 h-9 rounded-xl object-cover"
                        />
                      ) : (
                        <div className="w-9 h-9 rounded-xl bg-surface-800 flex items-center justify-center">
                          {getIcon(notification.type)}
                        </div>
                      )}
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-lg bg-surface-900 border border-white/[0.06] flex items-center justify-center">
                        {getIcon(notification.type)}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white leading-snug">
                        {getTitle(notification)}
                      </p>
                      <p className="text-xs text-surface-500 mt-0.5">
                        {timeAgo(notification.created_at)}
                      </p>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        clearNotification(notification.id);
                      }}
                      className="p-1 rounded-lg text-surface-600 hover:text-surface-400 hover:bg-white/[0.04] transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
