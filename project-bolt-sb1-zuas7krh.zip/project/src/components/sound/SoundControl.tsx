import { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, Volume1 } from 'lucide-react';
import { useSound } from '../../contexts/SoundContext';

interface SoundControlProps {
  position?: 'bottom-left' | 'bottom-right' | 'top-left' | 'top-right';
  showVolumeSlider?: boolean;
}

export function SoundControl({ position = 'bottom-left', showVolumeSlider = true }: SoundControlProps) {
  const { isPlaying, volume, isMuted, toggleSound, setVolume, toggleMute } = useSound();
  const [showSlider, setShowSlider] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const positionClasses = {
    'bottom-left': 'bottom-24 left-4',
    'bottom-right': 'bottom-24 right-4',
    'top-left': 'top-24 left-4',
    'top-right': 'top-24 right-4',
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        sliderRef.current &&
        buttonRef.current &&
        !sliderRef.current.contains(e.target as Node) &&
        !buttonRef.current.contains(e.target as Node)
      ) {
        setShowSlider(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getVolumeIcon = () => {
    if (isMuted || volume === 0) return VolumeX;
    if (volume < 50) return Volume1;
    return Volume2;
  };

  const VolumeIcon = getVolumeIcon();

  return (
    <div className={`fixed ${positionClasses[position]} z-40`}>
      <div className="relative flex items-center gap-2">
        {showSlider && showVolumeSlider && (
          <div
            ref={sliderRef}
            className="absolute left-14 bg-slate-900/95 backdrop-blur-xl rounded-xl p-4 border border-white/10 shadow-xl animate-fadeIn"
          >
            <div className="flex items-center gap-4 min-w-[180px]">
              <button
                onClick={toggleMute}
                className="p-2 rounded-lg hover:bg-white/10 transition-colors text-gray-400 hover:text-white"
              >
                <VolumeIcon size={18} />
              </button>
              <input
                type="range"
                min="0"
                max="100"
                value={isMuted ? 0 : volume}
                onChange={(e) => setVolume(parseInt(e.target.value))}
                className="flex-1 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-teal-500"
              />
              <span className="text-xs text-gray-400 w-8 text-right tabular-nums">
                {isMuted ? 0 : volume}%
              </span>
            </div>
          </div>
        )}

        <button
          ref={buttonRef}
          onClick={() => {
            if (!isPlaying) {
              toggleSound();
            } else if (showVolumeSlider) {
              setShowSlider(!showSlider);
            } else {
              toggleSound();
            }
          }}
          onDoubleClick={() => {
            if (isPlaying) {
              toggleSound();
            }
          }}
          className={`group relative w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 ${
            isPlaying
              ? 'bg-teal-500/20 border border-teal-500/30 text-teal-400 hover:bg-teal-500/30'
              : 'bg-white/5 border border-white/10 text-gray-400 hover:bg-white/10 hover:text-gray-300'
          }`}
          title={isPlaying ? 'Click for volume, double-click to stop' : 'Play ambient sound'}
        >
          {isPlaying ? (
            <>
              <Volume2 size={20} className="relative z-10" />
              <div className="absolute inset-0 rounded-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-teal-500/10 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-teal-500/30">
                  <div
                    className="h-full bg-teal-400 transition-all duration-300"
                    style={{ width: `${isMuted ? 0 : volume}%` }}
                  />
                </div>
              </div>
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-teal-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(20,184,166,0.6)]" />
            </>
          ) : (
            <VolumeX size={20} />
          )}
        </button>
      </div>

      {!isPlaying && (
        <div className="absolute left-14 top-1/2 -translate-y-1/2 whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none">
          <span className="text-xs text-gray-500 bg-slate-900/90 px-2 py-1 rounded">
            Ambient sound
          </span>
        </div>
      )}
    </div>
  );
}
