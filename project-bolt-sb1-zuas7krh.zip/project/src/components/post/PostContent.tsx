import { parsePostContent } from '../../lib/post-parser';

interface PostContentProps {
  content: string;
  onHashtagClick?: (hashtag: string) => void;
  onMentionClick?: (username: string) => void;
  className?: string;
}

export function PostContent({
  content,
  onHashtagClick,
  onMentionClick,
  className = '',
}: PostContentProps) {
  const segments = parsePostContent(content);

  const handleHashtagClick = (hashtag: string) => {
    if (onHashtagClick) {
      onHashtagClick(hashtag);
    } else {
      window.dispatchEvent(
        new CustomEvent('navigate-hashtag', { detail: hashtag })
      );
    }
  };

  const handleMentionClick = (username: string) => {
    if (onMentionClick) {
      onMentionClick(username);
    } else {
      window.dispatchEvent(
        new CustomEvent('navigate-mention', { detail: username })
      );
    }
  };

  return (
    <p className={`text-surface-300 leading-relaxed ${className}`}>
      {segments.map((segment, index) => {
        if (segment.type === 'hashtag') {
          return (
            <button
              key={index}
              onClick={() => handleHashtagClick(segment.value!)}
              className="text-accent-400 hover:text-accent-300 hover:underline transition-colors"
            >
              {segment.content}
            </button>
          );
        }

        if (segment.type === 'mention') {
          return (
            <button
              key={index}
              onClick={() => handleMentionClick(segment.value!)}
              className="text-teal-400 hover:text-teal-300 hover:underline transition-colors"
            >
              {segment.content}
            </button>
          );
        }

        return <span key={index}>{segment.content}</span>;
      })}
    </p>
  );
}
