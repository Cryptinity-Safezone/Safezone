export { PostContent } from './PostContent';
