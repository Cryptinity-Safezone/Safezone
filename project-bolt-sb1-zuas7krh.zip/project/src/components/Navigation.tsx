import { Home, Compass, Sparkles, Lock, User, MessageCircle } from 'lucide-react';
import type { ViewState } from '../types';

interface NavigationProps {
  view: ViewState;
  onViewChange: (view: ViewState) => void;
}

interface NavIconProps {
  icon: typeof Home;
  active: boolean;
  onClick: () => void;
  label: string;
}

const NavIcon = ({ icon: Icon, active, onClick, label }: NavIconProps) => (
  <button
    onClick={onClick}
    className={`relative group flex flex-col items-center justify-center p-2.5 transition-all duration-300 ${
      active ? 'text-accent-400' : 'text-surface-500 hover:text-surface-300'
    }`}
  >
    <div className={`relative transition-transform duration-300 ${active ? 'scale-110' : 'group-hover:scale-105'}`}>
      <Icon size={22} strokeWidth={active ? 2.5 : 2} />
      {active && (
        <div className="absolute -inset-2 bg-accent-500/20 rounded-xl blur-lg -z-10" />
      )}
    </div>
    <span className={`mt-0.5 text-[8px] font-semibold tracking-wider uppercase transition-all duration-300 ${
      active ? 'opacity-100 text-accent-400' : 'opacity-0 group-hover:opacity-60'
    }`}>
      {label}
    </span>
    {active && (
      <span className="absolute -bottom-0.5 w-1 h-1 bg-accent-500 rounded-sm shadow-glow-sm" />
    )}
  </button>
);

export const Navigation = ({ view, onViewChange }: NavigationProps) => (
  <nav className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 px-4 w-full max-w-[420px]">
    <div className="relative">
      <div className="absolute -inset-1 bg-gradient-to-r from-accent-500/10 via-transparent to-teal-500/10 rounded-[28px] blur-xl opacity-60" />
      <div className="relative glass-dark rounded-[24px] px-1.5 py-1 flex items-center justify-between shadow-2xl shadow-black/60">
        <NavIcon icon={Home} active={view === 'feed'} onClick={() => onViewChange('feed')} label="Feed" />
        <NavIcon icon={Compass} active={view === 'explore'} onClick={() => onViewChange('explore')} label="Explore" />

        <button
          onClick={() => onViewChange('create')}
          className={`relative mx-1 w-12 h-12 rounded-[16px] flex items-center justify-center transition-all duration-300 ${
            view === 'create'
              ? 'bg-gradient-to-br from-accent-400 to-teal-500 shadow-lg shadow-accent-500/40 scale-105'
              : 'bg-gradient-to-br from-accent-500 to-teal-600 shadow-lg shadow-accent-500/30 hover:shadow-accent-500/40 hover:scale-105'
          }`}
        >
          <div className="absolute inset-0 rounded-[16px] bg-gradient-to-br from-white/20 to-transparent" />
          <Sparkles size={22} className="text-white relative z-10" strokeWidth={2.5} />
          {view === 'create' && (
            <div className="absolute -inset-1 bg-accent-500/30 rounded-[20px] blur-lg animate-pulse-glow -z-10" />
          )}
        </button>

        <NavIcon icon={MessageCircle} active={view === 'messages'} onClick={() => onViewChange('messages')} label="Chat" />
        <NavIcon icon={Lock} active={view === 'warehouse'} onClick={() => onViewChange('warehouse')} label="Vault" />
        <NavIcon icon={User} active={view === 'profile'} onClick={() => onViewChange('profile')} label="Profile" />
      </div>
    </div>
  </nav>
);
