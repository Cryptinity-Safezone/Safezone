import { useEffect, useState } from 'react';
import {
  X, Volume2, VolumeX, Image, Music, Zap, Package, Star,
  Sparkles, Lock, Heart, MessageCircle
} from 'lucide-react';

type PlanType = 'free' | 'personal' | 'creator';

interface PlanPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  planType: PlanType;
}

const MOCK_DATA = {
  free: {
    name: 'Free Explorer',
    handle: 'free_explorer',
    avatarGradient: 'from-surface-600 to-surface-700',
    coverGradient: 'from-surface-800 via-surface-700 to-surface-800',
    showcaseCount: 2,
    hasSound: false,
    ctyMonthly: 100,
    warehouseSize: '1GB',
  },
  personal: {
    name: 'Personal Creator',
    handle: 'personal_creator',
    avatarGradient: 'from-accent-500 to-teal-500',
    coverGradient: 'from-accent-900/60 via-teal-800/40 to-surface-900',
    showcaseCount: 5,
    hasSound: true,
    ctyMonthly: 500,
    warehouseSize: '5GB',
  },
  creator: {
    name: 'Full Creator',
    handle: 'full_creator',
    avatarGradient: 'from-amber-400 via-accent-400 to-teal-400',
    coverGradient: 'from-amber-900/30 via-accent-800/40 to-teal-900/50',
    showcaseCount: 12,
    hasSound: true,
    ctyMonthly: 1500,
    warehouseSize: '20GB',
  },
};

const SHOWCASE_IMAGES = [
  'https://images.pexels.com/photos/3075993/pexels-photo-3075993.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/2693212/pexels-photo-2693212.png?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/3617500/pexels-photo-3617500.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/3109807/pexels-photo-3109807.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/2387793/pexels-photo-2387793.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/3052361/pexels-photo-3052361.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/1252869/pexels-photo-1252869.jpeg?auto=compress&cs=tinysrgb&w=400',
  'https://images.pexels.com/photos/3225529/pexels-photo-3225529.jpeg?auto=compress&cs=tinysrgb&w=400',
];

interface CTYUsageItemProps {
  icon: typeof Image;
  label: string;
  cost: string;
}

const CTYUsageItem = ({ icon: Icon, label, cost }: CTYUsageItemProps) => (
  <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white/[0.03] border border-white/[0.04]">
    <div className="w-7 h-7 rounded-lg bg-accent-500/10 flex items-center justify-center">
      <Icon size={14} className="text-accent-400" />
    </div>
    <div className="flex-1 min-w-0">
      <div className="text-xs text-surface-300 truncate">{label}</div>
    </div>
    <div className="flex items-center gap-1">
      <Zap size={10} className="text-amber-400 fill-amber-400" />
      <span className="text-xs font-medium text-amber-300">{cost}</span>
    </div>
  </div>
);

export function PlanPreviewModal({ isOpen, onClose, planType }: PlanPreviewModalProps) {
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  const data = MOCK_DATA[planType];
  const showcaseImages = SHOWCASE_IMAGES.slice(0, data.showcaseCount);

  useEffect(() => {
    if (isOpen) {
      requestAnimationFrame(() => setIsVisible(true));
    } else {
      setIsVisible(false);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const planLabel = planType === 'free' ? 'Free' : planType === 'personal' ? 'Personal' : 'Creator';

  return (
    <div
      className={`fixed inset-0 z-[80] flex items-center justify-center p-4 transition-all duration-300 ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" />

      <div
        className={`relative w-full max-w-lg max-h-[85vh] overflow-hidden rounded-[28px] bg-[#0c0c0d] border border-white/[0.08] shadow-2xl transition-all duration-300 ${
          isVisible ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className={`relative h-28 bg-gradient-to-br ${data.coverGradient}`}>
          <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c0d] via-transparent to-transparent" />

          {planType !== 'free' && (
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute top-4 right-8 w-24 h-24 rounded-full bg-accent-500/10 blur-2xl" />
              <div className="absolute bottom-2 left-12 w-16 h-16 rounded-full bg-teal-500/10 blur-xl" />
            </div>
          )}

          <div className="absolute top-3 right-3 flex items-center gap-2">
            <div className="px-3 py-1 rounded-full bg-black/40 backdrop-blur-sm border border-white/10">
              <span className="text-xs font-medium text-white/80">{planLabel} Preview</span>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm border border-white/10 flex items-center justify-center text-white/70 hover:text-white transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="relative px-5 -mt-10">
          <div className="flex items-end gap-4">
            <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${data.avatarGradient} border-4 border-[#0c0c0d] flex items-center justify-center shadow-xl`}>
              <span className="text-2xl font-bold text-white">{data.name.charAt(0)}</span>
            </div>
            <div className="flex-1 pb-2">
              <div className="font-semibold text-white text-lg">{data.name}</div>
              <div className="text-sm text-surface-500">@{data.handle}</div>
            </div>
          </div>
        </div>

        <div className="px-5 py-4 overflow-y-auto max-h-[calc(85vh-200px)]">
          {data.hasSound && (
            <div className="mb-5 p-4 rounded-2xl bg-white/[0.02] border border-white/[0.04]">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-accent-500/10 flex items-center justify-center">
                    <Music size={16} className="text-accent-400" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-white">Ambient Sound</div>
                    <div className="text-xs text-surface-500">Calm Forest Rain</div>
                  </div>
                </div>
                <button
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200 ${
                    soundEnabled
                      ? 'bg-accent-500/20 text-accent-400'
                      : 'bg-white/[0.04] text-surface-500 hover:text-surface-300'
                  }`}
                >
                  {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
                </button>
              </div>
              <div className="h-1 rounded-full bg-white/[0.06] overflow-hidden">
                <div
                  className={`h-full rounded-full bg-gradient-to-r from-accent-500 to-teal-500 transition-all duration-300 ${
                    soundEnabled ? 'w-1/3' : 'w-0'
                  }`}
                />
              </div>
              <p className="text-xs text-surface-500 mt-2 text-center">
                Tap to preview (no autoplay)
              </p>
            </div>
          )}

          {!data.hasSound && (
            <div className="mb-5 p-4 rounded-2xl bg-white/[0.02] border border-white/[0.04] border-dashed">
              <div className="flex items-center gap-3 opacity-50">
                <div className="w-8 h-8 rounded-lg bg-surface-700/50 flex items-center justify-center">
                  <VolumeX size={16} className="text-surface-500" />
                </div>
                <div>
                  <div className="text-sm text-surface-400">Ambient Sound</div>
                  <div className="text-xs text-surface-600">Upgrade to unlock</div>
                </div>
              </div>
            </div>
          )}

          <div className="mb-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Star size={14} className="text-accent-400" />
                <span className="text-sm font-medium text-white">Showcase</span>
              </div>
              <span className="text-xs text-surface-500">
                {planType === 'creator' ? 'Unlimited' : `${data.showcaseCount} slots`}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {showcaseImages.map((img, i) => (
                <div
                  key={i}
                  className="aspect-square rounded-xl overflow-hidden bg-surface-800 border border-white/[0.04] transition-transform duration-200 hover:scale-[1.02]"
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </div>
              ))}
              {planType === 'free' && (
                <div className="aspect-square rounded-xl bg-white/[0.02] border border-white/[0.04] border-dashed flex items-center justify-center">
                  <Lock size={16} className="text-surface-600" />
                </div>
              )}
            </div>
            {planType === 'creator' && (
              <p className="text-xs text-surface-500 text-center mt-2">
                + unlimited more slots available
              </p>
            )}
          </div>

          <div className="mb-5">
            <div className="flex items-center gap-2 mb-3">
              <Zap size={14} className="text-amber-400 fill-amber-400" />
              <span className="text-sm font-medium text-white">CTY Usage Examples</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <CTYUsageItem icon={Image} label="AI Image" cost="10" />
              <CTYUsageItem icon={Music} label="AI Sound" cost="15" />
              <CTYUsageItem icon={Sparkles} label="Enhance" cost="5" />
              <CTYUsageItem icon={Heart} label="Premium Filter" cost="8" />
            </div>
            <div className="mt-3 p-3 rounded-xl bg-amber-500/5 border border-amber-500/10">
              <div className="flex items-center justify-between">
                <span className="text-xs text-surface-400">Monthly Allowance</span>
                <div className="flex items-center gap-1.5">
                  <Zap size={12} className="text-amber-400 fill-amber-400" />
                  <span className="text-sm font-bold text-amber-300">{data.ctyMonthly.toLocaleString()}</span>
                  <span className="text-xs text-amber-400/70">CTY</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mb-2">
            <div className="flex items-center gap-2 mb-3">
              <Package size={14} className="text-accent-400" />
              <span className="text-sm font-medium text-white">Warehouse Storage</span>
            </div>
            <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-surface-400">Available Space</span>
                <span className="text-sm font-medium text-white">{data.warehouseSize}</span>
              </div>
              <div className="h-2 rounded-full bg-white/[0.06] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-accent-500 to-teal-500"
                  style={{ width: planType === 'free' ? '15%' : planType === 'personal' ? '8%' : '3%' }}
                />
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-[10px] text-surface-600">Used: Demo</span>
                <span className="text-[10px] text-surface-600">
                  {planType === 'creator' ? 'Priority storage' : 'Standard storage'}
                </span>
              </div>
            </div>
          </div>

          {planType !== 'free' && (
            <div className="flex items-center gap-2 mt-4 p-3 rounded-xl bg-accent-500/5 border border-accent-500/10">
              <MessageCircle size={14} className="text-accent-400" />
              <span className="text-xs text-accent-300/80">
                {planType === 'personal'
                  ? 'Make your space feel like home'
                  : 'Full creative freedom unlocked'}
              </span>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-white/[0.04]">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-sm font-medium text-surface-300 hover:bg-white/[0.06] hover:text-white transition-all duration-200"
          >
            Close Preview
          </button>
        </div>
      </div>
    </div>
  );
}
