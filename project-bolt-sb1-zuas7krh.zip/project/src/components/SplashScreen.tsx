import { useState, useEffect } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen = ({ onComplete }: SplashScreenProps) => {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setStep(1), 300),
      setTimeout(() => setStep(2), 1200),
      setTimeout(() => setStep(3), 2000),
      setTimeout(() => setStep(4), 3200),
      setTimeout(onComplete, 3700),
    ];
    return () => timers.forEach(clearTimeout);
  }, [onComplete]);

  if (step === 4) {
    return (
      <div className="fixed inset-0 bg-surface-950 z-[100] transition-opacity duration-500 opacity-0 pointer-events-none" />
    );
  }

  return (
    <div className="fixed inset-0 z-[100] bg-surface-950 flex flex-col items-center justify-center">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent-500/10 rounded-full blur-[150px] animate-pulse-glow" />
      </div>

      <div className={`relative transition-all duration-700 ease-out ${step >= 1 ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`}>
        <div className="absolute -inset-4 bg-accent-500/20 rounded-[36px] blur-2xl animate-pulse-glow" />
        <div className="relative w-28 h-28 rounded-[28px] flex items-center justify-center shadow-2xl shadow-accent-500/30 overflow-hidden">
          <img src="/711-removebg-preview.png" alt="Cryptinity" className="w-full h-full object-contain drop-shadow-lg" />
        </div>
      </div>

      <h1 className={`mt-10 text-4xl font-bold text-white tracking-[0.2em] transition-all duration-700 ${step >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
        CRYPTINITY
      </h1>

      <p className={`mt-4 text-accent-400 font-medium tracking-[0.3em] uppercase text-xs transition-all duration-700 ${step >= 3 ? 'opacity-100' : 'opacity-0'}`}>
        Entering SafeZone
      </p>

      <div className={`mt-8 flex gap-2 transition-all duration-500 ${step >= 3 ? 'opacity-100' : 'opacity-0'}`}>
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="w-2 h-2 bg-accent-500 rounded-sm animate-pulse shadow-glow-sm"
            style={{ animationDelay: `${i * 200}ms` }}
          />
        ))}
      </div>
    </div>
  );
};
