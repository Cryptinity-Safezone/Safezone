import { useState, useRef, useCallback, useEffect } from 'react';
import { X, Upload, Camera, Image as ImageIcon, Trash2, Check, Sparkles } from 'lucide-react';
import { useImageGeneration } from '../../hooks/useImageGeneration';

type UploadType = 'avatar' | 'cover';

interface ImageUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: UploadType;
  currentImage?: string;
  onUpload: (file: File) => Promise<void>;
  onRemove?: () => Promise<void>;
}

const MAX_FILE_SIZE = 5 * 1024 * 1024;
const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

export function ImageUploadModal({
  isOpen,
  onClose,
  type,
  currentImage,
  onUpload,
  onRemove,
}: ImageUploadModalProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [showAIPrompt, setShowAIPrompt] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { generate, generating, error: generationError, clearError } = useImageGeneration();

  useEffect(() => {
    if (isOpen) {
      requestAnimationFrame(() => setIsVisible(true));
      setPreview(null);
      setSelectedFile(null);
      setError('');
      setProgress(0);
      setShowAIPrompt(false);
      setAiPrompt('');
    } else {
      setIsVisible(false);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !uploading) onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose, uploading]);

  const validateFile = useCallback((file: File): string | null => {
    if (!ACCEPTED_TYPES.includes(file.type)) {
      return 'Please select a valid image (JPEG, PNG, WebP, or GIF)';
    }
    if (file.size > MAX_FILE_SIZE) {
      return 'Image must be smaller than 5MB';
    }
    return null;
  }, []);

  const handleFileSelect = useCallback((file: File) => {
    setError('');
    const validationError = validateFile(file);
    if (validationError) {
      setError(validationError);
      return;
    }

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  }, [validateFile]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  }, [handleFileSelect]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileSelect(file);
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setUploading(true);
    setError('');
    setProgress(0);

    const progressInterval = setInterval(() => {
      setProgress((p) => Math.min(p + 10, 90));
    }, 100);

    try {
      await onUpload(selectedFile);
      setProgress(100);
      setTimeout(() => {
        clearInterval(progressInterval);
        onClose();
      }, 300);
    } catch (err: any) {
      clearInterval(progressInterval);
      setError(err.message || 'Failed to upload image');
      setProgress(0);
    } finally {
      setUploading(false);
    }
  };

  const handleRemove = async () => {
    if (!onRemove) return;

    setUploading(true);
    setError('');

    try {
      await onRemove();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to remove image');
    } finally {
      setUploading(false);
    }
  };

  const handleAIGenerate = async () => {
    if (!aiPrompt.trim()) {
      setError('Please enter a description for AI generation');
      return;
    }

    setError('');
    clearError();
    setProgress(0);

    const result = await generate({
      prompt: type === 'avatar'
        ? `Profile avatar: ${aiPrompt}. Square format, centered subject, professional quality.`
        : `Cover photo: ${aiPrompt}. Wide landscape format, high quality banner image.`,
      style: 'abstract',
      quality: 'standard',
      isPrivate: true,
    });

    if (!result || !result.image_url) {
      return;
    }

    try {
      const response = await fetch(result.image_url);
      const blob = await response.blob();
      const file = new File([blob], 'ai-generated.png', { type: 'image/png' });

      setSelectedFile(file);
      setPreview(result.image_url);
      setShowAIPrompt(false);
      setAiPrompt('');
    } catch (err: any) {
      setError('Failed to load generated image');
    }
  };

  if (!isOpen) return null;

  const title = type === 'avatar' ? 'Change Avatar' : 'Change Cover';
  const aspectRatio = type === 'avatar' ? 'aspect-square' : 'aspect-[16/9]';
  const previewRounded = type === 'avatar' ? 'rounded-[28px]' : 'rounded-2xl';

  return (
    <div
      className={`fixed inset-0 z-[80] flex items-end sm:items-center justify-center transition-all duration-300 ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
      onClick={() => !uploading && onClose()}
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" />

      <div
        className={`relative w-full sm:max-w-md sm:mx-4 bg-[#0c0c0d] border border-white/[0.08] shadow-2xl transition-all duration-300 max-h-[90vh] overflow-y-auto ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
        } rounded-t-[28px] sm:rounded-[28px]`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 border-b border-white/[0.04]">
          <h2 className="text-lg font-semibold text-white">{title}</h2>
          <button
            onClick={onClose}
            disabled={uploading}
            className="w-9 h-9 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] flex items-center justify-center text-surface-400 hover:text-white transition-all disabled:opacity-50"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-5">
          {(error || generationError) && (
            <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-400">
              {error || generationError}
            </div>
          )}

          <div
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
            className={`relative ${aspectRatio} ${previewRounded} overflow-hidden border-2 border-dashed border-white/[0.08] bg-white/[0.02] transition-all duration-200 hover:border-accent-500/30 hover:bg-white/[0.04] cursor-pointer group`}
            onClick={() => fileInputRef.current?.click()}
          >
            {preview ? (
              <>
                <img src={preview} alt="Preview" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 backdrop-blur-sm text-white text-sm">
                    <ImageIcon size={16} />
                    <span>Change Image</span>
                  </div>
                </div>
              </>
            ) : currentImage ? (
              <>
                <img src={currentImage} alt="Current" className="w-full h-full object-cover opacity-60" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <div className="flex flex-col items-center gap-2 text-white/80">
                    <Upload size={24} />
                    <span className="text-sm">Upload new image</span>
                  </div>
                </div>
              </>
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-surface-500">
                <Upload size={28} className="mb-2" />
                <span className="text-sm font-medium">Drop image here</span>
                <span className="text-xs text-surface-600 mt-1">or tap to browse</span>
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPTED_TYPES.join(',')}
              onChange={handleInputChange}
              className="hidden"
            />
          </div>

          {showAIPrompt ? (
            <div className="mt-4 space-y-3">
              <div>
                <input
                  type="text"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder={`Describe your ${type === 'avatar' ? 'avatar' : 'cover photo'}...`}
                  className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-white placeholder:text-surface-600 focus:border-accent-500/30 focus:outline-none transition-all"
                  onKeyDown={(e) => e.key === 'Enter' && handleAIGenerate()}
                  autoFocus
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowAIPrompt(false)}
                  disabled={generating}
                  className="flex-1 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-surface-300 hover:bg-white/[0.06] hover:text-white transition-all disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAIGenerate}
                  disabled={generating || !aiPrompt.trim()}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-accent-500 to-teal-600 text-white font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {generating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span className="text-sm">Generating...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles size={16} />
                      <span className="text-sm">Generate</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ) : (
            <div className="flex gap-3 mt-4">
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06] text-surface-300 hover:bg-white/[0.06] hover:text-white transition-all disabled:opacity-50"
              >
                <ImageIcon size={16} />
                <span className="text-sm font-medium">Gallery</span>
              </button>
              <button
                onClick={() => setShowAIPrompt(true)}
                disabled={uploading}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-accent-500/20 to-teal-600/20 border border-accent-500/30 text-accent-400 hover:from-accent-500/30 hover:to-teal-600/30 transition-all disabled:opacity-50"
              >
                <Sparkles size={16} />
                <span className="text-sm font-medium">AI Generate</span>
              </button>
            </div>
          )}

          {uploading && progress > 0 && (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-surface-400">Uploading...</span>
                <span className="text-xs text-accent-400">{progress}%</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-accent-500 to-teal-500 transition-all duration-200"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          <p className="text-xs text-surface-600 text-center mt-4">
            JPEG, PNG, WebP, or GIF. Max 5MB.
          </p>
        </div>

        <div className="p-5 pt-0 pb-8 sm:pb-5 flex gap-3">
          {currentImage && onRemove && (
            <button
              onClick={handleRemove}
              disabled={uploading}
              className="flex items-center justify-center gap-2 px-4 py-3.5 rounded-xl border border-red-500/20 text-red-400 hover:bg-red-500/10 transition-all disabled:opacity-50"
            >
              <Trash2 size={16} />
            </button>
          )}
          <button
            onClick={handleUpload}
            disabled={!selectedFile || uploading}
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl bg-gradient-to-r from-accent-500 to-teal-600 text-white font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-accent-500/20"
          >
            {uploading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Check size={18} />
                <span>Save</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
