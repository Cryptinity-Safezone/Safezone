import { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';

interface EditProfileModalProps {
  profile: any;
  onClose: () => void;
  onSave: (updates: any) => Promise<void>;
}

export const EditProfileModal = ({ profile, onClose, onSave }: EditProfileModalProps) => {
  const [formData, setFormData] = useState({
    username: profile.username || '',
    bio: profile.bio || '',
    interests: (profile.interests || []).join(', '),
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    requestAnimationFrame(() => setIsVisible(true));
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !saving) onClose();
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [onClose, saving]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSaving(true);

    try {
      const updates = {
        username: formData.username.trim(),
        bio: formData.bio.trim() || null,
        interests: formData.interests
          .split(',')
          .map((i: string) => i.trim())
          .filter((i: string) => i.length > 0),
      };

      await onSave(updates);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className={`fixed inset-0 z-[60] flex items-end sm:items-center justify-center transition-all duration-300 ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
      onClick={() => !saving && onClose()}
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" />

      <div
        className={`relative w-full sm:max-w-md sm:mx-4 max-h-[90vh] overflow-y-auto bg-[#0c0c0d] border border-white/[0.08] shadow-2xl transition-all duration-300 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
        } rounded-t-[28px] sm:rounded-[28px]`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between p-5 border-b border-white/[0.04] bg-[#0c0c0d]">
          <h2 className="text-lg font-semibold text-white">Edit Profile</h2>
          <button
            onClick={onClose}
            disabled={saving}
            className="w-9 h-9 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] flex items-center justify-center text-surface-400 hover:text-white transition-all disabled:opacity-50"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5">
          {error && (
            <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-sm text-red-400">
              {error}
            </div>
          )}

          <div className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-surface-300 mb-2">Username</label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="input-field"
                required
                minLength={3}
                maxLength={30}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-surface-300 mb-2">Bio</label>
              <textarea
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                className="input-field resize-none"
                rows={3}
                maxLength={160}
                placeholder="Tell us about yourself..."
              />
              <p className="text-xs text-surface-500 mt-1">{formData.bio.length}/160</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-surface-300 mb-2">
                Interests (comma-separated)
              </label>
              <input
                type="text"
                value={formData.interests}
                onChange={(e) => setFormData({ ...formData, interests: e.target.value })}
                className="input-field"
                placeholder="e.g., Art, Music, Photography"
              />
            </div>
          </div>

          <div className="flex gap-3 mt-6 pt-5 border-t border-white/[0.04]">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3.5 text-sm text-surface-400 hover:text-white bg-white/[0.04] hover:bg-white/[0.06] rounded-xl transition-all font-medium"
              disabled={saving}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 px-4 py-3.5 bg-gradient-to-r from-accent-500 to-teal-600 text-white text-sm font-medium rounded-xl hover:from-accent-400 hover:to-teal-500 transition-all duration-200 disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-accent-500/20"
            >
              {saving ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Save size={16} />
                  Save Changes
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
