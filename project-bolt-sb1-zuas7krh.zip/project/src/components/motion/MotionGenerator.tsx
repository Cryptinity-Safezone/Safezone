import { useState, useEffect } from 'react';
import {
  Sparkles,
  Image as ImageIcon,
  Play,
  Loader2,
  Wind,
  Waves,
  Shirt,
  Stars,
  Move3D,
  Lock,
  Globe,
  AlertCircle,
  ChevronRight,
  Zap
} from 'lucide-react';
import { useMotion } from '../../hooks/useMotion';
import { useAuth } from '../../contexts/AuthContext';
import { CTY_COSTS } from '../../lib/cty-costs';
import { MotionPlayer } from './MotionPlayer';

interface MotionGeneratorProps {
  onGenerated?: (motion: any) => void;
  onClose?: () => void;
}

const MOTION_ICONS: Record<string, React.ReactNode> = {
  breathing: <Wind className="w-5 h-5" />,
  drift: <Waves className="w-5 h-5" />,
  hair_cloth: <Shirt className="w-5 h-5" />,
  particles: <Stars className="w-5 h-5" />,
  camera_pan: <Move3D className="w-5 h-5" />,
};

export function MotionGenerator({ onGenerated, onClose }: MotionGeneratorProps) {
  const { user, profile, refreshProfile } = useAuth();
  const {
    loading,
    error,
    sourceImages,
    motionHistory,
    motionTypes,
    fetchSourceImages,
    fetchMotionHistory,
    generateMotion,
    getMotionCost,
  } = useMotion();

  const [step, setStep] = useState<'select' | 'configure' | 'generating' | 'complete'>('select');
  const [selectedImage, setSelectedImage] = useState<any>(null);
  const [selectedMotionType, setSelectedMotionType] = useState('breathing');
  const [isPrivate, setIsPrivate] = useState(true);
  const [generatedMotion, setGeneratedMotion] = useState<any>(null);
  const [generating, setGenerating] = useState(false);

  const cost = getMotionCost(profile?.plan_type);
  const canAfford = (profile?.cty_balance || 0) >= cost;

  useEffect(() => {
    fetchSourceImages();
    fetchMotionHistory();
  }, [fetchSourceImages, fetchMotionHistory]);

  const handleSelectImage = (image: any) => {
    setSelectedImage(image);
    setStep('configure');
  };

  const handleGenerate = async () => {
    if (!selectedImage || !canAfford) return;

    setGenerating(true);
    setStep('generating');

    try {
      const result = await generateMotion({
        sourceImageId: selectedImage.id,
        sourceImageUrl: selectedImage.image_url,
        motionType: selectedMotionType,
        duration: 10,
        isPrivate,
      });

      setGeneratedMotion(result.motion);
      setStep('complete');
      await refreshProfile();
      onGenerated?.(result.motion);
    } catch (err) {
      setStep('configure');
    } finally {
      setGenerating(false);
    }
  };

  const handleBack = () => {
    if (step === 'configure') {
      setSelectedImage(null);
      setStep('select');
    }
  };

  const renderSelectStep = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white">Select Source Image</h3>
          <p className="text-sm text-white/60">Choose an AI-generated image to animate</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-amber-500/20 rounded-lg">
          <Zap className="w-4 h-4 text-amber-400" />
          <span className="text-sm font-medium text-amber-400">{cost} CTY</span>
        </div>
      </div>

      {sourceImages.length === 0 && !loading && (
        <div className="py-12 text-center">
          <ImageIcon className="w-12 h-12 text-white/20 mx-auto mb-3" />
          <p className="text-white/60">No AI-generated images yet</p>
          <p className="text-sm text-white/40 mt-1">
            Create some images first to use as source for Living Images
          </p>
        </div>
      )}

      <div className="grid grid-cols-3 gap-3 max-h-80 overflow-y-auto">
        {sourceImages.map((image) => (
          <button
            key={image.id}
            onClick={() => handleSelectImage(image)}
            className="relative aspect-square rounded-lg overflow-hidden group hover:ring-2 hover:ring-teal-400 transition-all"
          >
            <img
              src={image.thumbnail_url || image.image_url}
              alt=""
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Play className="w-8 h-8 text-white" fill="white" />
            </div>
          </button>
        ))}
      </div>

      {motionHistory.length > 0 && (
        <div className="pt-4 border-t border-white/10">
          <h4 className="text-sm font-medium text-white/80 mb-3">Recent Living Images</h4>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {motionHistory.slice(0, 5).map((motion) => (
              <div
                key={motion.id}
                className="relative flex-shrink-0 w-24 aspect-video rounded-lg overflow-hidden"
              >
                {motion.video_url ? (
                  <video
                    src={motion.video_url}
                    poster={motion.thumbnail_url || undefined}
                    className="w-full h-full object-cover"
                    muted
                    loop
                    playsInline
                  />
                ) : (
                  <div className="w-full h-full bg-white/10 flex items-center justify-center">
                    <Loader2 className="w-4 h-4 text-white/40 animate-spin" />
                  </div>
                )}
                <div className="absolute bottom-1 right-1 px-1.5 py-0.5 bg-black/60 rounded text-[10px] text-white/80">
                  {motion.duration_seconds}s
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderConfigureStep = () => (
    <div className="space-y-5">
      <button
        onClick={handleBack}
        className="text-sm text-white/60 hover:text-white flex items-center gap-1"
      >
        <ChevronRight className="w-4 h-4 rotate-180" />
        Back to image selection
      </button>

      <div className="flex gap-4">
        <div className="w-32 h-32 rounded-lg overflow-hidden flex-shrink-0">
          <img
            src={selectedImage?.image_url}
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-white mb-1">Configure Motion</h3>
          <p className="text-sm text-white/60 line-clamp-2">
            {selectedImage?.prompt || 'AI-generated image'}
          </p>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-white/80 mb-3">Motion Type</label>
        <div className="grid grid-cols-1 gap-2">
          {motionTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => setSelectedMotionType(type.id)}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${
                selectedMotionType === type.id
                  ? 'border-teal-400 bg-teal-400/10'
                  : 'border-white/10 bg-white/5 hover:border-white/20'
              }`}
            >
              <div className={`${selectedMotionType === type.id ? 'text-teal-400' : 'text-white/60'}`}>
                {MOTION_ICONS[type.id]}
              </div>
              <div className="flex-1 text-left">
                <p className={`font-medium ${selectedMotionType === type.id ? 'text-teal-400' : 'text-white'}`}>
                  {type.name}
                </p>
                <p className="text-xs text-white/50">{type.description}</p>
              </div>
              {selectedMotionType === type.id && (
                <div className="w-2 h-2 rounded-full bg-teal-400" />
              )}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-white/80 mb-3">Privacy</label>
        <div className="flex gap-2">
          <button
            onClick={() => setIsPrivate(true)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg border transition-all ${
              isPrivate
                ? 'border-teal-400 bg-teal-400/10 text-teal-400'
                : 'border-white/10 bg-white/5 text-white/60 hover:border-white/20'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span className="text-sm font-medium">Private</span>
          </button>
          <button
            onClick={() => setIsPrivate(false)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg border transition-all ${
              !isPrivate
                ? 'border-teal-400 bg-teal-400/10 text-teal-400'
                : 'border-white/10 bg-white/5 text-white/60 hover:border-white/20'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span className="text-sm font-medium">Public</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-500/20 border border-red-500/30 rounded-lg">
          <AlertCircle className="w-4 h-4 text-red-400" />
          <span className="text-sm text-red-300">{error}</span>
        </div>
      )}

      <div className="pt-2">
        <button
          onClick={handleGenerate}
          disabled={!canAfford || generating}
          className={`w-full py-3 rounded-lg font-medium flex items-center justify-center gap-2 transition-all ${
            canAfford
              ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white hover:from-teal-400 hover:to-cyan-400'
              : 'bg-white/10 text-white/40 cursor-not-allowed'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          <span>Generate Living Image</span>
          <span className="text-sm opacity-80">({cost} CTY)</span>
        </button>
        {!canAfford && (
          <p className="text-center text-sm text-red-400 mt-2">
            Insufficient CTY balance
          </p>
        )}
      </div>

      <div className="text-center text-xs text-white/40 space-y-1">
        <p>Duration: 10 seconds | Format: MP4 | Looping</p>
        <p>Silent (no audio) | Auto watermarked</p>
      </div>
    </div>
  );

  const renderGeneratingStep = () => (
    <div className="py-12 text-center">
      <div className="relative w-24 h-24 mx-auto mb-6">
        <div className="absolute inset-0 rounded-full border-2 border-teal-400/30 animate-ping" />
        <div className="absolute inset-2 rounded-full border-2 border-teal-400/50 animate-pulse" />
        <div className="absolute inset-4 rounded-full bg-gradient-to-br from-teal-500 to-cyan-500 flex items-center justify-center">
          <Sparkles className="w-8 h-8 text-white animate-pulse" />
        </div>
      </div>
      <h3 className="text-lg font-semibold text-white mb-2">Creating Living Image</h3>
      <p className="text-sm text-white/60">
        Applying {motionTypes.find(t => t.id === selectedMotionType)?.name.toLowerCase()} effect...
      </p>
      <p className="text-xs text-white/40 mt-4">This may take a moment</p>
    </div>
  );

  const renderCompleteStep = () => (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-teal-500/20 flex items-center justify-center">
          <Sparkles className="w-6 h-6 text-teal-400" />
        </div>
        <h3 className="text-lg font-semibold text-white">Living Image Created!</h3>
        <p className="text-sm text-white/60">Your motion post is ready</p>
      </div>

      {generatedMotion?.videoUrl && (
        <div className="rounded-lg overflow-hidden">
          <MotionPlayer
            videoUrl={generatedMotion.videoUrl}
            thumbnailUrl={generatedMotion.thumbnailUrl}
            duration={generatedMotion.duration}
            showWatermark
            className="aspect-video"
          />
        </div>
      )}

      <div className="flex gap-3">
        <button
          onClick={() => {
            setSelectedImage(null);
            setGeneratedMotion(null);
            setStep('select');
          }}
          className="flex-1 py-2.5 rounded-lg border border-white/20 text-white font-medium hover:bg-white/5 transition-colors"
        >
          Create Another
        </button>
        <button
          onClick={onClose}
          className="flex-1 py-2.5 rounded-lg bg-gradient-to-r from-teal-500 to-cyan-500 text-white font-medium hover:from-teal-400 hover:to-cyan-400 transition-colors"
        >
          Done
        </button>
      </div>
    </div>
  );

  return (
    <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-teal-500 to-cyan-500 flex items-center justify-center">
          <Play className="w-5 h-5 text-white" fill="white" />
        </div>
        <div>
          <h2 className="font-semibold text-white">Living Images</h2>
          <p className="text-xs text-white/60">10-second AI motion from your images</p>
        </div>
      </div>

      {loading && step === 'select' ? (
        <div className="py-12 flex items-center justify-center">
          <Loader2 className="w-8 h-8 text-teal-400 animate-spin" />
        </div>
      ) : step === 'select' ? (
        renderSelectStep()
      ) : step === 'configure' ? (
        renderConfigureStep()
      ) : step === 'generating' ? (
        renderGeneratingStep()
      ) : (
        renderCompleteStep()
      )}
    </div>
  );
}
