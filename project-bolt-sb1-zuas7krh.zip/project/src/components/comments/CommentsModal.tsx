import { useState, useEffect, useRef } from 'react';
import { X, Send, Trash2, AlertCircle } from 'lucide-react';
import { useComments } from '../../hooks/useComments';
import { useAuth } from '../../contexts/AuthContext';

interface CommentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  postId: string;
  postAuthor: string;
}

export function CommentsModal({ isOpen, onClose, postId, postAuthor }: CommentsModalProps) {
  const { user, profile } = useAuth();
  const { comments, loading, error, fetchComments, addComment, deleteComment, clearError } = useComments(postId);
  const [newComment, setNewComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      requestAnimationFrame(() => setIsVisible(true));
      fetchComments();
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setIsVisible(false);
    }
  }, [isOpen, fetchComments]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || submitting) return;

    setSubmitting(true);
    clearError();
    const result = await addComment(newComment.trim());
    setSubmitting(false);

    if (result) {
      setNewComment('');
    }
  };

  const handleDelete = async (commentId: string) => {
    await deleteComment(commentId);
  };

  const timeAgo = (date: string) => {
    const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
    if (seconds < 60) return 'now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    return `${Math.floor(seconds / 86400)}d`;
  };

  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-0 z-[80] flex items-end sm:items-center justify-center transition-all duration-300 ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" />

      <div
        className={`relative w-full sm:max-w-lg sm:mx-4 max-h-[85vh] bg-[#0c0c0d] border border-white/[0.08] shadow-2xl transition-all duration-300 flex flex-col ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
        } rounded-t-[28px] sm:rounded-[28px]`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 border-b border-white/[0.04] flex-shrink-0">
          <div>
            <h2 className="text-lg font-semibold text-white">Comments</h2>
            <p className="text-xs text-surface-500 mt-0.5">on {postAuthor}'s post</p>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] flex items-center justify-center text-surface-400 hover:text-white transition-all"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4 min-h-[200px]">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-400">
              <AlertCircle size={16} />
              <span>{error}</span>
            </div>
          )}

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-8 h-8 border-2 border-accent-400/30 border-t-accent-400 rounded-full animate-spin" />
            </div>
          ) : comments.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-surface-500 text-sm">No comments yet</p>
              <p className="text-surface-600 text-xs mt-1">Be the first to comment</p>
            </div>
          ) : (
            comments.map((comment) => (
              <div key={comment.id} className="flex gap-3 group">
                <img
                  src={comment.user_profile?.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80'}
                  alt={comment.user_profile?.username || 'User'}
                  className="w-9 h-9 rounded-xl object-cover bg-surface-800 flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-white truncate">
                      {comment.user_profile?.username || 'Unknown'}
                    </span>
                    <span className="text-xs text-surface-600">{timeAgo(comment.created_at)}</span>
                  </div>
                  <p className="text-sm text-surface-300 mt-1 break-words">{comment.content}</p>
                </div>
                {user?.id === comment.user_id && (
                  <button
                    onClick={() => handleDelete(comment.id)}
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-surface-600 hover:text-red-400 hover:bg-red-500/10 opacity-0 group-hover:opacity-100 transition-all flex-shrink-0"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            ))
          )}
        </div>

        <form onSubmit={handleSubmit} className="p-4 border-t border-white/[0.04] flex-shrink-0">
          <div className="flex items-center gap-3">
            <img
              src={profile?.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80'}
              alt="You"
              className="w-9 h-9 rounded-xl object-cover bg-surface-800 flex-shrink-0"
            />
            <div className="flex-1 relative">
              <input
                ref={inputRef}
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Write a comment..."
                maxLength={500}
                className="w-full px-4 py-3 pr-12 bg-white/[0.04] border border-white/[0.06] rounded-xl text-white placeholder-surface-600 text-sm outline-none focus:border-accent-500/30 transition-all"
              />
              <button
                type="submit"
                disabled={!newComment.trim() || submitting}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg flex items-center justify-center text-accent-400 hover:bg-accent-500/10 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              >
                {submitting ? (
                  <div className="w-4 h-4 border-2 border-accent-400/30 border-t-accent-400 rounded-full animate-spin" />
                ) : (
                  <Send size={16} />
                )}
              </button>
            </div>
          </div>
          <p className="text-xs text-surface-600 text-right mt-2">{newComment.length}/500</p>
        </form>
      </div>
    </div>
  );
}
