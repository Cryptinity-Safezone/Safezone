import { Shield, Sparkles, Lock, Unlock, User } from 'lucide-react';

interface OwnershipInfoProps {
  isAIGenerated?: boolean;
  isOwner?: boolean;
  hasUnlocked?: boolean;
  creatorName?: string;
  variant?: 'compact' | 'detailed';
  className?: string;
}

export function OwnershipInfo({
  isAIGenerated = false,
  isOwner = false,
  hasUnlocked = false,
  creatorName,
  variant = 'compact',
  className = '',
}: OwnershipInfoProps) {
  if (variant === 'compact') {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        {isAIGenerated && (
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-accent-500/10 border border-accent-500/20">
            <Sparkles size={10} className="text-accent-400" />
            <span className="text-[10px] text-accent-400 font-medium">AI</span>
          </div>
        )}
        {isOwner && (
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-teal-500/10 border border-teal-500/20">
            <User size={10} className="text-teal-400" />
            <span className="text-[10px] text-teal-400 font-medium">Yours</span>
          </div>
        )}
        {hasUnlocked && !isOwner && (
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20">
            <Unlock size={10} className="text-amber-400" />
            <span className="text-[10px] text-amber-400 font-medium">Unlocked</span>
          </div>
        )}
        {!isOwner && !hasUnlocked && isAIGenerated && (
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-surface-800/50 border border-white/[0.06]">
            <Lock size={10} className="text-surface-400" />
            <span className="text-[10px] text-surface-400 font-medium">Protected</span>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`glass rounded-xl p-4 ${className}`}>
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-accent-500/10 flex items-center justify-center flex-shrink-0">
          <Shield size={16} className="text-accent-400" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="text-sm font-medium text-white">Content Ownership</h4>
            {isAIGenerated && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-accent-500/10 text-[9px] text-accent-400 font-medium">
                <Sparkles size={8} />
                AI
              </span>
            )}
          </div>
          <p className="text-xs text-surface-400 leading-relaxed">
            {isOwner ? (
              <>You created this content. It's fully yours to use, share, or sell.</>
            ) : hasUnlocked ? (
              <>You've unlocked this content. Download without watermark anytime.</>
            ) : creatorName ? (
              <>Created by <span className="text-surface-300">{creatorName}</span>. Unlock to remove the watermark.</>
            ) : (
              <>This content is protected. The watermark appears only in previews.</>
            )}
          </p>
          {!isOwner && !hasUnlocked && (
            <p className="text-[10px] text-surface-500 mt-2">
              Creators own what they generate. Watermarks exist for protection only.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
