import { useState, useEffect } from 'react';
import { X, Info, AlertCircle, CheckCircle, Sparkles } from 'lucide-react';

type NotificationType = 'info' | 'similarity' | 'success' | 'protection';

interface CalmNotificationProps {
  type: NotificationType;
  title: string;
  message: string;
  isOpen: boolean;
  onClose: () => void;
  autoClose?: boolean;
  autoCloseDelay?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

const iconMap = {
  info: Info,
  similarity: AlertCircle,
  success: CheckCircle,
  protection: Sparkles,
};

const colorMap = {
  info: {
    bg: 'from-blue-500/10 to-blue-600/5',
    border: 'border-blue-500/20',
    icon: 'text-blue-400',
    iconBg: 'bg-blue-500/10',
  },
  similarity: {
    bg: 'from-amber-500/10 to-amber-600/5',
    border: 'border-amber-500/20',
    icon: 'text-amber-400',
    iconBg: 'bg-amber-500/10',
  },
  success: {
    bg: 'from-emerald-500/10 to-emerald-600/5',
    border: 'border-emerald-500/20',
    icon: 'text-emerald-400',
    iconBg: 'bg-emerald-500/10',
  },
  protection: {
    bg: 'from-accent-500/10 to-teal-500/5',
    border: 'border-accent-500/20',
    icon: 'text-accent-400',
    iconBg: 'bg-accent-500/10',
  },
};

export function CalmNotification({
  type,
  title,
  message,
  isOpen,
  onClose,
  autoClose = false,
  autoCloseDelay = 5000,
  action,
}: CalmNotificationProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (isOpen) {
      requestAnimationFrame(() => setIsVisible(true));

      if (autoClose) {
        const timer = setTimeout(() => {
          setIsVisible(false);
          setTimeout(onClose, 300);
        }, autoCloseDelay);
        return () => clearTimeout(timer);
      }
    } else {
      setIsVisible(false);
    }
  }, [isOpen, autoClose, autoCloseDelay, onClose]);

  if (!isOpen) return null;

  const Icon = iconMap[type];
  const colors = colorMap[type];

  return (
    <div
      className={`fixed bottom-24 left-4 right-4 sm:left-auto sm:right-6 sm:max-w-sm z-50 transition-all duration-300 ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
      }`}
    >
      <div
        className={`bg-gradient-to-br ${colors.bg} backdrop-blur-xl border ${colors.border} rounded-2xl p-4 shadow-2xl`}
      >
        <div className="flex gap-3">
          <div
            className={`w-10 h-10 rounded-xl ${colors.iconBg} flex items-center justify-center flex-shrink-0`}
          >
            <Icon size={18} className={colors.icon} />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <h4 className="text-sm font-semibold text-white">{title}</h4>
              <button
                onClick={() => {
                  setIsVisible(false);
                  setTimeout(onClose, 300);
                }}
                className="w-6 h-6 rounded-lg hover:bg-white/10 flex items-center justify-center text-surface-400 hover:text-white transition-colors"
              >
                <X size={14} />
              </button>
            </div>

            <p className="text-sm text-surface-300 mt-1 leading-relaxed">{message}</p>

            {action && (
              <button
                onClick={action.onClick}
                className="mt-3 px-3 py-1.5 text-xs font-medium text-white bg-white/10 hover:bg-white/15 rounded-lg transition-colors"
              >
                {action.label}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
