import { useState, useRef } from 'react';
import { Play, Pause, Sparkles, Download, Info } from 'lucide-react';

interface ProtectedAudioProps {
  src: string;
  title: string;
  isAIGenerated?: boolean;
  duration?: number;
  showExport?: boolean;
  onExport?: () => void;
}

export function ProtectedAudio({
  src,
  title,
  isAIGenerated = false,
  duration = 0,
  showExport = false,
  onExport,
}: ProtectedAudioProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showMetadataInfo, setShowMetadataInfo] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const togglePlay = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    if (!audioRef.current) return;
    const percent = (audioRef.current.currentTime / audioRef.current.duration) * 100;
    setProgress(percent);
  };

  const handleEnded = () => {
    setIsPlaying(false);
    setProgress(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-surface-900/50 border border-white/[0.06] rounded-2xl p-4">
      <audio
        ref={audioRef}
        src={src}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleEnded}
        preload="metadata"
      />

      <div className="flex items-center gap-4">
        <button
          onClick={togglePlay}
          className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-accent-500/20 hover:shadow-accent-500/30 transition-all"
        >
          {isPlaying ? <Pause size={20} /> : <Play size={20} className="ml-0.5" />}
        </button>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <h4 className="text-sm font-medium text-white truncate">{title}</h4>
            {isAIGenerated && (
              <button
                onClick={() => setShowMetadataInfo(!showMetadataInfo)}
                className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-accent-500/10 border border-accent-500/20 hover:bg-accent-500/15 transition-colors"
              >
                <Sparkles size={10} className="text-accent-400" />
                <span className="text-[9px] text-accent-400 font-medium">AI</span>
              </button>
            )}
          </div>

          <div className="relative h-1.5 bg-white/[0.06] rounded-full overflow-hidden">
            <div
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-accent-500 to-teal-500 rounded-full transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="flex justify-between mt-1.5">
            <span className="text-[10px] text-surface-500">
              {audioRef.current ? formatTime(audioRef.current.currentTime) : '0:00'}
            </span>
            <span className="text-[10px] text-surface-500">
              {duration > 0 ? formatTime(duration) : '--:--'}
            </span>
          </div>
        </div>

        {showExport && onExport && (
          <button
            onClick={onExport}
            className="w-10 h-10 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] flex items-center justify-center text-surface-400 hover:text-white transition-all"
            title="Export with signature"
          >
            <Download size={16} />
          </button>
        )}
      </div>

      {showMetadataInfo && isAIGenerated && (
        <div className="mt-3 pt-3 border-t border-white/[0.04]">
          <div className="flex items-start gap-2 text-surface-400">
            <Info size={12} className="mt-0.5 flex-shrink-0" />
            <div className="text-[11px] leading-relaxed">
              <p className="text-surface-300 mb-1">Metadata: Generated via Cryptinity AI</p>
              <p className="text-surface-500">
                This audio contains embedded metadata identifying it as AI-generated.
                Exported files include a subtle 0.5s audio signature at the end.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
