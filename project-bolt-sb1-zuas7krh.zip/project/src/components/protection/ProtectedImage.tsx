import { useState } from 'react';
import { Maximize2, Sparkles } from 'lucide-react';
import { AIWatermark } from './AIWatermark';
import { ImageViewer } from './ImageViewer';

interface ProtectedImageProps {
  src: string;
  alt: string;
  isAIGenerated?: boolean;
  isWatermarked?: boolean;
  hasUnlocked?: boolean;
  isOwner?: boolean;
  creatorName?: string;
  className?: string;
  watermarkVariant?: 'centered' | 'tiled' | 'corner' | 'subtle';
  watermarkSize?: 'sm' | 'md' | 'lg';
  enableViewer?: boolean;
  showAIBadge?: boolean;
  onDownload?: () => void;
}

export function ProtectedImage({
  src,
  alt,
  isAIGenerated = false,
  isWatermarked = true,
  hasUnlocked = false,
  isOwner = false,
  creatorName,
  className = '',
  watermarkVariant = 'centered',
  watermarkSize = 'md',
  enableViewer = true,
  showAIBadge = true,
  onDownload,
}: ProtectedImageProps) {
  const [loaded, setLoaded] = useState(false);
  const [viewerOpen, setViewerOpen] = useState(false);

  const showWatermark = isAIGenerated && isWatermarked && !hasUnlocked && !isOwner;

  const handleClick = () => {
    if (enableViewer) {
      setViewerOpen(true);
    }
  };

  return (
    <>
      <div
        className={`relative overflow-hidden group ${enableViewer ? 'cursor-pointer' : ''} ${className}`}
        onClick={handleClick}
      >
        <img
          src={src}
          alt={alt}
          className={`w-full h-full object-cover transition-opacity duration-300 ${
            loaded ? 'opacity-100' : 'opacity-0'
          }`}
          onLoad={() => setLoaded(true)}
          draggable={false}
        />
        {showWatermark && <AIWatermark variant={watermarkVariant} size={watermarkSize} />}

        {showAIBadge && isAIGenerated && !showWatermark && (
          <div className="absolute top-3 left-3 flex items-center gap-1 px-2 py-1 rounded-lg bg-black/30 backdrop-blur-sm pointer-events-none">
            <Sparkles size={10} className="text-white/80" />
            <span className="text-[10px] text-white/80 font-medium">AI</span>
          </div>
        )}

        {enableViewer && (
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 pointer-events-none">
            <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="w-8 h-8 rounded-lg bg-black/40 backdrop-blur-sm flex items-center justify-center">
                <Maximize2 size={14} className="text-white" />
              </div>
            </div>
          </div>
        )}
      </div>

      {enableViewer && (
        <ImageViewer
          isOpen={viewerOpen}
          onClose={() => setViewerOpen(false)}
          src={src}
          alt={alt}
          isAIGenerated={isAIGenerated}
          isOwner={isOwner}
          hasUnlocked={hasUnlocked}
          creatorName={creatorName}
          onDownload={onDownload}
        />
      )}
    </>
  );
}
