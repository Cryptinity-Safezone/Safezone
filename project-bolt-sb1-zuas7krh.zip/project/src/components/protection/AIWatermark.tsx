import { Sparkles } from 'lucide-react';

interface AIWatermarkProps {
  variant?: 'centered' | 'tiled' | 'corner';
  opacity?: number;
}

export function AIWatermark({ variant = 'centered', opacity = 0.15 }: AIWatermarkProps) {
  if (variant === 'tiled') {
    return (
      <div
        className="absolute inset-0 pointer-events-none overflow-hidden select-none"
        style={{ opacity }}
      >
        <div className="absolute inset-0 flex flex-wrap items-center justify-center gap-16 -rotate-12">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="flex items-center gap-2 text-white whitespace-nowrap">
              <Sparkles size={14} />
              <span className="text-xs font-medium tracking-wide">Cryptinity</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (variant === 'corner') {
    return (
      <div
        className="absolute bottom-3 right-3 pointer-events-none select-none"
        style={{ opacity: opacity + 0.1 }}
      >
        <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-black/30 backdrop-blur-sm">
          <Sparkles size={12} className="text-white" />
          <span className="text-[10px] font-medium text-white tracking-wide">
            AI-generated
          </span>
        </div>
      </div>
    );
  }

  return (
    <div
      className="absolute inset-0 pointer-events-none flex items-center justify-center select-none"
      style={{ opacity }}
    >
      <div className="flex items-center gap-2.5 px-4 py-2 rounded-xl bg-black/20 backdrop-blur-[2px]">
        <Sparkles size={16} className="text-white/90" />
        <span className="text-sm font-medium text-white tracking-wide">
          Cryptinity <span className="text-white/70 mx-1">•</span> AI-generated
        </span>
      </div>
    </div>
  );
}
