import { useState, useEffect } from 'react';
import { X, Download, Sparkles, Shield, Info, ZoomIn, ZoomOut } from 'lucide-react';
import { AIWatermark } from './AIWatermark';

interface ImageViewerProps {
  isOpen: boolean;
  onClose: () => void;
  src: string;
  alt?: string;
  isAIGenerated?: boolean;
  isOwner?: boolean;
  hasUnlocked?: boolean;
  creatorName?: string;
  onDownload?: () => void;
}

export function ImageViewer({
  isOpen,
  onClose,
  src,
  alt = 'Image',
  isAIGenerated = false,
  isOwner = false,
  hasUnlocked = false,
  creatorName,
  onDownload,
}: ImageViewerProps) {
  const [zoom, setZoom] = useState(1);
  const [showInfo, setShowInfo] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const showWatermark = isAIGenerated && !isOwner && !hasUnlocked;
  const canDownloadClean = isOwner || hasUnlocked;

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const handleDownload = async () => {
    if (downloading) return;
    setDownloading(true);

    try {
      if (onDownload) {
        onDownload();
      } else {
        const response = await fetch(src);
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `cryptinity-${Date.now()}.jpg`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Download failed:', error);
    } finally {
      setDownloading(false);
    }
  };

  const handleZoomIn = () => setZoom(z => Math.min(z + 0.25, 3));
  const handleZoomOut = () => setZoom(z => Math.max(z - 0.25, 0.5));

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div
        className="absolute inset-0 bg-surface-950/95 backdrop-blur-xl"
        onClick={onClose}
      />

      <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          {isAIGenerated && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-accent-500/10 border border-accent-500/20">
              <Sparkles size={14} className="text-accent-400" />
              <span className="text-xs text-accent-400 font-medium">AI-generated</span>
            </div>
          )}
          {creatorName && (
            <span className="text-sm text-surface-400">by {creatorName}</span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleZoomOut}
            className="w-10 h-10 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.06] flex items-center justify-center text-surface-400 hover:text-white transition-all"
          >
            <ZoomOut size={18} />
          </button>
          <span className="text-sm text-surface-500 w-12 text-center">{Math.round(zoom * 100)}%</span>
          <button
            onClick={handleZoomIn}
            className="w-10 h-10 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.06] flex items-center justify-center text-surface-400 hover:text-white transition-all"
          >
            <ZoomIn size={18} />
          </button>
          <div className="w-px h-6 bg-white/[0.06] mx-2" />
          <button
            onClick={() => setShowInfo(!showInfo)}
            className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all ${
              showInfo
                ? 'bg-accent-500/10 border-accent-500/30 text-accent-400'
                : 'bg-white/[0.05] hover:bg-white/[0.1] border-white/[0.06] text-surface-400 hover:text-white'
            }`}
          >
            <Info size={18} />
          </button>
          {canDownloadClean && (
            <button
              onClick={handleDownload}
              disabled={downloading}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-accent-500 hover:bg-accent-400 text-white text-sm font-medium transition-all disabled:opacity-50"
            >
              <Download size={16} />
              {downloading ? 'Downloading...' : 'Download'}
            </button>
          )}
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.06] flex items-center justify-center text-surface-400 hover:text-white transition-all"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      <div className="absolute inset-0 flex items-center justify-center overflow-auto p-16">
        <div
          className="relative transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
        >
          <img
            src={src}
            alt={alt}
            className="max-w-full max-h-[80vh] object-contain rounded-lg shadow-2xl"
            draggable={false}
          />
          {showWatermark && <AIWatermark variant="centered" size="lg" opacity={0.2} />}
        </div>
      </div>

      {showInfo && (
        <div className="absolute bottom-4 left-4 right-4 max-w-lg mx-auto">
          <div className="glass rounded-2xl p-5 animate-slide-up">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-accent-500/10 flex items-center justify-center flex-shrink-0">
                <Shield size={18} className="text-accent-400" />
              </div>
              <div>
                <h4 className="text-sm font-medium text-white mb-1.5">Content Protection</h4>
                <p className="text-xs text-surface-400 leading-relaxed mb-3">
                  {isOwner ? (
                    'You own this creation. Download it without the watermark anytime.'
                  ) : hasUnlocked ? (
                    'You have unlocked this content. The watermark is removed for your downloads.'
                  ) : isAIGenerated ? (
                    'This AI-generated content displays a protective watermark. The watermark is removed when you download your own creations or unlock content from other creators.'
                  ) : (
                    'This content is protected under Cryptinity\'s creator protection system.'
                  )}
                </p>
                <div className="flex flex-wrap gap-2">
                  {isAIGenerated && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded bg-accent-500/10 text-[10px] text-accent-400 font-medium">
                      <Sparkles size={10} />
                      AI-generated
                    </span>
                  )}
                  {isOwner && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded bg-teal-500/10 text-[10px] text-teal-400 font-medium">
                      <Shield size={10} />
                      You own this
                    </span>
                  )}
                  {hasUnlocked && !isOwner && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded bg-amber-500/10 text-[10px] text-amber-400 font-medium">
                      Unlocked
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
