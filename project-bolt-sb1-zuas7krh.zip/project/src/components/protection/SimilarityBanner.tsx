import { AlertCircle, X } from 'lucide-react';

interface SimilarityBannerProps {
  onDismiss: () => void;
  onLearnMore?: () => void;
}

export function SimilarityBanner({ onDismiss, onLearnMore }: SimilarityBannerProps) {
  return (
    <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/15 rounded-2xl p-4">
      <div className="flex gap-3">
        <div className="w-9 h-9 rounded-xl bg-amber-500/10 flex items-center justify-center flex-shrink-0">
          <AlertCircle size={16} className="text-amber-400" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h4 className="text-sm font-medium text-amber-300">Similarity Detected</h4>
            <button
              onClick={onDismiss}
              className="w-6 h-6 rounded-lg hover:bg-white/10 flex items-center justify-center text-surface-400 hover:text-white transition-colors"
            >
              <X size={14} />
            </button>
          </div>

          <p className="text-sm text-surface-300 mt-1 leading-relaxed">
            We noticed some similarity with existing content. Your creation is still visible
            and shareable, but marketplace listing is temporarily paused while we review.
          </p>

          <p className="text-xs text-surface-500 mt-2">
            This usually takes 24-48 hours. You own your creation.
          </p>

          {onLearnMore && (
            <button
              onClick={onLearnMore}
              className="mt-3 text-xs text-amber-400 hover:text-amber-300 font-medium transition-colors"
            >
              Learn more about content protection
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
