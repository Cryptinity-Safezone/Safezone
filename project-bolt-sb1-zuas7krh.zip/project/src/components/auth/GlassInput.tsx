import { useState, forwardRef } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface GlassInputProps {
  label: string;
  type?: 'text' | 'email' | 'password';
  value: string;
  onChange: (value: string) => void;
  error?: string;
  disabled?: boolean;
  autoComplete?: string;
}

export const GlassInput = forwardRef<HTMLInputElement, GlassInputProps>(
  ({ label, type = 'text', value, onChange, error, disabled, autoComplete }, ref) => {
    const [isFocused, setIsFocused] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const isActive = isFocused || value.length > 0;
    const isPassword = type === 'password';
    const inputType = isPassword && showPassword ? 'text' : type;

    return (
      <div className="relative">
        <div
          className={`relative rounded-2xl transition-all duration-300 ${
            error
              ? 'ring-2 ring-red-500/30'
              : isFocused
              ? 'ring-2 ring-accent-500/30'
              : ''
          }`}
        >
          <div
            className={`absolute inset-0 rounded-2xl transition-opacity duration-300 ${
              isFocused ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.05), transparent)',
            }}
          />

          <input
            ref={ref}
            type={inputType}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            disabled={disabled}
            autoComplete={autoComplete}
            className={`
              relative w-full px-5 pt-7 pb-3
              bg-surface-900/50 border border-white/[0.08] rounded-2xl
              text-white text-[15px] font-medium
              outline-none transition-all duration-300
              placeholder-transparent
              disabled:opacity-50 disabled:cursor-not-allowed
              ${isPassword ? 'pr-12' : ''}
              ${error ? 'border-red-500/30' : isFocused ? 'border-accent-500/40' : 'hover:border-white/[0.12]'}
            `}
            placeholder={label}
          />

          <label
            className={`
              absolute left-5 transition-all duration-300 pointer-events-none
              ${
                isActive
                  ? 'top-2.5 text-[11px] tracking-wider uppercase'
                  : 'top-1/2 -translate-y-1/2 text-[15px]'
              }
              ${
                error
                  ? 'text-red-400'
                  : isFocused
                  ? 'text-accent-400'
                  : 'text-surface-500'
              }
              font-medium
            `}
          >
            {label}
          </label>

          {isPassword && (
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-surface-500 hover:text-surface-300 transition-colors p-1"
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          )}
        </div>

        {error && (
          <p className="mt-2 text-xs text-red-400 font-medium pl-1 animate-slide-down">
            {error}
          </p>
        )}
      </div>
    );
  }
);

GlassInput.displayName = 'GlassInput';
