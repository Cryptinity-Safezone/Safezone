import type { ReactNode } from 'react';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
}

export const GlassCard = ({ children, className = '' }: GlassCardProps) => (
  <div className={`relative ${className}`}>
    <div className="absolute -inset-1 bg-gradient-to-br from-accent-500/20 via-transparent to-teal-500/10 rounded-[32px] blur-xl opacity-60" />
    <div className="relative backdrop-blur-3xl bg-surface-900/70 border border-white/[0.08] rounded-[28px] shadow-2xl shadow-black/40">
      <div className="absolute inset-0 rounded-[28px] bg-gradient-to-br from-white/[0.03] to-transparent pointer-events-none" />
      <div className="relative">{children}</div>
    </div>
  </div>
);
