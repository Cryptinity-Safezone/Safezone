import type { ReactNode } from 'react';
import { Loader2 } from 'lucide-react';

interface PrimaryButtonProps {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  loading?: boolean;
  type?: 'button' | 'submit';
  className?: string;
}

export const PrimaryButton = ({
  children,
  onClick,
  disabled,
  loading,
  type = 'button',
  className = '',
}: PrimaryButtonProps) => (
  <button
    type={type}
    onClick={onClick}
    disabled={disabled || loading}
    className={`
      relative w-full py-4 px-6
      bg-gradient-to-r from-accent-500 to-teal-600
      text-white font-semibold text-[15px] tracking-wide
      rounded-2xl
      shadow-lg shadow-accent-500/20
      transition-all duration-300
      hover:shadow-xl hover:shadow-accent-500/30 hover:-translate-y-0.5
      active:scale-[0.98] active:shadow-md
      disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:translate-y-0 disabled:hover:shadow-lg
      group
      ${className}
    `}
  >
    <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    <span className="relative flex items-center justify-center gap-2">
      {loading && <Loader2 size={18} className="animate-spin" />}
      {children}
    </span>
  </button>
);

interface SecondaryButtonProps {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}

export const SecondaryButton = ({
  children,
  onClick,
  disabled,
  className = '',
}: SecondaryButtonProps) => (
  <button
    type="button"
    onClick={onClick}
    disabled={disabled}
    className={`
      w-full py-3.5 px-6
      bg-surface-800/50 border border-white/[0.08]
      text-surface-300 font-medium text-sm
      rounded-2xl
      transition-all duration-300
      hover:bg-surface-800/70 hover:border-white/[0.12] hover:text-white
      active:scale-[0.98]
      disabled:opacity-50 disabled:cursor-not-allowed
      ${className}
    `}
  >
    {children}
  </button>
);

interface SecondaryLinkProps {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  highlight?: boolean;
}

export const SecondaryLink = ({
  children,
  onClick,
  className = '',
  highlight = false,
}: SecondaryLinkProps) => (
  <button
    type="button"
    onClick={onClick}
    className={`
      text-sm font-medium
      transition-all duration-200
      hover:underline underline-offset-4
      ${highlight ? 'text-accent-400 hover:text-accent-300' : 'text-surface-500 hover:text-surface-300'}
      ${className}
    `}
  >
    {children}
  </button>
);

interface DividerProps {
  text?: string;
}

export const Divider = ({ text }: DividerProps) => (
  <div className="relative flex items-center my-6">
    <div className="flex-1 h-px bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />
    {text && (
      <span className="px-4 text-xs text-surface-600 font-medium uppercase tracking-wider">
        {text}
      </span>
    )}
    <div className="flex-1 h-px bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />
  </div>
);
