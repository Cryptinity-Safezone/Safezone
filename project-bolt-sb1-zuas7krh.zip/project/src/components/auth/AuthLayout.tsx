import type { ReactNode } from 'react';

interface AuthLayoutProps {
  children: ReactNode;
}

export const AuthLayout = ({ children }: AuthLayoutProps) => (
  <div className="min-h-screen relative flex items-center justify-center px-4 py-12 overflow-hidden">
    <div className="fixed inset-0 bg-surface-950" />

    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      <div
        className="absolute top-[-30%] left-[-20%] w-[800px] h-[800px] rounded-full opacity-30"
        style={{
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.15) 0%, transparent 70%)',
          animation: 'float 20s ease-in-out infinite',
        }}
      />
      <div
        className="absolute bottom-[-20%] right-[-15%] w-[600px] h-[600px] rounded-full opacity-20"
        style={{
          background: 'radial-gradient(circle, rgba(20, 184, 166, 0.12) 0%, transparent 70%)',
          animation: 'float 25s ease-in-out infinite reverse',
        }}
      />
      <div
        className="absolute top-[40%] right-[10%] w-[400px] h-[400px] rounded-full opacity-15"
        style={{
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.1) 0%, transparent 70%)',
          animation: 'float 15s ease-in-out infinite',
        }}
      />

      <div
        className="absolute inset-0 opacity-[0.015]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />

      <div className="absolute inset-0 bg-gradient-to-b from-surface-950/50 via-transparent to-surface-950/80" />
    </div>

    <div className="relative z-10 w-full max-w-[420px]">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-[20px] mb-5 overflow-hidden">
          <img src="/711-removebg-preview.png" alt="Cryptinity" className="w-full h-full object-contain" />
        </div>
        <h1 className="text-2xl font-bold text-white tracking-wide mb-2">
          Cryptinity<span className="text-accent-400">.</span>
        </h1>
        <p className="text-sm text-surface-500 font-medium max-w-xs mx-auto leading-relaxed">
          Purity & Creativity is the Essence of Cryptinity
        </p>
      </div>

      {children}
    </div>
  </div>
);
