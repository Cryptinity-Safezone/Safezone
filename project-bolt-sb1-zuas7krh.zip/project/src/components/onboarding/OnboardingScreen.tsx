import { useState } from 'react';
import { Zap, Shield, Heart, ArrowRight, Check } from 'lucide-react';
import { Background } from '../Background';

interface OnboardingScreenProps {
  onComplete: () => void;
}

interface Screen {
  icon: React.ReactNode;
  title: string;
  description: string;
  details: string[];
}

const screens: Screen[] = [
  {
    icon: <Shield className="text-accent-400" size={32} />,
    title: 'Welcome to Cryptinity',
    description: 'A SafeZone for your creativity',
    details: [
      'No algorithms controlling what you see',
      'Content appears chronologically, not by manipulation',
      'Your feed is yours—pure, unfiltered, human',
      'Create and share without the noise',
    ],
  },
  {
    icon: <Zap className="text-yellow-400 fill-yellow-400" size={32} />,
    title: 'Meet CTY⚡',
    description: 'Creative energy, not currency',
    details: [
      'CTY is internal creative utility—not money',
      'Used to unlock features and support creators',
      'Earn by sharing and engaging authentically',
      'Cannot be withdrawn or sold—it stays here',
    ],
  },
  {
    icon: <Heart className="text-red-400 fill-red-400" size={32} />,
    title: 'Stay Free Forever',
    description: 'Care for your inner time',
    details: [
      'Free tier gives you full creative freedom',
      'Upgrade only for extra features, not core access',
      'No hidden costs, no forced subscriptions',
      'Your creative home, your choice',
    ],
  },
];

export const OnboardingScreen = ({ onComplete }: OnboardingScreenProps) => {
  const [currentScreen, setCurrentScreen] = useState(0);
  const isLastScreen = currentScreen === screens.length - 1;
  const screen = screens[currentScreen];

  const handleNext = () => {
    if (isLastScreen) {
      onComplete();
    } else {
      setCurrentScreen(currentScreen + 1);
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <Background />

      <div className="relative z-10 w-full max-w-md">
        <div className="card p-8 animate-fade-in">
          <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-accent-500/10 to-teal-500/10 border border-accent-500/20 mx-auto mb-6">
            {screen.icon}
          </div>

          <h1 className="text-2xl font-semibold text-white/95 text-center mb-3">
            {screen.title}
          </h1>

          <p className="text-surface-400/80 text-center mb-8 font-light">
            {screen.description}
          </p>

          <div className="space-y-4 mb-8">
            {screen.details.map((detail, index) => (
              <div
                key={index}
                className="flex items-start gap-3 animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-5 h-5 rounded-lg bg-accent-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check size={12} className="text-accent-400" />
                </div>
                <p className="text-sm text-white/70 leading-[1.7] font-light">
                  {detail}
                </p>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center gap-2 mb-8">
            {screens.map((_, index) => (
              <div
                key={index}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  index === currentScreen
                    ? 'w-8 bg-accent-500'
                    : 'w-1.5 bg-white/10'
                }`}
              />
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleSkip}
              className="flex-1 px-5 py-3 text-sm text-surface-400/80 hover:text-white/80 transition-colors duration-200 font-medium"
            >
              Skip
            </button>
            <button
              onClick={handleNext}
              className="flex-1 px-5 py-3 bg-gradient-to-r from-accent-500/90 to-teal-600/90 text-white text-sm font-medium rounded-xl hover:from-accent-500 hover:to-teal-600 transition-all duration-200 flex items-center justify-center gap-2 shadow-lg shadow-accent-500/10"
            >
              {isLastScreen ? 'Get Started' : 'Next'}
              <ArrowRight size={16} />
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-surface-600/60 mt-6 font-light">
          Cryptinity — Care for your inner time
        </p>
      </div>
    </div>
  );
};
