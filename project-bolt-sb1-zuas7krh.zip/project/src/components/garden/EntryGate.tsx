import { useState } from 'react';
import { Flower2, Send, Edit3 } from 'lucide-react';
import type { DailyQuestion, UserState } from '../../hooks/useHiddenGarden';

interface EntryGateProps {
  question: DailyQuestion;
  userState: UserState | null;
  canEdit: boolean;
  themeName?: string;
  themeColor?: string;
  onSubmit: (answer: string) => Promise<{ error?: string }>;
  onEnter: () => void;
}

export function EntryGate({ question, userState, canEdit, themeName, themeColor, onSubmit, onEnter }: EntryGateProps) {
  const [answer, setAnswer] = useState(userState?.answer || '');
  const [isEditing, setIsEditing] = useState(!userState?.answer);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async () => {
    if (!answer.trim()) {
      setError('Please share something before entering');
      return;
    }

    setLoading(true);
    setError(null);

    const result = await onSubmit(answer.trim());

    if (result.error) {
      setError(result.error);
      setLoading(false);
      return;
    }

    setIsEditing(false);
    setLoading(false);
  };

  const hasAnswered = Boolean(userState?.answer);
  const accentColor = themeColor || '#10b981';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-xl">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-900/20 via-black to-black" />
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 rounded-full animate-pulse"
            style={{
              backgroundColor: `${accentColor}4d`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`
            }}
          />
        ))}
      </div>

      <div className="relative w-full max-w-lg mx-4 p-8">
        <div className="text-center mb-8">
          <div
            className="inline-flex items-center justify-center w-16 h-16 rounded-full mb-6"
            style={{
              backgroundColor: `${accentColor}1a`,
              borderColor: `${accentColor}33`,
              borderWidth: '1px'
            }}
          >
            <Flower2 className="w-8 h-8" style={{ color: accentColor }} />
          </div>

          <h1 className="text-2xl font-light text-white mb-2">
            {themeName || 'Hidden Garden'}
          </h1>
          <p className="text-white/50 text-sm font-light">
            Take a breath before you speak.
          </p>
        </div>

        <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-6 mb-6">
          <p className="text-emerald-300/80 text-sm mb-2 font-medium">Today's reflection</p>
          <p className="text-white text-lg font-light leading-relaxed">
            {question.question}
          </p>
        </div>

        {isEditing ? (
          <div className="space-y-4">
            <div className="relative">
              <textarea
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="Share your thoughts..."
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-emerald-500/50 resize-none h-32 font-light"
                maxLength={500}
                autoFocus
              />
              <span className="absolute bottom-3 right-3 text-xs text-white/30">
                {answer.length}/500
              </span>
            </div>

            {error && (
              <p className="text-red-400 text-sm">{error}</p>
            )}

            <button
              onClick={handleSubmit}
              disabled={loading || !answer.trim()}
              className="w-full flex items-center justify-center gap-2 py-3 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 rounded-xl text-emerald-300 font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-emerald-300/30 border-t-emerald-300 rounded-full animate-spin" />
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  {hasAnswered ? 'Update & Enter' : 'Enter the Garden'}
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4">
              <p className="text-white/70 text-sm mb-1">Your reflection:</p>
              <p className="text-white font-light">{userState?.answer}</p>
            </div>

            <div className="flex gap-3">
              {canEdit && (
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-white/70 font-medium transition-all"
                >
                  <Edit3 className="w-4 h-4" />
                  Edit Once
                </button>
              )}

              <button
                onClick={onEnter}
                className="flex-1 flex items-center justify-center gap-2 py-3 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 rounded-xl text-emerald-300 font-medium transition-all"
              >
                <Flower2 className="w-4 h-4" />
                Enter Garden
              </button>
            </div>

            {!canEdit && (
              <p className="text-white/30 text-xs text-center">
                You've already edited your reflection today
              </p>
            )}
          </div>
        )}

        <p className="text-center text-white/30 text-xs mt-6">
          Your answer is visible to others in the garden
        </p>
      </div>
    </div>
  );
}
