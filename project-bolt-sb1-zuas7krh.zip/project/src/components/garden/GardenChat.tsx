import { useState, useRef, useEffect } from 'react';
import { Send, Heart, Leaf, Star, Hand, Sparkles, MoreVertical, Trash2, VolumeX } from 'lucide-react';
import type { GardenMessage, MessageReaction, GardenSettings } from '../../hooks/useHiddenGarden';

interface GardenChatProps {
  messages: GardenMessage[];
  settings: GardenSettings | null;
  isMuted: boolean;
  isAdmin: boolean;
  currentUserId?: string;
  onSendMessage: (content: string, isReflection?: boolean) => Promise<{ error?: string }>;
  onToggleReaction: (messageId: string, reaction: MessageReaction['reaction']) => void;
  onRemoveMessage?: (messageId: string) => void;
  onMuteUser?: (userId: string, minutes: number, reason?: string) => void;
}

const REACTION_ICONS = {
  heart: Heart,
  leaf: Leaf,
  star: Star,
  peace: Hand,
  hug: Sparkles
};

const REACTION_COLORS = {
  heart: 'text-rose-400',
  leaf: 'text-emerald-400',
  star: 'text-amber-400',
  peace: 'text-sky-400',
  hug: 'text-violet-400'
};

function MessageBubble({
  message,
  isOwn,
  isAdmin,
  currentUserId,
  onToggleReaction,
  onRemoveMessage,
  onMuteUser
}: {
  message: GardenMessage;
  isOwn: boolean;
  isAdmin: boolean;
  currentUserId?: string;
  onToggleReaction: (messageId: string, reaction: MessageReaction['reaction']) => void;
  onRemoveMessage?: (messageId: string) => void;
  onMuteUser?: (userId: string, minutes: number, reason?: string) => void;
}) {
  const [showReactions, setShowReactions] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className={`group flex gap-3 ${isOwn ? 'flex-row-reverse' : ''}`}>
      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500/30 to-teal-500/30 flex items-center justify-center flex-shrink-0 border border-white/10">
        {message.user?.avatar_url ? (
          <img
            src={message.user.avatar_url}
            alt=""
            className="w-full h-full rounded-full object-cover"
          />
        ) : (
          <span className="text-emerald-300 text-sm font-medium">
            {message.user?.username?.[0]?.toUpperCase() || '?'}
          </span>
        )}
      </div>

      <div className={`flex-1 max-w-[70%] ${isOwn ? 'text-right' : ''}`}>
        <div className="flex items-center gap-2 mb-1">
          {!isOwn && (
            <span className="text-white/80 text-sm font-medium">
              {message.user?.username || 'Anonymous'}
            </span>
          )}
          {message.user_answer && (
            <span className="text-emerald-400/60 text-xs italic truncate max-w-[150px]">
              "{message.user_answer}"
            </span>
          )}
          {isOwn && (
            <span className="text-white/80 text-sm font-medium ml-auto">You</span>
          )}
        </div>

        <div className="relative inline-block">
          <div
            className={`relative px-4 py-2.5 rounded-2xl ${
              isOwn
                ? 'bg-emerald-500/20 border border-emerald-500/30'
                : 'bg-white/5 border border-white/10'
            } ${message.is_reflection ? 'italic' : ''}`}
            onMouseEnter={() => setShowReactions(true)}
            onMouseLeave={() => {
              setShowReactions(false);
              setShowMenu(false);
            }}
          >
            <p className="text-white/90 font-light text-sm leading-relaxed whitespace-pre-wrap">
              {message.content}
            </p>

            <span className="text-white/30 text-xs mt-1 block">
              {formatTime(message.created_at)}
              {message.is_reflection && ' • reflection'}
            </span>

            {showReactions && (
              <div className={`absolute ${isOwn ? 'left-0' : 'right-0'} -bottom-10 flex items-center gap-1 bg-black/80 backdrop-blur-sm rounded-full px-2 py-1 border border-white/10 z-10`}>
                {(Object.keys(REACTION_ICONS) as Array<keyof typeof REACTION_ICONS>).map((reaction) => {
                  const Icon = REACTION_ICONS[reaction];
                  const existingReaction = message.reactions?.find(r => r.reaction === reaction);
                  return (
                    <button
                      key={reaction}
                      onClick={() => onToggleReaction(message.id, reaction)}
                      className={`p-1.5 rounded-full hover:bg-white/10 transition-colors ${
                        existingReaction?.user_reacted ? REACTION_COLORS[reaction] : 'text-white/40'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </button>
                  );
                })}

                {isAdmin && !isOwn && (
                  <div className="relative border-l border-white/10 ml-1 pl-1">
                    <button
                      onClick={() => setShowMenu(!showMenu)}
                      className="p-1.5 rounded-full hover:bg-white/10 text-white/40"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {showMenu && (
                      <div className="absolute bottom-full right-0 mb-2 bg-black/90 backdrop-blur-sm rounded-lg border border-white/10 py-1 min-w-[140px]">
                        <button
                          onClick={() => {
                            onRemoveMessage?.(message.id);
                            setShowMenu(false);
                          }}
                          className="w-full px-3 py-2 text-left text-sm text-red-400 hover:bg-white/5 flex items-center gap-2"
                        >
                          <Trash2 className="w-4 h-4" />
                          Remove
                        </button>
                        <button
                          onClick={() => {
                            onMuteUser?.(message.user_id, 2, 'Muted by moderator');
                            setShowMenu(false);
                          }}
                          className="w-full px-3 py-2 text-left text-sm text-amber-400 hover:bg-white/5 flex items-center gap-2"
                        >
                          <VolumeX className="w-4 h-4" />
                          Mute 2min
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {message.reactions && message.reactions.length > 0 && (
            <div className={`flex gap-1 mt-1 ${isOwn ? 'justify-end' : ''}`}>
              {message.reactions.map((r) => {
                const Icon = REACTION_ICONS[r.reaction];
                return (
                  <button
                    key={r.reaction}
                    onClick={() => onToggleReaction(message.id, r.reaction)}
                    className={`flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-xs ${
                      r.user_reacted ? REACTION_COLORS[r.reaction] : 'text-white/50'
                    }`}
                  >
                    <Icon className="w-3 h-3" />
                    {r.count}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function GardenChat({
  messages,
  settings,
  isMuted,
  isAdmin,
  currentUserId,
  onSendMessage,
  onToggleReaction,
  onRemoveMessage,
  onMuteUser
}: GardenChatProps) {
  const [newMessage, setNewMessage] = useState('');
  const [isReflection, setIsReflection] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSend = async () => {
    if (!newMessage.trim() || sending) return;

    setSending(true);
    setError(null);

    const result = await onSendMessage(newMessage.trim(), isReflection);

    if (result.error) {
      setError(result.error);
    } else {
      setNewMessage('');
      setIsReflection(false);
    }

    setSending(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full">
      {settings?.pinned_content && (
        <div className="px-4 py-3 bg-emerald-500/10 border-b border-emerald-500/20">
          <div className="flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <span className="text-emerald-400/60 text-xs uppercase tracking-wide">
                {settings.pinned_type || 'Pinned'}
              </span>
              <p className="text-white/80 text-sm font-light mt-0.5">
                {settings.pinned_content}
              </p>
            </div>
          </div>
        </div>
      )}

      <div
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto px-4 py-4 space-y-4 scrollbar-thin scrollbar-thumb-white/10"
      >
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-12">
            <Leaf className="w-12 h-12 text-emerald-400/30 mb-4" />
            <p className="text-white/40 font-light">The garden is quiet...</p>
            <p className="text-white/30 text-sm mt-1">Be the first to share</p>
          </div>
        ) : (
          messages.map((msg) => (
            <MessageBubble
              key={msg.id}
              message={msg}
              isOwn={msg.user_id === currentUserId}
              isAdmin={isAdmin}
              currentUserId={currentUserId}
              onToggleReaction={onToggleReaction}
              onRemoveMessage={onRemoveMessage}
              onMuteUser={onMuteUser}
            />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-white/10 bg-black/20">
        {isMuted ? (
          <div className="flex items-center justify-center gap-2 py-3 text-amber-400/80 bg-amber-500/10 rounded-xl border border-amber-500/20">
            <VolumeX className="w-4 h-4" />
            <span className="text-sm">You are temporarily muted</span>
          </div>
        ) : (
          <>
            {error && (
              <p className="text-red-400 text-xs mb-2">{error}</p>
            )}

            <div className="flex items-end gap-2">
              <div className="flex-1 relative">
                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Share a thought..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 pr-24 text-white placeholder-white/30 focus:outline-none focus:border-emerald-500/30 resize-none text-sm font-light"
                  rows={1}
                  maxLength={500}
                  style={{ minHeight: '44px', maxHeight: '120px' }}
                />

                <div className="absolute right-2 bottom-2 flex items-center gap-1">
                  <button
                    onClick={() => setIsReflection(!isReflection)}
                    className={`px-2 py-1 rounded-lg text-xs transition-colors ${
                      isReflection
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-white/40 hover:text-white/60'
                    }`}
                    title="Mark as reflection"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={handleSend}
                    disabled={!newMessage.trim() || sending}
                    className="p-2 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {sending ? (
                      <div className="w-4 h-4 border-2 border-emerald-300/30 border-t-emerald-300 rounded-full animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            <p className="text-white/20 text-xs mt-2 text-center">
              Be kind. This is a safe space.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
