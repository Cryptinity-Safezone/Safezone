import { useState, useEffect } from 'react';
import {
  Settings,
  MessageSquare,
  Music,
  Trash2,
  Pin,
  Palette,
  X,
  Check,
  Plus,
  Play,
  Pause,
  RefreshCw,
  Clock,
  Sparkles,
  ChevronDown,
  Zap
} from 'lucide-react';
import type {
  GardenSettings,
  GardenMusic,
  AutomationState,
  GardenTheme,
  GardenQuestion,
  GardenTrack
} from '../../hooks/useHiddenGarden';

interface AdminControlsProps {
  settings: GardenSettings | null;
  allMusic: GardenMusic[];
  activeMusic: GardenMusic | null;
  automation: AutomationState | null;
  allThemes: GardenTheme[];
  onUpdateSettings: (updates: Partial<GardenSettings>) => Promise<{ error?: string }>;
  onSetPinned: (content: string | null, type: GardenSettings['pinned_type']) => Promise<{ error?: string }>;
  onSetActiveTrack: (musicId: string | null) => Promise<{ error?: string; success?: boolean }>;
  onClearChat: () => Promise<{ error?: string }>;
  onOverrideTheme: (themeId: string) => Promise<{ error?: string; success?: boolean }>;
  onOverrideQuestion: (questionId: string) => Promise<{ error?: string; success?: boolean }>;
  onOverrideTrack: (trackId: string | null) => Promise<{ error?: string; success?: boolean }>;
  onToggleTrackPaused: (paused: boolean) => Promise<{ error?: string; success?: boolean }>;
  onClearOverride: (type: 'theme' | 'question' | 'track') => Promise<{ error?: string; success?: boolean }>;
  getThemeQuestions: (themeId: string) => Promise<GardenQuestion[]>;
  getThemeTracks: (themeId: string) => Promise<GardenTrack[]>;
  onClose: () => void;
}

const COLOR_MOODS = [
  { value: 'calm', label: 'Calm', colors: 'from-emerald-900/20 to-teal-900/20' },
  { value: 'dark', label: 'Dark', colors: 'from-gray-900 to-black' },
  { value: 'green', label: 'Forest', colors: 'from-green-900/30 to-emerald-900/30' },
  { value: 'night', label: 'Night', colors: 'from-indigo-900/20 to-slate-900/30' }
] as const;

const PIN_TYPES = [
  { value: 'quote', label: 'Quote' },
  { value: 'message', label: 'Message' },
  { value: 'reflection', label: 'Reflection' },
  { value: 'question', label: 'Question' },
  { value: 'reminder', label: 'Reminder' }
] as const;

export function AdminControls({
  settings,
  allMusic,
  activeMusic,
  automation,
  allThemes,
  onUpdateSettings,
  onSetPinned,
  onSetActiveTrack,
  onClearChat,
  onOverrideTheme,
  onOverrideQuestion,
  onOverrideTrack,
  onToggleTrackPaused,
  onClearOverride,
  getThemeQuestions,
  getThemeTracks,
  onClose
}: AdminControlsProps) {
  const [activeTab, setActiveTab] = useState<'automation' | 'appearance' | 'pinned' | 'music' | 'moderation'>('automation');
  const [pinnedContent, setPinnedContent] = useState(settings?.pinned_content || '');
  const [pinnedType, setPinnedType] = useState<GardenSettings['pinned_type']>(settings?.pinned_type || 'quote');
  const [backgroundUrl, setBackgroundUrl] = useState(settings?.background_image || '');
  const [saving, setSaving] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  const [showThemeSelect, setShowThemeSelect] = useState(false);
  const [showQuestionSelect, setShowQuestionSelect] = useState(false);
  const [showTrackSelect, setShowTrackSelect] = useState(false);
  const [themeQuestions, setThemeQuestions] = useState<GardenQuestion[]>([]);
  const [themeTracks, setThemeTracks] = useState<GardenTrack[]>([]);

  useEffect(() => {
    if (automation?.theme?.id) {
      getThemeQuestions(automation.theme.id).then(setThemeQuestions);
      getThemeTracks(automation.theme.id).then(setThemeTracks);
    }
  }, [automation?.theme?.id, getThemeQuestions, getThemeTracks]);

  const handleSaveAppearance = async () => {
    setSaving(true);
    await onUpdateSettings({
      background_image: backgroundUrl,
      background_motion: settings?.background_motion || false,
      color_mood: settings?.color_mood || 'calm'
    });
    setSaving(false);
  };

  const handleSavePinned = async () => {
    setSaving(true);
    await onSetPinned(pinnedContent || null, pinnedContent ? pinnedType : null);
    setSaving(false);
  };

  const handleClearPinned = async () => {
    setSaving(true);
    await onSetPinned(null, null);
    setPinnedContent('');
    setSaving(false);
  };

  const handleClearChat = async () => {
    if (!confirmClear) {
      setConfirmClear(true);
      return;
    }
    await onClearChat();
    setConfirmClear(false);
  };

  const handleThemeSelect = async (themeId: string) => {
    setSaving(true);
    await onOverrideTheme(themeId);
    setShowThemeSelect(false);
    setSaving(false);
  };

  const handleQuestionSelect = async (questionId: string) => {
    setSaving(true);
    await onOverrideQuestion(questionId);
    setShowQuestionSelect(false);
    setSaving(false);
  };

  const handleTrackSelect = async (trackId: string | null) => {
    setSaving(true);
    await onOverrideTrack(trackId);
    setShowTrackSelect(false);
    setSaving(false);
  };

  const tabs = [
    { id: 'automation', label: 'Auto', icon: Zap },
    { id: 'appearance', label: 'Look', icon: Palette },
    { id: 'pinned', label: 'Pin', icon: Pin },
    { id: 'music', label: 'Music', icon: Music },
    { id: 'moderation', label: 'Mod', icon: Settings }
  ] as const;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-gray-900 rounded-2xl border border-white/10 w-full max-w-md max-h-[80vh] overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
          <h2 className="text-white font-medium">Garden Controls</h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/5 text-white/60"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex border-b border-white/10 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-medium transition-colors whitespace-nowrap px-2 ${
                activeTab === tab.id
                  ? 'text-emerald-400 border-b-2 border-emerald-400 -mb-px'
                  : 'text-white/50 hover:text-white/70'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-4 overflow-y-auto max-h-[60vh]">
          {activeTab === 'automation' && (
            <div className="space-y-4">
              <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-emerald-300 font-medium">Automation Status</h3>
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-white/5 rounded-lg p-2">
                    <span className="text-white/40">Theme rotates</span>
                    <p className="text-white font-medium">Every 7 days</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-2">
                    <span className="text-white/40">Question changes</span>
                    <p className="text-white font-medium">Every 24 hours</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-2">
                    <span className="text-white/40">Track changes</span>
                    <p className="text-white font-medium">Every 24 hours</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-2">
                    <span className="text-white/40">Admin effort</span>
                    <p className="text-white font-medium">&lt; 5 min/week</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="bg-white/5 border border-white/10 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: automation?.theme?.mood_color || '#4a6fa5' }}
                      />
                      <span className="text-white/70 text-sm">Current Theme</span>
                    </div>
                    {automation?.overrides.theme && (
                      <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded">Override</span>
                    )}
                  </div>
                  <p className="text-white font-medium">{automation?.theme?.name || 'Loading...'}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Clock className="w-3 h-3 text-white/40" />
                    <span className="text-white/40 text-xs">
                      {automation?.meta.theme_days_remaining || 0} days remaining
                    </span>
                  </div>

                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() => setShowThemeSelect(!showThemeSelect)}
                      className="flex-1 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-white/60 text-xs flex items-center justify-center gap-1"
                    >
                      Change Theme
                      <ChevronDown className={`w-3 h-3 transition-transform ${showThemeSelect ? 'rotate-180' : ''}`} />
                    </button>
                    {automation?.overrides.theme && (
                      <button
                        onClick={() => onClearOverride('theme')}
                        className="py-1.5 px-3 bg-amber-500/10 hover:bg-amber-500/20 rounded-lg text-amber-300 text-xs flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        Auto
                      </button>
                    )}
                  </div>

                  {showThemeSelect && (
                    <div className="mt-2 space-y-1">
                      {allThemes.map(theme => (
                        <button
                          key={theme.id}
                          onClick={() => handleThemeSelect(theme.id)}
                          disabled={saving}
                          className={`w-full text-left p-2 rounded-lg text-xs transition-colors ${
                            theme.id === automation?.theme?.id
                              ? 'bg-emerald-500/20 border border-emerald-500/30'
                              : 'bg-white/5 hover:bg-white/10 border border-transparent'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: theme.mood_color }}
                            />
                            <span className="text-white font-medium">{theme.name}</span>
                          </div>
                          <p className="text-white/40 mt-0.5 ml-4">{theme.description}</p>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-white/5 border border-white/10 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white/70 text-sm">Today's Question</span>
                    {automation?.overrides.question && (
                      <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded">Override</span>
                    )}
                  </div>
                  <p className="text-white text-sm italic">
                    "{automation?.question?.question || 'Loading...'}"
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-white/40 text-xs">
                      Day {automation?.question?.day_number || 1} of 7
                    </span>
                  </div>

                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() => setShowQuestionSelect(!showQuestionSelect)}
                      className="flex-1 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-white/60 text-xs flex items-center justify-center gap-1"
                    >
                      Change Question
                      <ChevronDown className={`w-3 h-3 transition-transform ${showQuestionSelect ? 'rotate-180' : ''}`} />
                    </button>
                    {automation?.overrides.question && (
                      <button
                        onClick={() => onClearOverride('question')}
                        className="py-1.5 px-3 bg-amber-500/10 hover:bg-amber-500/20 rounded-lg text-amber-300 text-xs flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        Auto
                      </button>
                    )}
                  </div>

                  {showQuestionSelect && (
                    <div className="mt-2 space-y-1 max-h-40 overflow-y-auto">
                      {themeQuestions.map(q => (
                        <button
                          key={q.id}
                          onClick={() => handleQuestionSelect(q.id)}
                          disabled={saving}
                          className={`w-full text-left p-2 rounded-lg text-xs transition-colors ${
                            q.id === automation?.question?.id
                              ? 'bg-emerald-500/20 border border-emerald-500/30'
                              : 'bg-white/5 hover:bg-white/10 border border-transparent'
                          }`}
                        >
                          <span className="text-white/40">Day {q.day_number}:</span>
                          <span className="text-white ml-1">{q.question}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-white/5 border border-white/10 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white/70 text-sm">Ambient Music</span>
                    <div className="flex items-center gap-2">
                      {automation?.track_paused && (
                        <span className="text-xs bg-red-500/20 text-red-300 px-2 py-0.5 rounded">Paused</span>
                      )}
                      {automation?.overrides.track && (
                        <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded">Override</span>
                      )}
                    </div>
                  </div>
                  <p className="text-white font-medium">{automation?.track?.track_name || 'No track selected'}</p>

                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() => onToggleTrackPaused(!automation?.track_paused)}
                      className={`py-1.5 px-3 rounded-lg text-xs flex items-center gap-1 ${
                        automation?.track_paused
                          ? 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300'
                          : 'bg-red-500/10 hover:bg-red-500/20 text-red-300'
                      }`}
                    >
                      {automation?.track_paused ? (
                        <>
                          <Play className="w-3 h-3" />
                          Resume
                        </>
                      ) : (
                        <>
                          <Pause className="w-3 h-3" />
                          Pause
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => setShowTrackSelect(!showTrackSelect)}
                      className="flex-1 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-white/60 text-xs flex items-center justify-center gap-1"
                    >
                      Change Track
                      <ChevronDown className={`w-3 h-3 transition-transform ${showTrackSelect ? 'rotate-180' : ''}`} />
                    </button>
                    {automation?.overrides.track && (
                      <button
                        onClick={() => onClearOverride('track')}
                        className="py-1.5 px-3 bg-amber-500/10 hover:bg-amber-500/20 rounded-lg text-amber-300 text-xs flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        Auto
                      </button>
                    )}
                  </div>

                  {showTrackSelect && (
                    <div className="mt-2 space-y-1">
                      {themeTracks.map(track => (
                        <button
                          key={track.id}
                          onClick={() => handleTrackSelect(track.id)}
                          disabled={saving}
                          className={`w-full text-left p-2 rounded-lg text-xs transition-colors ${
                            track.id === automation?.track?.id
                              ? 'bg-emerald-500/20 border border-emerald-500/30'
                              : 'bg-white/5 hover:bg-white/10 border border-transparent'
                          }`}
                        >
                          <span className="text-white">{track.track_name}</span>
                          <span className="text-white/40 ml-2">
                            {Math.floor(track.duration_seconds / 60)}:{(track.duration_seconds % 60).toString().padStart(2, '0')}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'appearance' && (
            <div className="space-y-4">
              <div>
                <label className="block text-white/70 text-sm mb-2">Color Mood</label>
                <div className="grid grid-cols-2 gap-2">
                  {COLOR_MOODS.map(mood => (
                    <button
                      key={mood.value}
                      onClick={() => onUpdateSettings({ color_mood: mood.value })}
                      className={`p-3 rounded-lg border transition-all ${
                        settings?.color_mood === mood.value
                          ? 'border-emerald-500 bg-emerald-500/10'
                          : 'border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className={`h-8 rounded bg-gradient-to-br ${mood.colors} mb-2`} />
                      <span className="text-white/80 text-xs">{mood.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-white/70 text-sm mb-2">Background Image URL</label>
                <input
                  type="url"
                  value={backgroundUrl}
                  onChange={(e) => setBackgroundUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm placeholder-white/30 focus:outline-none focus:border-emerald-500/50"
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="text-white/70 text-sm">Subtle Motion</label>
                <button
                  onClick={() => onUpdateSettings({ background_motion: !settings?.background_motion })}
                  className={`w-12 h-6 rounded-full transition-colors ${
                    settings?.background_motion ? 'bg-emerald-500' : 'bg-white/10'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${
                    settings?.background_motion ? 'translate-x-6' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>

              <button
                onClick={handleSaveAppearance}
                disabled={saving}
                className="w-full py-2 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 rounded-lg text-emerald-300 text-sm font-medium transition-colors disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save Appearance'}
              </button>
            </div>
          )}

          {activeTab === 'pinned' && (
            <div className="space-y-4">
              <div>
                <label className="block text-white/70 text-sm mb-2">Pin Type</label>
                <div className="flex flex-wrap gap-2">
                  {PIN_TYPES.map(type => (
                    <button
                      key={type.value}
                      onClick={() => setPinnedType(type.value)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                        pinnedType === type.value
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-white/5 text-white/60 border border-white/10 hover:border-white/20'
                      }`}
                    >
                      {type.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-white/70 text-sm mb-2">Content</label>
                <textarea
                  value={pinnedContent}
                  onChange={(e) => setPinnedContent(e.target.value)}
                  placeholder="Enter content to pin..."
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm placeholder-white/30 focus:outline-none focus:border-emerald-500/50 resize-none h-24"
                  maxLength={300}
                />
                <span className="text-white/30 text-xs">{pinnedContent.length}/300</span>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleSavePinned}
                  disabled={saving}
                  className="flex-1 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 rounded-lg text-emerald-300 text-sm font-medium transition-colors disabled:opacity-50"
                >
                  <Pin className="w-4 h-4 inline mr-1" />
                  Pin Content
                </button>

                {settings?.pinned_content && (
                  <button
                    onClick={handleClearPinned}
                    disabled={saving}
                    className="py-2 px-4 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 rounded-lg text-red-400 text-sm font-medium transition-colors disabled:opacity-50"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          )}

          {activeTab === 'music' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-white/80 text-sm font-medium">Music Library</h3>
                <button className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30">
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {allMusic.length === 0 ? (
                <div className="text-center py-8">
                  <Music className="w-10 h-10 text-white/20 mx-auto mb-2" />
                  <p className="text-white/40 text-sm">No music uploaded yet</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {allMusic.map(track => (
                    <div
                      key={track.id}
                      className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
                        track.is_active
                          ? 'bg-emerald-500/10 border-emerald-500/30'
                          : 'bg-white/5 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <button
                        onClick={() => onSetActiveTrack(track.is_active ? null : track.id)}
                        className={`p-2 rounded-full ${
                          track.is_active
                            ? 'bg-emerald-500/30 text-emerald-300'
                            : 'bg-white/10 text-white/60 hover:bg-white/20'
                        }`}
                      >
                        <Play className="w-4 h-4" />
                      </button>

                      <div className="flex-1 min-w-0">
                        <p className="text-white text-sm font-medium truncate">{track.title}</p>
                        <p className="text-white/40 text-xs">{track.mood}</p>
                      </div>

                      {track.is_active && (
                        <Check className="w-4 h-4 text-emerald-400" />
                      )}
                    </div>
                  ))}
                </div>
              )}

              {activeMusic && (
                <button
                  onClick={() => onSetActiveTrack(null)}
                  className="w-full py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-white/60 text-sm transition-colors"
                >
                  Stop Music
                </button>
              )}
            </div>
          )}

          {activeTab === 'moderation' && (
            <div className="space-y-4">
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <MessageSquare className="w-5 h-5 text-amber-400 mt-0.5" />
                  <div>
                    <h4 className="text-amber-300 font-medium text-sm">Clear All Messages</h4>
                    <p className="text-white/50 text-xs mt-1">
                      This will remove all messages from the garden. This cannot be undone.
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleClearChat}
                  className={`w-full mt-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    confirmClear
                      ? 'bg-red-500 hover:bg-red-600 text-white'
                      : 'bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 text-amber-300'
                  }`}
                >
                  {confirmClear ? (
                    <>
                      <Trash2 className="w-4 h-4 inline mr-1" />
                      Confirm Clear
                    </>
                  ) : (
                    'Clear Chat'
                  )}
                </button>

                {confirmClear && (
                  <button
                    onClick={() => setConfirmClear(false)}
                    className="w-full mt-2 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-white/60 text-sm"
                  >
                    Cancel
                  </button>
                )}
              </div>

              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <h4 className="text-white/80 font-medium text-sm mb-2">Auto-Moderation</h4>
                <ul className="space-y-2 text-white/50 text-xs">
                  <li className="flex items-center gap-2">
                    <Check className="w-3 h-3 text-emerald-400" />
                    Spam detection: 5 messages/minute limit
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-3 h-3 text-emerald-400" />
                    Auto-mute on spam: 2 minutes
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-3 h-3 text-emerald-400" />
                    Message removal available on hover
                  </li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
