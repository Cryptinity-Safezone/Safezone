import { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, Play, Pause, Music, Sparkles } from 'lucide-react';
import type { GardenMusic as GardenMusicType } from '../../hooks/useHiddenGarden';

interface GardenMusicProps {
  music: GardenMusicType | null;
  isMinimized?: boolean;
}

export function GardenMusic({ music, isMinimized = false }: GardenMusicProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.3);
  const [isMuted, setIsMuted] = useState(false);
  const [showVolume, setShowVolume] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (music?.audio_url) {
      if (audioRef.current) {
        audioRef.current.pause();
      }

      const audio = new Audio(music.audio_url);
      audio.volume = music.volume || 0.3;
      audio.loop = music.loop_enabled;

      audio.addEventListener('timeupdate', () => {
        setCurrentTime(audio.currentTime);
      });

      audio.addEventListener('play', () => setIsPlaying(true));
      audio.addEventListener('pause', () => setIsPlaying(false));

      audioRef.current = audio;
      setVolume(music.volume || 0.3);

      audio.play().catch(() => {
        setIsPlaying(false);
      });

      return () => {
        audio.pause();
        audio.src = '';
      };
    }
  }, [music?.audio_url, music?.loop_enabled, music?.volume]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  const togglePlay = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(() => {});
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!music) return null;

  if (isMinimized) {
    return (
      <div className="flex items-center gap-2">
        <button
          onClick={togglePlay}
          className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 transition-colors"
        >
          {isPlaying ? (
            <Pause className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <Play className="w-3.5 h-3.5 text-emerald-400" />
          )}
        </button>

        <div className="flex items-center gap-1.5">
          <Music className="w-3 h-3 text-emerald-400/60" />
          <span className="text-white/50 text-xs truncate max-w-[100px]">
            {music.title}
          </span>
        </div>

        <button
          onClick={() => setIsMuted(!isMuted)}
          className="p-1 text-white/40 hover:text-white/60"
        >
          {isMuted ? (
            <VolumeX className="w-3.5 h-3.5" />
          ) : (
            <Volume2 className="w-3.5 h-3.5" />
          )}
        </button>
      </div>
    );
  }

  return (
    <div className="bg-black/40 backdrop-blur-sm rounded-xl border border-white/10 p-4">
      <div className="flex items-start gap-4">
        <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/20 flex items-center justify-center flex-shrink-0">
          <Music className="w-6 h-6 text-emerald-400" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h4 className="text-white font-medium text-sm truncate">
                {music.title}
              </h4>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-white/40 text-xs">{music.mood}</span>
                {music.is_ai_generated && (
                  <span className="flex items-center gap-1 text-emerald-400/60 text-xs">
                    <Sparkles className="w-3 h-3" />
                    AI
                  </span>
                )}
              </div>
            </div>

            <span className="text-white/30 text-xs flex-shrink-0">
              {formatTime(currentTime)} / {formatTime(music.duration || 0)}
            </span>
          </div>

          <div className="mt-3 flex items-center gap-3">
            <button
              onClick={togglePlay}
              className="p-2 rounded-full bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 transition-colors"
            >
              {isPlaying ? (
                <Pause className="w-4 h-4 text-emerald-300" />
              ) : (
                <Play className="w-4 h-4 text-emerald-300" />
              )}
            </button>

            <div
              className="relative flex-1"
              onMouseEnter={() => setShowVolume(true)}
              onMouseLeave={() => setShowVolume(false)}
            >
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-1 text-white/50 hover:text-white/70"
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-4 h-4" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </button>

                {showVolume && (
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={isMuted ? 0 : volume}
                    onChange={(e) => {
                      const newVolume = parseFloat(e.target.value);
                      setVolume(newVolume);
                      setIsMuted(newVolume === 0);
                    }}
                    className="w-20 h-1 bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-emerald-400"
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
