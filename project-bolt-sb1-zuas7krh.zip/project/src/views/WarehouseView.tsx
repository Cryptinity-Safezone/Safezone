import { useState } from 'react';
import {
  FolderLock,
  Shield,
  Image,
  Film,
  Music,
  Sparkles,
  Calendar,
  Trash2,
  X,
  Check,
  AlertCircle
} from 'lucide-react';
import { useShowcase, ShowcaseItem } from '../hooks/useShowcase';
import { useAuth } from '../contexts/AuthContext';

type MediaFilter = 'all' | 'image' | 'motion' | 'audio' | 'video';

const MEDIA_ICONS = {
  image: Image,
  motion: Film,
  video: Film,
  audio: Music,
} as const;

const MEDIA_LABELS = {
  image: 'AI Images',
  motion: 'Living Images',
  video: 'Videos',
  audio: 'Soundscapes',
} as const;

function ShowcaseCard({
  item,
  onRemove
}: {
  item: ShowcaseItem;
  onRemove: (id: string) => void;
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [imageError, setImageError] = useState(false);
  const Icon = MEDIA_ICONS[item.media_type] || Image;

  const handleRemove = () => {
    if (confirmDelete) {
      onRemove(item.id);
    } else {
      setConfirmDelete(true);
      setTimeout(() => setConfirmDelete(false), 3000);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="glass rounded-2xl overflow-hidden group">
      <div className="aspect-square relative bg-surface-900/50">
        {item.media_type === 'audio' ? (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-orange-500/10 to-surface-900">
            <div className="w-16 h-16 rounded-2xl bg-orange-500/20 flex items-center justify-center">
              <Music size={28} className="text-orange-400" />
            </div>
          </div>
        ) : item.media_type === 'motion' || item.media_type === 'video' ? (
          imageError ? (
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-teal-500/10 to-surface-900">
              <Film size={28} className="text-teal-400" />
            </div>
          ) : (
            <>
              <img
                src={item.media_url}
                alt={item.title}
                className="w-full h-full object-cover"
                onError={() => setImageError(true)}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
                  <Film size={20} className="text-white" />
                </div>
              </div>
            </>
          )
        ) : (
          imageError ? (
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-accent-500/10 to-surface-900">
              <Image size={28} className="text-accent-400" />
            </div>
          ) : (
            <img
              src={item.media_url}
              alt={item.title}
              className="w-full h-full object-cover"
              onError={() => setImageError(true)}
            />
          )
        )}

        <div className="absolute top-2 left-2">
          <div className="px-2 py-1 rounded-lg bg-surface-900/80 backdrop-blur-sm flex items-center gap-1.5">
            <Icon size={12} className="text-accent-400" />
            <span className="text-xs font-medium text-surface-300">
              {MEDIA_LABELS[item.media_type] || item.media_type}
            </span>
          </div>
        </div>

        {item.is_protected && (
          <div className="absolute top-2 right-2">
            <div className="w-6 h-6 rounded-lg bg-surface-900/80 backdrop-blur-sm flex items-center justify-center">
              <Shield size={12} className="text-accent-400" />
            </div>
          </div>
        )}

        <button
          onClick={handleRemove}
          className={`absolute bottom-2 right-2 w-8 h-8 rounded-lg backdrop-blur-sm flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 ${
            confirmDelete
              ? 'bg-red-500/80 text-white'
              : 'bg-surface-900/80 text-surface-400 hover:text-red-400'
          }`}
        >
          {confirmDelete ? <Check size={14} /> : <Trash2 size={14} />}
        </button>
      </div>

      <div className="p-3">
        <h3 className="text-sm font-medium text-white truncate">{item.title}</h3>
        <div className="flex items-center gap-1.5 mt-1.5">
          <Calendar size={11} className="text-surface-500" />
          <span className="text-xs text-surface-500">{formatDate(item.created_at)}</span>
        </div>
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="text-center py-16">
      <div className="relative inline-flex mb-6">
        <div className="absolute -inset-4 bg-surface-700/20 rounded-full blur-2xl" />
        <div className="relative w-20 h-20 rounded-3xl bg-surface-800/50 border border-white/5 flex items-center justify-center">
          <Sparkles size={32} className="text-surface-500" />
        </div>
      </div>
      <h3 className="text-lg font-medium text-surface-400 mb-2">No Creations Yet</h3>
      <p className="text-sm text-surface-600 max-w-xs mx-auto leading-relaxed">
        Generate AI images, living images, or soundscapes, then tap "Add to Showcase" to store them here.
      </p>
    </div>
  );
}

function FilterTabs({
  active,
  onChange,
  counts
}: {
  active: MediaFilter;
  onChange: (filter: MediaFilter) => void;
  counts: Record<string, number>;
}) {
  const filters: { id: MediaFilter; label: string; icon: typeof Image }[] = [
    { id: 'all', label: 'All', icon: FolderLock },
    { id: 'image', label: 'Images', icon: Image },
    { id: 'motion', label: 'Motion', icon: Film },
    { id: 'audio', label: 'Audio', icon: Music },
  ];

  return (
    <div className="flex gap-2 overflow-x-auto pb-2 hide-scrollbar">
      {filters.map(({ id, label, icon: Icon }) => {
        const count = id === 'all'
          ? Object.values(counts).reduce((a, b) => a + b, 0)
          : counts[id] || 0;
        const isActive = active === id;

        return (
          <button
            key={id}
            onClick={() => onChange(id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
              isActive
                ? 'bg-accent-500/20 text-accent-400 border border-accent-500/30'
                : 'glass text-surface-400 hover:text-white'
            }`}
          >
            <Icon size={16} />
            <span className="text-sm font-medium">{label}</span>
            <span className={`text-xs px-1.5 py-0.5 rounded-md ${
              isActive ? 'bg-accent-500/30' : 'bg-surface-700/50'
            }`}>
              {count}
            </span>
          </button>
        );
      })}
    </div>
  );
}

export function WarehouseView() {
  const { user } = useAuth();
  const { items, groupedItems, loading, error, removeFromShowcase, clearError } = useShowcase();
  const [filter, setFilter] = useState<MediaFilter>('all');

  const counts = {
    image: groupedItems.images.length,
    motion: groupedItems.motion.length,
    video: groupedItems.videos.length,
    audio: groupedItems.audio.length,
  };

  const filteredItems = filter === 'all'
    ? items
    : items.filter(item => item.media_type === filter);

  if (!user) {
    return (
      <div className="pt-24 pb-32 px-4 max-w-lg mx-auto animate-fade-in">
        <div className="text-center">
          <div className="w-20 h-20 rounded-3xl bg-surface-800/50 border border-white/5 flex items-center justify-center mx-auto mb-6">
            <FolderLock size={32} className="text-surface-500" />
          </div>
          <h1 className="text-xl font-semibold text-white mb-2">Sign In Required</h1>
          <p className="text-sm text-surface-500">
            Please sign in to access your showcase
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-32 px-4 max-w-2xl mx-auto animate-fade-in">
      <div className="text-center mb-8">
        <div className="relative inline-flex mb-5">
          <div className="absolute -inset-4 bg-accent-500/15 rounded-full blur-2xl" />
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-accent-500/20 to-teal-500/10 border border-accent-500/20 flex items-center justify-center">
            <FolderLock size={28} className="text-accent-400" />
          </div>
        </div>
        <h1 className="text-2xl font-bold text-white mb-2">Your Showcase</h1>
        <p className="text-sm text-surface-500 max-w-sm mx-auto">
          A private vault for your AI-generated creations
        </p>
      </div>

      <div className="glass rounded-2xl p-4 mb-6 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-accent-500/10 flex items-center justify-center">
          <Shield size={16} className="text-accent-400" />
        </div>
        <div className="flex-1">
          <p className="text-sm text-surface-400">
            <span className="text-white font-medium">{items.length}</span> protected {items.length === 1 ? 'item' : 'items'} in your vault
          </p>
        </div>
      </div>

      {error && (
        <div className="glass rounded-2xl p-4 mb-6 flex items-center gap-3 border border-red-500/20">
          <AlertCircle size={18} className="text-red-400 flex-shrink-0" />
          <p className="text-sm text-red-400 flex-1">{error}</p>
          <button onClick={clearError} className="text-surface-500 hover:text-white">
            <X size={16} />
          </button>
        </div>
      )}

      <div className="mb-6">
        <FilterTabs active={filter} onChange={setFilter} counts={counts} />
      </div>

      {loading ? (
        <div className="grid grid-cols-2 gap-3">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="glass rounded-2xl overflow-hidden animate-pulse">
              <div className="aspect-square bg-surface-800/50" />
              <div className="p-3 space-y-2">
                <div className="h-4 bg-surface-800/50 rounded w-3/4" />
                <div className="h-3 bg-surface-800/50 rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : filteredItems.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {filteredItems.map(item => (
            <ShowcaseCard
              key={item.id}
              item={item}
              onRemove={removeFromShowcase}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default WarehouseView;
