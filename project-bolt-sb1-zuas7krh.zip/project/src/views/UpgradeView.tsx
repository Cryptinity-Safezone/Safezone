import { useState } from 'react';
import { Sparkles, Image, Music, Package, Star, Zap, Shield, Heart, Check, Eye } from 'lucide-react';
import { PlanPreviewModal } from '../components/pricing/PlanPreviewModal';
import { HelpButton, AskCryptinity } from '../components/assistant';

type PlanType = 'free' | 'personal' | 'creator';

interface PlanCardProps {
  name: string;
  price: string;
  description: string;
  features: string[];
  cta: string;
  isPopular?: boolean;
  isFree?: boolean;
  planType: PlanType;
  onPreview: () => void;
}

const PlanCard = ({ name, price, description, features, cta, isPopular, isFree, onPreview }: PlanCardProps) => (
  <div
    className={`relative rounded-[24px] backdrop-blur-xl border transition-all duration-300 ${
      isPopular
        ? 'bg-surface-900/60 border-accent-500/30 shadow-glow'
        : 'bg-surface-900/40 border-white/[0.06] hover:border-white/[0.1]'
    }`}
  >
    {isPopular && (
      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
        <div className="px-4 py-1.5 rounded-full bg-gradient-to-r from-accent-500 to-teal-600 text-white text-xs font-semibold tracking-wide shadow-glow-sm">
          Most Personal
        </div>
      </div>
    )}

    <div className="p-8">
      <h3 className="text-2xl font-bold text-white mb-2 tracking-tight">{name}</h3>
      <div className="flex items-baseline gap-2 mb-4">
        <span className="text-4xl font-bold text-white">{price}</span>
        {!isFree && <span className="text-surface-500 text-sm">/month</span>}
      </div>
      <p className="text-surface-400 text-sm leading-relaxed mb-6">{description}</p>

      <button
        onClick={onPreview}
        className="w-full flex items-center justify-center gap-2 py-2.5 mb-6 rounded-xl bg-white/[0.03] border border-white/[0.06] text-surface-400 hover:text-white hover:bg-white/[0.05] hover:border-white/[0.1] transition-all duration-200"
      >
        <Eye size={16} />
        <span className="text-sm font-medium">Preview Your Space</span>
      </button>

      <ul className="space-y-3 mb-8">
        {features.map((feature, i) => (
          <li key={i} className="flex items-start gap-3 text-sm text-surface-300">
            <Check size={18} className="text-accent-400 flex-shrink-0 mt-0.5" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>

      <button
        className={`w-full py-3.5 rounded-2xl font-semibold text-sm tracking-wide transition-all duration-300 ${
          isPopular
            ? 'bg-gradient-to-r from-accent-500 to-teal-600 text-white shadow-lg shadow-accent-500/20 hover:shadow-xl hover:shadow-accent-500/30 hover:-translate-y-0.5'
            : isFree
            ? 'bg-surface-800/60 text-surface-300 border border-white/[0.08] hover:bg-surface-700/60'
            : 'bg-surface-800/80 text-white border border-white/[0.1] hover:bg-surface-700/80 hover:border-accent-500/30'
        }`}
      >
        {cta}
      </button>
    </div>
  </div>
);

interface FeatureSectionProps {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  description: string;
  benefits: string[];
}

const FeatureSection = ({ icon, title, subtitle, description, benefits }: FeatureSectionProps) => (
  <div className="relative group">
    <div className="absolute -inset-4 bg-gradient-to-br from-accent-500/5 via-transparent to-transparent rounded-[32px] blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

    <div className="relative backdrop-blur-xl bg-surface-900/40 border border-white/[0.06] rounded-[24px] p-8 md:p-10 transition-all duration-300 hover:border-white/[0.1]">
      <div className="flex items-start gap-6">
        <div className="w-14 h-14 rounded-2xl bg-accent-500/10 border border-accent-500/20 flex items-center justify-center flex-shrink-0">
          <div className="text-accent-400">{icon}</div>
        </div>

        <div className="flex-1">
          <h3 className="text-2xl font-bold text-white mb-2 tracking-tight">{title}</h3>
          <p className="text-accent-400 text-sm font-medium mb-4">{subtitle}</p>
          <p className="text-surface-300 leading-relaxed mb-6">{description}</p>

          <div className="space-y-2.5">
            {benefits.map((benefit, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-accent-500/60 mt-2.5 flex-shrink-0" />
                <p className="text-surface-400 text-sm leading-relaxed">{benefit}</p>
              </div>
            ))}
          </div>

          <p className="text-surface-500 text-sm italic mt-6 leading-relaxed">
            {title === 'Your Profile Is Your Inner World' &&
              'When your space feels right, expression becomes easier.'}
            {title === 'Sound Is Emotion' && 'Peace is sometimes silence — and sometimes the right sound at the right moment.'}
            {title === 'Give Your Creativity Room to Stay' && "Creativity shouldn't feel temporary. Your ideas deserve space."}
            {title === "Share Only When You're Ready" &&
              "Share because you want to be seen. Not because a system demands it."}
            {title === 'CTY⚡ Powers Creation, Not Addiction' &&
              'Creation has more meaning when it comes from intention.'}
          </p>
        </div>
      </div>
    </div>
  </div>
);

export const UpgradeView = () => {
  const [previewPlan, setPreviewPlan] = useState<PlanType | null>(null);
  const [showAssistant, setShowAssistant] = useState(false);
  const [assistantQuestion, setAssistantQuestion] = useState<string>();

  const openAssistant = (question?: string) => {
    setAssistantQuestion(question);
    setShowAssistant(true);
  };

  return (
    <div className="min-h-screen pb-32">
      <PlanPreviewModal
        isOpen={previewPlan !== null}
        onClose={() => setPreviewPlan(null)}
        planType={previewPlan || 'free'}
      />
      <AskCryptinity
        isOpen={showAssistant}
        onClose={() => {
          setShowAssistant(false);
          setAssistantQuestion(undefined);
        }}
        initialQuestion={assistantQuestion}
      />

      <div className="max-w-6xl mx-auto px-6 pt-28 pb-16">
        <div className="text-center mb-16 animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight mb-4">
            Customize Your Space
          </h1>
          <p className="text-xl text-surface-400 max-w-2xl mx-auto leading-relaxed mb-3">
            Cryptinity is free to enter.
          </p>
          <p className="text-lg text-surface-400 max-w-2xl mx-auto leading-relaxed">
            Upgrading simply gives you more room to express who you are.
          </p>
        </div>

        <div className="relative backdrop-blur-xl bg-surface-900/30 border border-white/[0.05] rounded-[28px] p-8 md:p-10 mb-20 animate-fade-in">
          <p className="text-surface-300 text-center leading-relaxed max-w-3xl mx-auto">
            This is not about status or competition. It's about creating a space that feels{' '}
            <span className="text-accent-400 font-medium">safe</span>,{' '}
            <span className="text-accent-400 font-medium">personal</span>, and{' '}
            <span className="text-accent-400 font-medium">calm</span>.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-24 animate-fade-in" style={{ animationDelay: '100ms' }}>
          <PlanCard
            name="Free"
            price="$0"
            description="Start your journey in the SafeZone. Create, share, and explore."
            features={[
              'Basic profile customization',
              '100 CTY⚡ monthly allowance',
              '2 Showcase slots',
              'Essential Warehouse storage',
              'Standard AI generation',
            ]}
            cta="Stay Free"
            isFree
            planType="free"
            onPreview={() => setPreviewPlan('free')}
          />

          <PlanCard
            name="Personal"
            price="$6"
            description="Expand your creative room. Make your space feel like home."
            features={[
              'Premium cover photos & avatars',
              '500 CTY⚡ monthly allowance',
              '5 Showcase slots',
              'Extended Warehouse (5GB)',
              'Background sounds & music',
              'Higher quality AI generation',
            ]}
            cta="Customize My Space"
            isPopular
            planType="personal"
            onPreview={() => setPreviewPlan('personal')}
          />

          <PlanCard
            name="Creator"
            price="$12"
            description="Full creative freedom. Room for everything you want to keep."
            features={[
              'All Personal features',
              '1,500 CTY⚡ monthly allowance',
              'Unlimited Showcase slots',
              'Expanded Warehouse (20GB)',
              'Personal sound libraries',
              'Priority AI generation',
              'Early access to new features',
            ]}
            cta="Unlock More Expression"
            planType="creator"
            onPreview={() => setPreviewPlan('creator')}
          />
        </div>

        <div className="space-y-12 mb-24">
          <FeatureSection
            icon={<Image size={24} />}
            title="Your Profile Is Your Inner World"
            subtitle="Your profile is not a performance. It's a reflection of what you feel, imagine, and carry inside."
            description="With CTY⚡ Energy, you can apply high-quality cover photos, use premium avatars & profile images, and create a space that feels like home."
            benefits={[
              'Apply high-quality cover photos that represent your mood',
              'Use premium avatars & profile images without compression',
              'Customize your profile colors and themes',
              'Add personal touches that make the space truly yours',
            ]}
          />

          <FeatureSection
            icon={<Music size={24} />}
            title="Sound Is Emotion"
            subtitle="Sound helps us feel grounded. It can calm the mind, unlock memories, or bring comfort."
            description="Upgraded plans allow higher quality background sounds, longer ambient loops, and personal sound libraries. Optional playback is always muted by default."
            benefits={[
              'Higher quality background sounds (256kbps+)',
              'Longer ambient loops for uninterrupted calm',
              'Personal sound libraries for your favorite tracks',
              'Optional playback (always muted by default, always your choice)',
            ]}
          />

          <FeatureSection
            icon={<Package size={24} />}
            title="Give Your Creativity Room to Stay"
            subtitle="Free users can create. Upgraded users can keep more."
            description="Expanded Warehouse provides more space for images, sounds, and creations. Less pressure to delete or choose. A private place for thoughts to exist safely."
            benefits={[
              'More space for images, sounds, and all your creations',
              'Less pressure to delete or make difficult choices',
              'A private place for thoughts to exist safely',
              'Automatic organization and easy retrieval',
            ]}
          />

          <FeatureSection
            icon={<Star size={24} />}
            title="Share Only When You're Ready"
            subtitle="The Showcase is optional. There is no ranking, no boosting, no algorithm."
            description="Upgrading unlocks more Showcase slots and more ways to present your art. Freedom to share — or keep private."
            benefits={[
              'More Showcase slots to display your best work',
              'More ways to present your art (galleries, collections)',
              'Freedom to share publicly or keep completely private',
              'No pressure, no performance metrics, no comparison',
            ]}
          />

          <FeatureSection
            icon={<Sparkles size={24} />}
            title="CTY⚡ Powers Creation, Not Addiction"
            subtitle="CTY⚡ Energy fuels AI-generated images, sounds, and abstract expressions."
            description="Limits exist to protect system health, keep creation intentional, and avoid endless, empty generation."
            benefits={[
              'Fuel AI-generated images and abstract art',
              'Create sounds and ambient compositions',
              'Generate thoughtful, intentional content',
              'Limits designed to encourage meaning over quantity',
            ]}
          />
        </div>

        <div className="relative backdrop-blur-xl bg-surface-900/40 border border-white/[0.06] rounded-[28px] p-10 mb-16">
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <h3 className="text-2xl font-bold text-white tracking-tight">
                CTY Energy Packs
              </h3>
              <HelpButton
                question="What is CTY and how does it work?"
                onClick={openAssistant}
                size="md"
              />
            </div>
            <p className="text-surface-400 leading-relaxed max-w-2xl mx-auto mb-8">
              CTY⚡ is an internal utility used only inside Cryptinity. It has no real-world value,
              cannot be withdrawn, and cannot be traded. Energy Packs help sustain AI creation
              tools, storage systems, and platform stability.
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
              {[
                { amount: '250', price: '$2' },
                { amount: '600', price: '$5' },
                { amount: '1,500', price: '$10' },
                { amount: '4,000', price: '$25' },
              ].map((pack) => (
                <div
                  key={pack.amount}
                  className="backdrop-blur-xl bg-surface-800/40 border border-white/[0.06] rounded-2xl p-5 hover:border-accent-500/30 transition-all duration-300"
                >
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Zap size={16} className="text-accent-400 fill-accent-400" />
                    <span className="text-xl font-bold text-white">{pack.amount}</span>
                  </div>
                  <p className="text-surface-400 text-sm">{pack.price}</p>
                </div>
              ))}
            </div>

            <p className="text-surface-500 text-sm mt-8 italic">
              CTY is creative energy. It renews monthly and is never a currency.
            </p>
          </div>
        </div>

        <div className="relative backdrop-blur-xl bg-accent-500/5 border border-accent-500/20 rounded-[28px] p-10 mb-12 shadow-glow-sm">
          <div className="flex items-start gap-6">
            <div className="w-14 h-14 rounded-2xl bg-accent-500/10 border border-accent-500/20 flex items-center justify-center flex-shrink-0">
              <Shield size={24} className="text-accent-400" />
            </div>

            <div className="flex-1">
              <h3 className="text-2xl font-bold text-white mb-4 tracking-tight">
                Cryptinity is a SafeZone
              </h3>

              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div className="space-y-2.5">
                  <p className="text-surface-300 flex items-center gap-2">
                    <span className="text-accent-400">✓</span> No algorithms
                  </p>
                  <p className="text-surface-300 flex items-center gap-2">
                    <span className="text-accent-400">✓</span> No manipulation
                  </p>
                  <p className="text-surface-300 flex items-center gap-2">
                    <span className="text-accent-400">✓</span> No discrimination
                  </p>
                </div>
                <div className="space-y-2.5">
                  <p className="text-surface-300 flex items-center gap-2">
                    <span className="text-accent-400">✓</span> No performance pressure
                  </p>
                  <p className="text-surface-300 flex items-center gap-2">
                    <span className="text-accent-400">✓</span> Express anonymously
                  </p>
                  <p className="text-surface-300 flex items-center gap-2">
                    <span className="text-accent-400">✓</span> Step away anytime
                  </p>
                </div>
              </div>

              <p className="text-surface-400 mt-6 leading-relaxed">
                You are free to create without judgment, socialize gently, and exist in your own
                way.
              </p>
            </div>
          </div>
        </div>

        <div className="relative backdrop-blur-xl bg-surface-900/30 border border-white/[0.04] rounded-[24px] p-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Heart size={20} className="text-accent-400" />
            <h4 className="text-lg font-semibold text-white">Anti-Manipulation Guarantee</h4>
          </div>
          <p className="text-surface-400 text-sm leading-relaxed max-w-2xl mx-auto">
            Cryptinity will never pressure you to upgrade. No dark patterns. No fear tactics. No
            artificial scarcity. Your value here is never tied to money.
          </p>
        </div>
      </div>
    </div>
  );
};
