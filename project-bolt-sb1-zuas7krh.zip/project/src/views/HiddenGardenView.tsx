import { useState, useMemo } from 'react';
import { Flower2, Settings, X, ChevronLeft } from 'lucide-react';
import { useHiddenGarden } from '../hooks/useHiddenGarden';
import { useAuth } from '../contexts/AuthContext';
import { EntryGate, GardenChat, GardenMusic, AdminControls } from '../components/garden';

interface HiddenGardenViewProps {
  onClose: () => void;
}

const COLOR_MOOD_STYLES = {
  calm: 'from-emerald-950/80 via-teal-950/60 to-black',
  dark: 'from-gray-950 via-gray-900 to-black',
  green: 'from-green-950/80 via-emerald-950/60 to-black',
  night: 'from-slate-950 via-slate-900/80 to-black'
};

export function HiddenGardenView({ onClose }: HiddenGardenViewProps) {
  const { user } = useAuth();
  const {
    settings,
    dailyQuestion,
    userState,
    messages,
    activeMusic,
    allMusic,
    loading,
    isAdmin,
    hasAnswered,
    canEdit,
    isMuted,
    submitAnswer,
    sendMessage,
    toggleReaction,
    setActiveTrack,
    updateSettings,
    setPinnedContent,
    muteUser,
    removeMessage,
    clearChat,
    automation,
    allThemes,
    currentThemeQuestion,
    overrideTheme,
    overrideQuestion,
    overrideTrack,
    toggleTrackPaused,
    clearOverride,
    getThemeQuestions,
    getThemeTracks
  } = useHiddenGarden();

  const [showAdminControls, setShowAdminControls] = useState(false);
  const [hasEntered, setHasEntered] = useState(false);

  const displayQuestion = useMemo(() => {
    if (automation?.question) {
      return {
        id: automation.question.id,
        question: automation.question.question,
        active_date: new Date().toISOString().split('T')[0]
      };
    }
    return dailyQuestion;
  }, [automation?.question, dailyQuestion]);

  const themeGradient = useMemo(() => {
    if (automation?.theme?.background_gradient) {
      return automation.theme.background_gradient;
    }
    return null;
  }, [automation?.theme]);

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black">
        <div className="text-center">
          <Flower2 className="w-12 h-12 text-emerald-400/50 mx-auto mb-4 animate-pulse" />
          <p className="text-white/40 text-sm">Entering the garden...</p>
        </div>
      </div>
    );
  }

  if (!displayQuestion) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black">
        <div className="text-center">
          <p className="text-white/60">Unable to load the garden</p>
          <button
            onClick={onClose}
            className="mt-4 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white text-sm"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  if (!hasAnswered || !hasEntered) {
    return (
      <EntryGate
        question={displayQuestion}
        userState={userState}
        canEdit={canEdit}
        themeName={automation?.theme?.name}
        themeColor={automation?.theme?.mood_color}
        onSubmit={async (answer) => {
          const result = await submitAnswer(answer, displayQuestion.id);
          return result;
        }}
        onEnter={() => setHasEntered(true)}
      />
    );
  }

  const colorMood = settings?.color_mood || 'calm';
  const gradientClass = COLOR_MOOD_STYLES[colorMood];
  const moodColor = automation?.theme?.mood_color || '#10b981';

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black">
      <div className="absolute inset-0 overflow-hidden">
        {themeGradient ? (
          <div
            className="absolute inset-0"
            style={{ background: themeGradient }}
          />
        ) : (
          <div className={`absolute inset-0 bg-gradient-to-b ${gradientClass}`} />
        )}

        {settings?.background_image && (
          <div
            className="absolute inset-0 bg-cover bg-center opacity-20"
            style={{ backgroundImage: `url(${settings.background_image})` }}
          />
        )}

        {settings?.background_motion && (
          <div className="absolute inset-0">
            {[...Array(30)].map((_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 rounded-full"
                style={{
                  backgroundColor: `${moodColor}33`,
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animation: `float ${8 + Math.random() * 4}s ease-in-out infinite`,
                  animationDelay: `${Math.random() * 5}s`
                }}
              />
            ))}
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/40" />
      </div>

      <header className="relative z-10 flex items-center justify-between px-4 py-3 border-b border-white/5">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 -ml-2 rounded-lg hover:bg-white/5 text-white/60 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{
                backgroundColor: `${moodColor}20`,
                borderColor: `${moodColor}40`,
                borderWidth: '1px'
              }}
            >
              <Flower2 className="w-4 h-4" style={{ color: moodColor }} />
            </div>
            <div>
              <h1 className="text-white font-medium text-sm">
                {automation?.theme?.name || 'Hidden Garden'}
              </h1>
              <p className="text-white/40 text-xs">{messages.length} messages today</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {activeMusic && !automation?.track_paused && (
            <GardenMusic music={activeMusic} isMinimized />
          )}

          {isAdmin && (
            <button
              onClick={() => setShowAdminControls(true)}
              className="p-2 rounded-lg hover:bg-white/5 text-white/60 transition-colors"
            >
              <Settings className="w-5 h-5" />
            </button>
          )}

          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/5 text-white/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      <main className="relative z-10 flex-1 overflow-hidden">
        <GardenChat
          messages={messages}
          settings={settings}
          isMuted={isMuted}
          isAdmin={isAdmin}
          currentUserId={user?.id}
          onSendMessage={sendMessage}
          onToggleReaction={toggleReaction}
          onRemoveMessage={isAdmin ? removeMessage : undefined}
          onMuteUser={isAdmin ? muteUser : undefined}
        />
      </main>

      {showAdminControls && isAdmin && (
        <AdminControls
          settings={settings}
          allMusic={allMusic}
          activeMusic={activeMusic}
          automation={automation}
          allThemes={allThemes}
          onUpdateSettings={updateSettings}
          onSetPinned={setPinnedContent}
          onSetActiveTrack={setActiveTrack}
          onClearChat={clearChat}
          onOverrideTheme={overrideTheme}
          onOverrideQuestion={overrideQuestion}
          onOverrideTrack={overrideTrack}
          onToggleTrackPaused={toggleTrackPaused}
          onClearOverride={clearOverride}
          getThemeQuestions={getThemeQuestions}
          getThemeTracks={getThemeTracks}
          onClose={() => setShowAdminControls(false)}
        />
      )}

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0) translateX(0); opacity: 0.2; }
          25% { transform: translateY(-20px) translateX(10px); opacity: 0.4; }
          50% { transform: translateY(-10px) translateX(-5px); opacity: 0.3; }
          75% { transform: translateY(-30px) translateX(5px); opacity: 0.2; }
        }
      `}</style>
    </div>
  );
}
