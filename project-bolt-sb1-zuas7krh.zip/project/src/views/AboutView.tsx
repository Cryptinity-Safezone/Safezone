import { useState } from 'react';
import {
  Zap,
  Shield,
  Heart,
  Target,
  Eye,
  HelpCircle,
  ChevronDown,
  Volume2,
  Hand,
  Feather,
  Clock,
  Users,
  Globe,
} from 'lucide-react';

const VALUES = [
  { icon: Volume2, title: 'Calm over noise', desc: 'Quiet spaces for clear minds' },
  { icon: Hand, title: 'Choice over pressure', desc: 'You decide when and how' },
  { icon: Feather, title: 'Expression over performance', desc: 'Be real, not viral' },
  { icon: Shield, title: 'Safety over virality', desc: 'Protection before reach' },
  { icon: Clock, title: 'Human time over algorithmic time', desc: 'Your pace, your rhythm' },
];

const FAQ_ITEMS = [
  {
    q: 'Is Cryptinity crypto?',
    a: 'No. Cryptinity is not a cryptocurrency platform. We are a social platform focused on creativity and human connection.',
  },
  {
    q: 'What is CTY?',
    a: 'CTY is creative energy — not money. It supports intentional creation and cannot be traded or sold.',
  },
  {
    q: 'Is it algorithm-free?',
    a: 'Yes. Your feed is chronological and not manipulated by engagement algorithms. You see content from people you follow, in order.',
  },
  {
    q: 'Is it safe?',
    a: 'Yes. Cryptinity is strictly moderated. We prioritize user safety and maintain a zero-tolerance policy for harmful content.',
  },
  {
    q: 'Is it in beta?',
    a: 'Yes. We are currently in public beta. This means you may encounter bugs, but also that your feedback directly shapes the platform.',
  },
  {
    q: 'Is Cryptinity available in my country?',
    a: 'Yes. Cryptinity is available worldwide with no country restrictions. Creativity, expression, and SafeZone access are open to everyone.',
  },
];

const FAQItem = ({ question, answer }: { question: string; answer: string }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="glass rounded-[20px] overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-5 flex items-center justify-between text-left hover:bg-white/[0.02] transition-colors"
      >
        <span className="font-medium text-white pr-4">{question}</span>
        <ChevronDown
          size={18}
          className={`text-surface-400 transition-transform duration-300 flex-shrink-0 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <p className="px-5 pb-5 text-sm text-surface-400 leading-relaxed">{answer}</p>
      </div>
    </div>
  );
};

export const AboutView = () => (
  <div className="pt-24 pb-32 px-4 max-w-2xl mx-auto animate-fade-in">
    <div className="text-center mb-12">
      <div className="inline-flex items-center justify-center w-16 h-16 rounded-[20px] bg-gradient-to-br from-accent-500/20 to-teal-500/10 border border-accent-500/20 mb-6">
        <Zap size={28} className="text-accent-400 fill-accent-400" />
      </div>
      <h1 className="text-3xl font-bold text-white mb-6">About Cryptinity</h1>
      <div className="glass rounded-[24px] p-6 glow-border text-left">
        <p className="text-surface-300 leading-relaxed mb-4">
          Cryptinity is a calm social platform designed as a SafeZone —
          a place where people can create, express, and exist without pressure.
        </p>
        <p className="text-surface-400 leading-relaxed text-sm">
          There are no ranking algorithms, no engagement traps, and no manipulation.
          Content appears chronologically, and attention is respected.
        </p>
      </div>
      <div className="flex items-center justify-center gap-2 mt-6">
        <span className="badge-accent">SafeZone</span>
        <span className="badge-surface">Algorithm-Free</span>
      </div>
    </div>

    <section className="mb-10">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-[14px] bg-accent-500/10 flex items-center justify-center">
          <Target size={18} className="text-accent-400" />
        </div>
        <h2 className="text-xl font-semibold text-white">Mission</h2>
      </div>
      <div className="glass rounded-[24px] p-6 glow-border">
        <p className="text-surface-300 leading-relaxed">
          To give people a safe digital space where creativity, expression,
          and identity can exist without anxiety, comparison, or exploitation.
        </p>
      </div>
    </section>

    <section className="mb-10">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-[14px] bg-teal-500/10 flex items-center justify-center">
          <Eye size={18} className="text-teal-400" />
        </div>
        <h2 className="text-xl font-semibold text-white">Vision</h2>
      </div>
      <div className="glass rounded-[24px] p-6">
        <p className="text-surface-300 leading-relaxed">
          A world where social platforms support mental clarity
          instead of draining it, and where people feel safe to express
          what's inside — at their own pace.
        </p>
      </div>
    </section>

    <section className="mb-10">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-[14px] bg-accent-500/10 flex items-center justify-center">
          <Heart size={18} className="text-accent-400" />
        </div>
        <h2 className="text-xl font-semibold text-white">Values</h2>
      </div>
      <div className="space-y-3">
        {VALUES.map((item) => (
          <div key={item.title} className="glass rounded-[20px] p-5 flex items-center gap-4 hover:bg-surface-800/60 transition-colors">
            <div className="w-10 h-10 rounded-[14px] bg-surface-800/80 flex items-center justify-center flex-shrink-0">
              <item.icon size={18} className="text-accent-400" />
            </div>
            <div>
              <h3 className="font-medium text-white">{item.title}</h3>
              <p className="text-xs text-surface-500 mt-0.5">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>

    <section className="mb-10">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-[14px] bg-amber-500/10 flex items-center justify-center">
          <Zap size={18} className="text-amber-400" />
        </div>
        <h2 className="text-xl font-semibold text-white">What is CTY?</h2>
      </div>
      <div className="glass rounded-[24px] p-6 glow-border">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-2xl font-bold text-amber-400">CTY</span>
          <Zap size={20} className="text-amber-400 fill-amber-400" />
        </div>
        <p className="text-surface-300 leading-relaxed">
          CTY is creative energy — not money.
          It supports intentional creation and cannot be traded or sold.
        </p>
        <p className="text-surface-500 text-sm mt-3">
          Think of it as your creative fuel within Cryptinity — earned through meaningful engagement
          and spent on features that enhance your expression.
        </p>
      </div>
    </section>

    <section className="mb-10">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-[14px] bg-orange-500/10 flex items-center justify-center">
          <HelpCircle size={18} className="text-orange-400" />
        </div>
        <h2 className="text-xl font-semibold text-white">FAQ</h2>
      </div>
      <div className="space-y-3">
        {FAQ_ITEMS.map((item) => (
          <FAQItem key={item.q} question={item.q} answer={item.a} />
        ))}
      </div>
    </section>

    <section className="mb-10">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-[14px] bg-blue-500/10 flex items-center justify-center">
          <Globe size={18} className="text-blue-400" />
        </div>
        <h2 className="text-xl font-semibold text-white">Global Availability</h2>
      </div>
      <div className="glass rounded-[24px] p-6">
        <p className="text-surface-300 leading-relaxed mb-3">
          Cryptinity is available worldwide.
        </p>
        <p className="text-surface-400 leading-relaxed text-sm mb-3">
          There are no country restrictions.
        </p>
        <p className="text-surface-400 leading-relaxed text-sm">
          Creativity, expression, and SafeZone access are open to everyone.
        </p>
      </div>
    </section>

    <section className="glass rounded-[24px] p-6 text-center">
      <div className="w-12 h-12 rounded-[16px] bg-accent-500/10 flex items-center justify-center mx-auto mb-4">
        <Users size={20} className="text-accent-400" />
      </div>
      <p className="text-white font-medium mb-2">Welcome to the SafeZone</p>
      <p className="text-xs text-surface-500 max-w-sm mx-auto leading-relaxed">
        You're in a space designed for calm. Take your time. Express at your pace.
        There's no rush here.
      </p>
    </section>
  </div>
);
