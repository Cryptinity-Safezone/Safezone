import { useState, useRef } from 'react';
import { Heart, MessageCircle, Share2, Zap, Shield, Bookmark, ImagePlus, Send, X, Hash, Play, Video, Clock, AlertCircle } from 'lucide-react';
import { usePosts } from '../hooks/usePosts';
import { useAuth } from '../contexts/AuthContext';
import { useCTY } from '../hooks/useCTY';
import { PostActions } from '../components/safety/PostActions';
import { ProtectedImage } from '../components/protection';
import { MotionPlayer } from '../components/motion/MotionPlayer';
import { PostContent } from '../components/post';
import { HelpButton, AskCryptinity } from '../components/assistant';
import { CommentsModal } from '../components/comments';
import { TipModal } from '../components/tipping';
import { supabase } from '../lib/supabase';
import { storage } from '../lib/storage';
import { validateHashtagCount } from '../lib/post-parser';
import { getVideoDurationLimits } from '../lib/cty-costs';

interface PostCardProps {
  post: any;
  onLike: (postId: string) => void;
  onComment: (postId: string, postAuthor: string) => void;
  onTip: (postId: string, authorId: string, authorName: string) => void;
  onHide: (postId: string) => void;
  onReport: (postId: string, reason: string, details?: string) => void;
  onBlock: (userId: string) => void;
  isOwnPost: boolean;
}

const MAX_CONTENT_LENGTH = 280;

const PostCard = ({ post, onLike, onComment, onTip, onHide, onReport, onBlock, isOwnPost }: PostCardProps) => {
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const timeAgo = (date: string) => {
    const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
    if (seconds < 60) return 'just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  const handleViewProfile = () => {
    window.dispatchEvent(new CustomEvent('view-profile', { detail: post.user_id }));
  };

  return (
    <article className="card overflow-hidden group animate-slide-up">
      <div className="p-6 flex items-center gap-4">
        <button onClick={handleViewProfile} className="relative flex-shrink-0">
          <img
            src={post.user_profiles.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop'}
            alt={post.user_profiles.username}
            className="w-12 h-12 rounded-2xl object-cover bg-surface-800/50 ring-1 ring-white/[0.06] hover:ring-accent-500/50 transition-all"
          />
          {post.user_profiles.is_verified && (
            <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-accent-500 rounded-lg border-2 border-[#0a0a0b]" />
          )}
        </button>
        <div className="flex-1 min-w-0">
          <button onClick={handleViewProfile} className="text-left">
            <h4 className="font-medium text-white/95 truncate hover:text-accent-400 transition-colors">{post.user_profiles.username}</h4>
          </button>
          <p className="text-xs text-surface-500/70 mt-0.5">{timeAgo(post.created_at)}</p>
        </div>
        <PostActions
          postId={post.id}
          authorId={post.user_id}
          onHide={onHide}
          onReport={onReport}
          onBlock={onBlock}
        />
      </div>

      {post.content && (
        <div className="px-6 pb-5">
          {post.content.length > MAX_CONTENT_LENGTH && !isExpanded ? (
            <div className="text-[15px] text-white/85 leading-[1.7] font-normal">
              <PostContent
                content={post.content.slice(0, MAX_CONTENT_LENGTH).trim() + '...'}
                className="inline"
              />
              <button
                onClick={() => setIsExpanded(true)}
                className="ml-1 text-accent-400 hover:text-accent-300 font-medium transition-colors"
              >
                See more
              </button>
            </div>
          ) : (
            <div className="text-[15px] text-white/85 leading-[1.7] font-normal">
              <PostContent content={post.content} className="inline" />
              {post.content.length > MAX_CONTENT_LENGTH && isExpanded && (
                <button
                  onClick={() => setIsExpanded(false)}
                  className="ml-1 text-accent-400 hover:text-accent-300 font-medium transition-colors"
                >
                  Show less
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {post.is_video_post && post.video_url ? (
        <div className="relative overflow-hidden">
          <video
            src={post.video_url}
            controls
            className="w-full aspect-video bg-black"
            preload="metadata"
          />
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-black/40 backdrop-blur-sm">
            <Video size={12} className="text-accent-400" />
            <span className="text-xs text-white/90 font-medium">Short Video</span>
            {post.video_duration && (
              <span className="text-xs text-white/60">{Math.round(post.video_duration)}s</span>
            )}
          </div>
        </div>
      ) : post.is_motion_post && post.motion_url ? (
        <div className="relative overflow-hidden">
          <MotionPlayer
            videoUrl={post.motion_url}
            thumbnailUrl={post.image_url}
            duration={10}
            showWatermark
            className="w-full aspect-[4/3]"
          />
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-black/40 backdrop-blur-sm">
            <Play size={12} className="text-teal-400" fill="currentColor" />
            <span className="text-xs text-white/90 font-medium">Living Image</span>
          </div>
        </div>
      ) : post.image_url && (
        <div className="relative overflow-hidden">
          <ProtectedImage
            src={post.image_url}
            alt="Post content"
            isAIGenerated={post.is_ai_generated}
            isWatermarked={post.is_watermarked !== false}
            className="w-full aspect-[4/3] transition-transform duration-700 ease-out group-hover:scale-[1.01]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
        </div>
      )}

      <div className="p-4 flex items-center justify-between border-t border-white/[0.03]">
        <div className="flex items-center gap-0.5">
          <button
            onClick={() => onLike(post.id)}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all duration-200 ${
              post.is_liked
                ? 'text-red-400/90 bg-red-500/8'
                : 'text-surface-400/80 hover:text-red-400/80 hover:bg-red-500/5'
            }`}
          >
            <Heart
              size={18}
              className={`transition-transform duration-300 ${post.is_liked ? 'fill-current scale-105' : ''}`}
            />
            <span className="text-sm font-medium tabular-nums">{post.likes_count}</span>
          </button>

          <button
            onClick={() => onComment(post.id, post.user_profiles.username)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-surface-400/80 hover:text-white/80 hover:bg-white/[0.03] transition-all duration-200"
          >
            <MessageCircle size={18} />
            <span className="text-sm font-medium tabular-nums">{post.comments_count}</span>
          </button>

          <button className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-surface-400/80 hover:text-white/80 hover:bg-white/[0.03] transition-all duration-200">
            <Share2 size={18} />
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsBookmarked(!isBookmarked)}
            className={`w-9 h-9 flex items-center justify-center rounded-xl transition-all duration-200 ${
              isBookmarked
                ? 'text-accent-400/90 bg-accent-500/8'
                : 'text-surface-500/70 hover:text-accent-400/80 hover:bg-accent-500/5'
            }`}
          >
            <Bookmark size={17} className={isBookmarked ? 'fill-current' : ''} />
          </button>
          {!isOwnPost && (
            <button
              onClick={() => onTip(post.id, post.user_id, post.user_profiles.username)}
              className="w-9 h-9 flex items-center justify-center rounded-xl text-surface-500/70 hover:text-yellow-400/80 hover:bg-yellow-500/5 transition-all duration-200 group/tip"
            >
              <Zap size={17} className="group-hover/tip:fill-yellow-400/80 transition-all duration-200" />
            </button>
          )}
        </div>
      </div>
    </article>
  );
};

const suggestionChips = [
  { label: 'A thought', icon: '💭' },
  { label: 'A mood', icon: '🌊' },
  { label: 'An image', icon: '🖼' },
  { label: 'A video', icon: '🎬' },
];

interface CreatePostProps {
  onPost: (content: string, options?: { imageUrl?: string; videoUrl?: string; videoDuration?: number }) => void;
}

const CreatePost = ({ onPost }: CreatePostProps) => {
  const [content, setContent] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const [videoDuration, setVideoDuration] = useState<number | null>(null);
  const [videoError, setVideoError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { profile, user } = useAuth();
  const { plan } = useCTY();

  const durationLimits = getVideoDurationLimits(plan || 'free');
  const hashtagValidation = validateHashtagCount(content);

  const handleChipClick = (label: string) => {
    setIsExpanded(true);
    if (label === 'An image') {
      fileInputRef.current?.click();
    } else if (label === 'A video') {
      videoInputRef.current?.click();
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('Image must be less than 5MB');
        return;
      }
      removeVideo();
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoError(null);

      if (file.type !== 'video/mp4') {
        setVideoError('Video format not supported. Only MP4 videos are allowed.');
        return;
      }

      if (file.size > 10 * 1024 * 1024) {
        setVideoError('File size too large. Maximum size is 10MB');
        return;
      }

      if (file.size < 1024) {
        setVideoError('File too small or corrupted');
        return;
      }

      removeImage();
      setSelectedVideo(file);
      const url = URL.createObjectURL(file);
      setVideoPreview(url);
    }
  };

  const handleVideoLoadedMetadata = () => {
    if (videoRef.current) {
      const duration = videoRef.current.duration;

      if (!isFinite(duration) || duration === 0) {
        setVideoError('Could not determine video duration. Try a different video.');
        return;
      }

      setVideoDuration(duration);

      if (duration < durationLimits.min) {
        setVideoError(`Video must be at least ${durationLimits.min} seconds`);
      } else if (duration > durationLimits.max) {
        setVideoError(`Video exceeds ${durationLimits.max}s limit for your plan. Upgrade for longer videos.`);
      } else {
        setVideoError(null);
      }
    }
  };

  const handleVideoError = () => {
    setVideoError('Failed to load video. Try a different file or format.');
  };

  const removeImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeVideo = () => {
    if (videoPreview) {
      URL.revokeObjectURL(videoPreview);
    }
    setSelectedVideo(null);
    setVideoPreview(null);
    setVideoDuration(null);
    setVideoError(null);
    if (videoInputRef.current) {
      videoInputRef.current.value = '';
    }
  };

  const handleSubmit = async () => {
    if (!content.trim() && !selectedImage && !selectedVideo) return;
    if (videoError) return;

    try {
      setUploading(true);
      let imageUrl: string | undefined;
      let videoUrl: string | undefined;

      if (selectedImage && user) {
        try {
          const result = await storage.uploadFile('posts', user.id, selectedImage);
          imageUrl = result.url;
        } catch (err: any) {
          console.error('Image upload failed:', err);
          throw new Error(`Image upload failed: ${err.message}`);
        }
      }

      if (selectedVideo && user && videoDuration) {
        try {
          const { data: sessionData } = await supabase.auth.getSession();
          const accessToken = sessionData.session?.access_token;
          if (!accessToken) {
            throw new Error('Not authenticated');
          }

          const formData = new FormData();
          formData.append('file', selectedVideo);
          formData.append('duration', videoDuration.toString());

          const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
          const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
          const response = await fetch(`${supabaseUrl}/functions/v1/video-upload`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'apikey': supabaseKey,
            },
            body: formData,
          });

          const result = await response.json();

          if (!response.ok) {
            throw new Error(result.error || 'Video upload failed');
          }

          videoUrl = result.url;
        } catch (err: any) {
          console.error('Video upload failed:', err);
          throw new Error(err.message || 'Video upload failed');
        }
      }

      try {
        await onPost(content, {
          imageUrl,
          videoUrl,
          videoDuration: videoDuration || undefined,
        });
      } catch (err: any) {
        console.error('Post creation failed:', err);
        throw new Error(`Post creation failed: ${err.message}`);
      }

      setContent('');
      removeImage();
      removeVideo();
      setIsExpanded(false);
    } catch (error: any) {
      console.error('Failed to create post:', error);
      const errorMessage = error.message || 'Failed to create post. Please try again.';
      alert(errorMessage);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="mb-6 card p-6 animate-fade-in">
      <div className="flex items-start gap-4">
        <img
          src={profile?.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop'}
          alt="Your avatar"
          className="w-11 h-11 rounded-2xl object-cover bg-surface-800/50 ring-1 ring-white/[0.06]"
        />
        <div className="flex-1">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onFocus={() => setIsExpanded(true)}
            placeholder="Share your thoughts..."
            className="w-full bg-transparent text-white/90 placeholder-surface-600/60 resize-none outline-none text-[15px] leading-[1.7]"
            rows={isExpanded ? 3 : 1}
          />
          {!isExpanded && !content && (
            <div className="mt-4">
              <p className="text-sm text-surface-500/80 leading-relaxed mb-3">
                What's on your mind today?<br />
                <span className="text-surface-600/70">A thought, an image, a feeling, or nothing at all — it's your choice.</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {suggestionChips.map((chip) => (
                  <button
                    key={chip.label}
                    onClick={() => handleChipClick(chip.label)}
                    className="px-3 py-1.5 text-xs text-surface-400/80 bg-white/[0.02] border border-white/[0.06] rounded-full hover:bg-white/[0.04] hover:border-white/[0.1] hover:text-surface-300 transition-all duration-200 flex items-center gap-1.5"
                  >
                    <span>{chip.icon}</span>
                    <span>{chip.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
          {imagePreview && (
            <div className="relative mt-4 rounded-xl overflow-hidden">
              <img src={imagePreview} alt="Preview" className="w-full max-h-80 object-cover" />
              <button
                onClick={removeImage}
                className="absolute top-2 right-2 w-8 h-8 bg-black/60 hover:bg-black/80 rounded-full flex items-center justify-center text-white transition-colors"
              >
                <X size={16} />
              </button>
            </div>
          )}
          {videoPreview && (
            <div className="relative mt-4 rounded-xl overflow-hidden">
              <video
                ref={videoRef}
                src={videoPreview}
                className="w-full max-h-80 object-cover"
                onLoadedMetadata={handleVideoLoadedMetadata}
                onError={handleVideoError}
                controls
              />
              <button
                onClick={removeVideo}
                className="absolute top-2 right-2 w-8 h-8 bg-black/60 hover:bg-black/80 rounded-full flex items-center justify-center text-white transition-colors"
              >
                <X size={16} />
              </button>
              {videoDuration ? (
                <div className="absolute bottom-2 left-2 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-black/60 backdrop-blur-sm">
                  <Clock size={12} className="text-white/80" />
                  <span className="text-xs text-white/90">{Math.round(videoDuration)}s</span>
                  <span className="text-xs text-surface-400">/ {durationLimits.max}s max</span>
                </div>
              ) : (
                <div className="absolute bottom-2 left-2 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-black/60 backdrop-blur-sm">
                  <div className="w-3 h-3 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                  <span className="text-xs text-white/70">Loading video...</span>
                </div>
              )}
            </div>
          )}
          {videoError && (
            <div className="mt-3 flex items-center gap-2 px-3 py-2 bg-red-500/10 border border-red-500/20 rounded-xl">
              <AlertCircle size={14} className="text-red-400" />
              <span className="text-xs text-red-400">{videoError}</span>
            </div>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
          />
          <input
            ref={videoInputRef}
            type="file"
            accept="video/mp4"
            onChange={handleVideoSelect}
            className="hidden"
          />
          {isExpanded && (
            <div className="flex items-center justify-between mt-5 pt-5 border-t border-white/[0.04]">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className={`w-9 h-9 flex items-center justify-center rounded-xl transition-all duration-200 ${
                    selectedImage
                      ? 'text-accent-400 bg-accent-500/10'
                      : 'text-surface-500/70 hover:text-accent-400/80 hover:bg-accent-500/8'
                  }`}
                  disabled={uploading || !!selectedVideo}
                  title="Add image"
                >
                  <ImagePlus size={18} />
                </button>
                <button
                  onClick={() => videoInputRef.current?.click()}
                  className={`w-9 h-9 flex items-center justify-center rounded-xl transition-all duration-200 ${
                    selectedVideo
                      ? 'text-accent-400 bg-accent-500/10'
                      : 'text-surface-500/70 hover:text-accent-400/80 hover:bg-accent-500/8'
                  }`}
                  disabled={uploading || !!selectedImage}
                  title={`Add video (${durationLimits.min}-${durationLimits.max}s)`}
                >
                  <Video size={18} />
                </button>
                {hashtagValidation.count > 0 && (
                  <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs ${
                    hashtagValidation.valid
                      ? 'bg-accent-500/10 text-accent-400'
                      : 'bg-red-500/10 text-red-400'
                  }`}>
                    <Hash size={12} />
                    <span>{hashtagValidation.count}/5</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setIsExpanded(false);
                    setContent('');
                    removeImage();
                    removeVideo();
                  }}
                  className="px-4 py-2 text-sm text-surface-400/80 hover:text-white/80 transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={
                    (!content.trim() && !selectedImage && !selectedVideo) ||
                    uploading ||
                    !hashtagValidation.valid ||
                    !!videoError ||
                    (!!selectedVideo && !videoDuration)
                  }
                  className="px-5 py-2.5 bg-gradient-to-r from-accent-500/90 to-teal-600/90 text-white text-sm font-medium rounded-xl hover:from-accent-500 hover:to-teal-600 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2 shadow-lg shadow-accent-500/10"
                >
                  {uploading ? (
                    <>Posting...</>
                  ) : (
                    <>
                      <Send size={16} />
                      Post
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const FeedView = () => {
  const { posts, loading, toggleLike, createPost, refresh } = usePosts();
  const { user } = useAuth();
  const [showAssistant, setShowAssistant] = useState(false);
  const [assistantQuestion, setAssistantQuestion] = useState<string>();
  const [commentsModal, setCommentsModal] = useState<{ postId: string; postAuthor: string } | null>(null);
  const [tipModal, setTipModal] = useState<{ postId: string; authorId: string; authorName: string } | null>(null);

  const openAssistant = (question?: string) => {
    setAssistantQuestion(question);
    setShowAssistant(true);
  };

  const handleOpenComments = (postId: string, postAuthor: string) => {
    setCommentsModal({ postId, postAuthor });
  };

  const handleOpenTip = (postId: string, authorId: string, authorName: string) => {
    setTipModal({ postId, authorId, authorName });
  };

  const handleCreatePost = async (
    content: string,
    options?: { imageUrl?: string; videoUrl?: string; videoDuration?: number }
  ) => {
    try {
      await createPost(content, options);
    } catch (error) {
      console.error('Failed to create post:', error);
    }
  };

  const handleLike = async (postId: string) => {
    try {
      await toggleLike(postId);
    } catch (error) {
      console.error('Failed to toggle like:', error);
    }
  };

  const handleHide = async (postId: string) => {
    try {
      await supabase.from('hidden_posts').insert({
        user_id: user?.id,
        post_id: postId,
      });
      await refresh();
    } catch (error) {
      console.error('Failed to hide post:', error);
    }
  };

  const handleReport = async (postId: string, reason: string, details?: string) => {
    try {
      await supabase.from('post_reports').insert({
        reporter_id: user?.id,
        post_id: postId,
        reason,
        details: details || null,
      });
    } catch (error) {
      console.error('Failed to report post:', error);
    }
  };

  const handleBlock = async (userId: string) => {
    try {
      await supabase.from('user_blocks').insert({
        blocker_id: user?.id,
        blocked_id: userId,
      });
      await refresh();
    } catch (error) {
      console.error('Failed to block user:', error);
    }
  };

  return (
    <div className="pt-24 pb-32 px-4 max-w-lg mx-auto">
      <AskCryptinity
        isOpen={showAssistant}
        onClose={() => {
          setShowAssistant(false);
          setAssistantQuestion(undefined);
        }}
        initialQuestion={assistantQuestion}
      />
      {commentsModal && (
        <CommentsModal
          isOpen={true}
          onClose={() => setCommentsModal(null)}
          postId={commentsModal.postId}
          postAuthor={commentsModal.postAuthor}
        />
      )}
      {tipModal && (
        <TipModal
          isOpen={true}
          onClose={() => setTipModal(null)}
          recipientId={tipModal.authorId}
          recipientName={tipModal.authorName}
          postId={tipModal.postId}
        />
      )}
      <div className="mb-8 p-5 rounded-2xl flex items-start gap-4 animate-fade-in border border-accent-500/10 bg-gradient-to-br from-accent-500/5 via-transparent to-teal-500/5 backdrop-blur-xl">
        <div className="w-9 h-9 rounded-xl bg-accent-500/10 flex items-center justify-center flex-shrink-0 border border-accent-500/10">
          <Shield className="text-accent-400/80" size={16} />
        </div>
        <div className="pt-0.5 flex-1">
          <p className="text-sm text-white/70 leading-[1.7] font-light">
            <span className="text-accent-400/90 font-medium">SafeZone Active</span> — Algorithm-free feed.
            Content appears chronologically. Care for your inner time.
          </p>
        </div>
        <HelpButton
          question="What is SafeZone?"
          onClick={openAssistant}
        />
      </div>

      <CreatePost onPost={handleCreatePost} />

      {loading ? (
        <div className="text-center py-24">
          <div className="w-16 h-16 rounded-3xl bg-white/[0.02] border border-white/[0.04] flex items-center justify-center mx-auto mb-6">
            <Zap size={26} className="text-surface-600/60 animate-pulse" style={{ animationDuration: '2s' }} />
          </div>
          <p className="text-sm text-surface-600/70 font-light">Loading feed...</p>
        </div>
      ) : posts.length === 0 ? (
        <div className="text-center py-24">
          <div className="w-16 h-16 rounded-3xl bg-white/[0.02] border border-white/[0.04] flex items-center justify-center mx-auto mb-6">
            <Zap size={26} className="text-surface-600/60" />
          </div>
          <h3 className="text-lg font-medium text-surface-400/80 mb-2">This space is quiet for now.</h3>
          <p className="text-sm text-surface-600/70 font-light">Share something when it feels right. There's no rush here.</p>
        </div>
      ) : (
        <div className="space-y-5">
          {posts.map((post, index) => (
            <div key={post.id} style={{ animationDelay: `${index * 80}ms` }}>
              <PostCard
                post={post}
                onLike={handleLike}
                onComment={handleOpenComments}
                onTip={handleOpenTip}
                onHide={handleHide}
                onReport={handleReport}
                onBlock={handleBlock}
                isOwnPost={post.user_id === user?.id}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
