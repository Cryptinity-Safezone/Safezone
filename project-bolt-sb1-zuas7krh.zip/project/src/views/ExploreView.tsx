import { useState, useEffect } from 'react';
import { Search, Hash, ChevronRight, Heart, Users, Sparkles, ArrowLeft, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { PostContent } from '../components/post';
import { ProtectedImage } from '../components/protection';

interface Hashtag {
  id: string;
  name: string;
  post_count: number;
}

interface HashtagPost {
  id: string;
  content: string;
  image_url: string | null;
  likes_count: number;
  created_at: string;
  user_profiles: {
    username: string;
    avatar_url: string | null;
    handle: string;
  };
}

interface SearchUser {
  id: string;
  username: string;
  handle: string;
  avatar_url: string | null;
  is_verified: boolean;
  followers_count: number;
}

const FEATURED_CREATORS = [
  {
    name: 'Alex Rivers',
    handle: '@alexrivers',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop',
    followers: '24.5K',
    verified: true,
  },
  {
    name: 'Maya Chen',
    handle: '@mayachen',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop',
    followers: '18.2K',
    verified: true,
  },
  {
    name: 'Jordan West',
    handle: '@jwest',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop',
    followers: '15.8K',
    verified: false,
  },
];

const DISCOVER_IMAGES = [
  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1618172193622-ae2d025f4032?w=600&auto=format&fit=crop',
];

export const ExploreView = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [hashtags, setHashtags] = useState<Hashtag[]>([]);
  const [selectedHashtag, setSelectedHashtag] = useState<string | null>(null);
  const [hashtagPosts, setHashtagPosts] = useState<HashtagPost[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchUsers, setSearchUsers] = useState<SearchUser[]>([]);
  const [searchingUsers, setSearchingUsers] = useState(false);

  useEffect(() => {
    fetchHashtags();

    const handleHashtagNav = (e: CustomEvent<string>) => {
      setSelectedHashtag(e.detail);
    };

    window.addEventListener('navigate-hashtag', handleHashtagNav as EventListener);
    return () => {
      window.removeEventListener('navigate-hashtag', handleHashtagNav as EventListener);
    };
  }, []);

  useEffect(() => {
    if (selectedHashtag) {
      fetchHashtagPosts(selectedHashtag);
    }
  }, [selectedHashtag]);

  useEffect(() => {
    const searchTimeout = setTimeout(() => {
      if (searchQuery.trim().length >= 2) {
        searchForUsers(searchQuery.trim());
      } else {
        setSearchUsers([]);
      }
    }, 300);
    return () => clearTimeout(searchTimeout);
  }, [searchQuery]);

  const searchForUsers = async (query: string) => {
    setSearchingUsers(true);
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('id, username, handle, avatar_url, is_verified, followers_count')
        .or(`username.ilike.%${query}%,handle.ilike.%${query}%`)
        .limit(10);

      if (error) throw error;
      setSearchUsers(data || []);
    } catch (err) {
      console.error('Error searching users:', err);
      setSearchUsers([]);
    } finally {
      setSearchingUsers(false);
    }
  };

  const handleViewProfile = (userId: string) => {
    window.dispatchEvent(new CustomEvent('view-profile', { detail: userId }));
  };

  const fetchHashtags = async () => {
    const { data } = await supabase
      .from('hashtags')
      .select('*')
      .order('post_count', { ascending: false })
      .limit(8);

    if (data) {
      setHashtags(data);
    }
  };

  const fetchHashtagPosts = async (tag: string) => {
    setLoading(true);
    const { data: hashtagData } = await supabase
      .from('hashtags')
      .select('id')
      .eq('name', tag)
      .maybeSingle();

    if (!hashtagData) {
      setHashtagPosts([]);
      setLoading(false);
      return;
    }

    const { data: postHashtags } = await supabase
      .from('post_hashtags')
      .select('post_id')
      .eq('hashtag_id', hashtagData.id);

    if (!postHashtags || postHashtags.length === 0) {
      setHashtagPosts([]);
      setLoading(false);
      return;
    }

    const postIds = postHashtags.map(ph => ph.post_id);
    const { data: posts } = await supabase
      .from('posts')
      .select(`
        id, content, image_url, likes_count, created_at,
        user_profiles!inner(username, avatar_url, handle)
      `)
      .in('id', postIds)
      .order('created_at', { ascending: false });

    setHashtagPosts(posts || []);
    setLoading(false);
  };

  const filteredHashtags = searchQuery
    ? hashtags.filter(h => h.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : hashtags;

  const timeAgo = (date: string) => {
    const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
    if (seconds < 60) return 'just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    return `${Math.floor(seconds / 86400)}d`;
  };

  if (selectedHashtag) {
    return (
      <div className="pt-24 pb-32 px-4 max-w-2xl mx-auto animate-fade-in">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => setSelectedHashtag(null)}
            className="w-10 h-10 rounded-xl bg-surface-800/50 border border-white/[0.06] flex items-center justify-center text-surface-400 hover:text-white hover:bg-surface-700/50 transition-all"
          >
            <ArrowLeft size={18} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-accent-500/10 flex items-center justify-center">
              <Hash size={18} className="text-accent-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">#{selectedHashtag}</h1>
              <p className="text-sm text-surface-500">{hashtagPosts.length} posts</p>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center py-16">
            <div className="w-12 h-12 rounded-2xl bg-surface-800/50 border border-white/[0.06] flex items-center justify-center mb-4">
              <div className="w-5 h-5 border-2 border-accent-400/30 border-t-accent-400 rounded-full animate-spin" />
            </div>
            <p className="text-sm text-surface-500">Loading posts...</p>
          </div>
        ) : hashtagPosts.length === 0 ? (
          <div className="flex flex-col items-center py-16">
            <div className="w-16 h-16 rounded-2xl bg-surface-800/50 border border-white/[0.06] flex items-center justify-center mb-4">
              <Hash size={28} className="text-surface-600" />
            </div>
            <h3 className="text-lg font-medium text-surface-400 mb-2">No posts yet</h3>
            <p className="text-sm text-surface-600">Be the first to use #{selectedHashtag}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {hashtagPosts.map((post) => (
              <article key={post.id} className="card overflow-hidden">
                <div className="p-4 flex items-center gap-3">
                  <img
                    src={post.user_profiles.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200'}
                    alt={post.user_profiles.username}
                    className="w-10 h-10 rounded-xl object-cover bg-surface-800"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium text-white truncate">
                      {post.user_profiles.username}
                    </h4>
                    <p className="text-xs text-surface-500">@{post.user_profiles.handle}</p>
                  </div>
                  <span className="text-xs text-surface-600">{timeAgo(post.created_at)}</span>
                </div>

                {post.content && (
                  <div className="px-4 pb-4">
                    <PostContent
                      content={post.content}
                      onHashtagClick={(tag) => setSelectedHashtag(tag)}
                      className="text-sm text-white/85 leading-relaxed"
                    />
                  </div>
                )}

                {post.image_url && (
                  <ProtectedImage
                    src={post.image_url}
                    alt="Post"
                    className="w-full aspect-[4/3]"
                  />
                )}

                <div className="p-4 border-t border-white/[0.04] flex items-center gap-4">
                  <div className="flex items-center gap-1.5 text-surface-400">
                    <Heart size={16} />
                    <span className="text-sm">{post.likes_count}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="pt-24 pb-32 px-4 max-w-2xl mx-auto animate-fade-in">
      <div className="relative mb-8">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
          <Search size={18} className="text-surface-500" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search users, hashtags..."
          className="input-field pl-12 pr-4"
        />
      </div>

      {searchQuery.trim().length >= 2 && (
        <section className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-9 h-9 rounded-xl bg-teal-500/10 flex items-center justify-center">
              <Users size={16} className="text-teal-400" />
            </div>
            <h2 className="text-lg font-semibold text-white">Users</h2>
          </div>
          {searchingUsers ? (
            <div className="glass rounded-2xl p-8 text-center">
              <div className="w-8 h-8 border-2 border-teal-400/30 border-t-teal-400 rounded-full animate-spin mx-auto mb-3" />
              <p className="text-sm text-surface-500">Searching...</p>
            </div>
          ) : searchUsers.length === 0 ? (
            <div className="glass rounded-2xl p-8 text-center">
              <Users size={24} className="text-surface-600 mx-auto mb-3" />
              <p className="text-sm text-surface-500">No users found</p>
              <p className="text-xs text-surface-600 mt-1">Try a different search term</p>
            </div>
          ) : (
            <div className="space-y-3">
              {searchUsers.map((searchUser) => (
                <button
                  key={searchUser.id}
                  onClick={() => handleViewProfile(searchUser.id)}
                  className="w-full glass rounded-2xl p-4 flex items-center gap-4 hover:bg-surface-800/60 transition-all text-left"
                >
                  <div className="relative">
                    <img
                      src={searchUser.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200'}
                      alt={searchUser.username}
                      className="w-12 h-12 rounded-2xl object-cover bg-surface-800"
                    />
                    {searchUser.is_verified && (
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-teal-500 rounded-lg flex items-center justify-center border-2 border-surface-900">
                        <Check size={10} className="text-white" strokeWidth={3} />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-white truncate">{searchUser.username}</h4>
                    <p className="text-sm text-surface-500">@{searchUser.handle}</p>
                  </div>
                  <div className="flex items-center gap-1 text-surface-400">
                    <Users size={14} />
                    <span className="text-sm">{searchUser.followers_count.toLocaleString()}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>
      )}

      <section className="mb-10">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-accent-500/10 flex items-center justify-center">
              <Hash size={16} className="text-accent-400" />
            </div>
            <h2 className="text-lg font-semibold text-white">Browse Hashtags</h2>
          </div>
        </div>

        {filteredHashtags.length === 0 ? (
          <div className="glass rounded-2xl p-8 text-center">
            <Hash size={24} className="text-surface-600 mx-auto mb-3" />
            <p className="text-sm text-surface-500">No hashtags found</p>
            <p className="text-xs text-surface-600 mt-1">Create a post with hashtags to get started</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filteredHashtags.map((hashtag) => (
              <button
                key={hashtag.id}
                onClick={() => setSelectedHashtag(hashtag.name)}
                className="glass rounded-2xl p-4 text-left hover:bg-surface-800/60 transition-all group"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Hash size={14} className="text-accent-400" />
                  <span className="text-white font-medium group-hover:text-accent-400 transition-colors truncate">
                    {hashtag.name}
                  </span>
                </div>
                <span className="text-xs text-surface-500">
                  {hashtag.post_count.toLocaleString()} {hashtag.post_count === 1 ? 'post' : 'posts'}
                </span>
              </button>
            ))}
          </div>
        )}
      </section>

      <section className="mb-10">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-500/10 flex items-center justify-center">
              <Sparkles size={16} className="text-teal-400" />
            </div>
            <h2 className="text-lg font-semibold text-white">Featured Creators</h2>
          </div>
          <button className="flex items-center gap-1 text-sm text-surface-400 hover:text-white transition-colors">
            See all <ChevronRight size={16} />
          </button>
        </div>
        <div className="space-y-3">
          {FEATURED_CREATORS.map((creator) => (
            <div
              key={creator.handle}
              className="glass rounded-2xl p-4 flex items-center gap-4 hover:bg-surface-800/60 transition-all cursor-pointer group"
            >
              <div className="relative">
                <img
                  src={creator.avatar}
                  alt={creator.name}
                  className="w-12 h-12 rounded-2xl object-cover bg-surface-800"
                />
                {creator.verified && (
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-accent-500 rounded-lg flex items-center justify-center border-2 border-surface-900">
                    <svg viewBox="0 0 24 24" className="w-3 h-3 text-white fill-current">
                      <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                    </svg>
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-white truncate group-hover:text-accent-400 transition-colors">
                  {creator.name}
                </h4>
                <p className="text-sm text-surface-500">{creator.handle}</p>
              </div>
              <div className="flex items-center gap-1 text-surface-400">
                <Users size={14} />
                <span className="text-sm">{creator.followers}</span>
              </div>
              <button className="px-4 py-2 bg-accent-500/10 text-accent-400 text-sm font-medium rounded-xl hover:bg-accent-500 hover:text-white transition-all">
                Follow
              </button>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center gap-3 mb-5">
          <div className="w-9 h-9 rounded-xl bg-rose-500/10 flex items-center justify-center">
            <Heart size={16} className="text-rose-400" />
          </div>
          <h2 className="text-lg font-semibold text-white">Discover</h2>
        </div>
        {DISCOVER_IMAGES.length === 0 ? (
          <div className="flex flex-col items-center text-center py-12">
            <div className="w-16 h-16 rounded-2xl bg-surface-900/40 border border-white/5 flex items-center justify-center mb-4">
              <Heart size={28} className="text-surface-600" />
            </div>
            <h3 className="text-lg font-medium text-surface-400 mb-2">Nothing new at the moment.</h3>
            <p className="text-sm text-surface-600 max-w-xs">Calm spaces grow naturally as people create.</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            {DISCOVER_IMAGES.map((src, i) => (
              <div
                key={i}
                className={`relative overflow-hidden rounded-2xl cursor-pointer group ${
                  i === 0 ? 'row-span-2 col-span-2' : ''
                }`}
              >
                <img
                  src={src}
                  alt="Discover"
                  className="w-full h-full object-cover aspect-square transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-3 left-3 right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Heart size={14} className="text-white" />
                  <span className="text-xs text-white font-medium">{Math.floor(Math.random() * 5000)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
