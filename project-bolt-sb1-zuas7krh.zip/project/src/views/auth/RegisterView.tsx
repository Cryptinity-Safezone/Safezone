import { useState } from 'react';
import { Shield, Zap, ArrowLeft, Check } from 'lucide-react';
import {
  AuthLayout,
  GlassCard,
  GlassInput,
  PrimaryButton,
  SecondaryLink,
} from '../../components/auth';
import { useAuth } from '../../contexts/AuthContext';

type AuthView = 'login' | 'register' | 'forgot';

interface RegisterViewProps {
  onNavigate: (view: AuthView) => void;
}

const PasswordStrength = ({ password }: { password: string }) => {
  const checks = [
    { label: '6+ characters', met: password.length >= 6 },
    { label: 'Uppercase letter', met: /[A-Z]/.test(password) },
    { label: 'Number', met: /[0-9]/.test(password) },
  ];

  const strength = checks.filter((c) => c.met).length;

  return (
    <div className="mt-3 space-y-2">
      <div className="flex gap-1.5">
        {[1, 2, 3].map((level) => (
          <div
            key={level}
            className={`h-1 flex-1 rounded-full transition-all duration-300 ${
              strength >= level
                ? level === 1
                  ? 'bg-red-400'
                  : level === 2
                  ? 'bg-yellow-400'
                  : 'bg-accent-400'
                : 'bg-surface-800'
            }`}
          />
        ))}
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1">
        {checks.map((check) => (
          <div key={check.label} className="flex items-center gap-1.5">
            <div
              className={`w-3.5 h-3.5 rounded flex items-center justify-center transition-colors ${
                check.met ? 'bg-accent-500/20' : 'bg-surface-800'
              }`}
            >
              {check.met && <Check size={10} className="text-accent-400" />}
            </div>
            <span
              className={`text-[11px] transition-colors ${
                check.met ? 'text-surface-300' : 'text-surface-600'
              }`}
            >
              {check.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export const RegisterView = ({ onNavigate }: RegisterViewProps) => {
  const { signUp } = useAuth();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!username) {
      newErrors.username = 'Username is required';
    } else if (username.length < 3) {
      newErrors.username = 'Username must be at least 3 characters';
    }

    if (!email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!password) {
      newErrors.password = 'Password is required';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (password !== confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setLoading(true);
    setErrors({});

    try {
      const handle = `@${username.toLowerCase().replace(/\s+/g, '')}`;
      await signUp(email, password, username, handle);
    } catch (error: any) {
      console.error('Registration error:', error);
      setErrors({
        general: error.message || 'Registration failed. Please try again.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout>
      <GlassCard>
        <form onSubmit={handleSubmit} className="p-8">
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="flex items-center gap-2 text-surface-500 hover:text-white text-sm font-medium transition-colors mb-6"
          >
            <ArrowLeft size={16} />
            Back to Login
          </button>

          <div className="text-center mb-8">
            <h2 className="text-xl font-semibold text-white mb-2">Create Account</h2>
            <p className="text-sm text-surface-500">Join the SafeZone community</p>
          </div>

          {errors.general && (
            <div className="mb-5 p-4 rounded-2xl bg-red-500/10 border border-red-500/20">
              <p className="text-sm text-red-400 text-center">{errors.general}</p>
            </div>
          )}

          <div className="space-y-5">
            <GlassInput
              label="Username"
              type="text"
              value={username}
              onChange={setUsername}
              error={errors.username}
              autoComplete="username"
            />

            <GlassInput
              label="Email Address"
              type="email"
              value={email}
              onChange={setEmail}
              error={errors.email}
              autoComplete="email"
            />

            <div>
              <GlassInput
                label="Password"
                type="password"
                value={password}
                onChange={setPassword}
                error={errors.password}
                autoComplete="new-password"
              />
              {password && <PasswordStrength password={password} />}
            </div>

            <GlassInput
              label="Confirm Password"
              type="password"
              value={confirmPassword}
              onChange={setConfirmPassword}
              error={errors.confirmPassword}
              autoComplete="new-password"
            />
          </div>

          <div className="mt-8">
            <PrimaryButton type="submit" loading={loading}>
              Create SafeZone Account
            </PrimaryButton>
          </div>

          <div className="text-center mt-6">
            <span className="text-surface-500 text-sm">Already have an account? </span>
            <SecondaryLink highlight onClick={() => onNavigate('login')}>
              Sign In
            </SecondaryLink>
          </div>
        </form>

        <div className="px-8 pb-6">
          <div className="p-4 rounded-2xl bg-surface-950/50 border border-white/[0.04]">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-accent-500/10 flex items-center justify-center flex-shrink-0">
                <Shield size={14} className="text-accent-400" />
              </div>
              <div>
                <p className="text-xs text-surface-400 leading-relaxed">
                  <span className="text-accent-400 font-medium">Your safety matters.</span>
                  <br />
                  We never sell your data or manipulate your feed.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-8 pb-8">
          <div className="flex items-center justify-center gap-1.5 text-[10px] text-surface-600">
            <Zap size={10} className="text-surface-600" />
            <span>CTY is an internal utility with no real-world value.</span>
          </div>
        </div>
      </GlassCard>
    </AuthLayout>
  );
};
