import { useState } from 'react';
import { ArrowLeft, Mail, CheckCircle } from 'lucide-react';
import {
  AuthLayout,
  GlassCard,
  GlassInput,
  PrimaryButton,
  SecondaryLink,
} from '../../components/auth';
import { useAuth } from '../../contexts/AuthContext';

type AuthView = 'login' | 'register' | 'forgot';

interface ForgotPasswordViewProps {
  onNavigate: (view: AuthView) => void;
}

export const ForgotPasswordView = ({ onNavigate }: ForgotPasswordViewProps) => {
  const { resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email) {
      setError('Email is required');
      return;
    }

    if (!/\S+@\S+\.\S+/.test(email)) {
      setError('Please enter a valid email');
      return;
    }

    setError('');
    setLoading(true);

    try {
      await resetPassword(email);
      setSent(true);
    } catch (error: any) {
      console.error('Reset password error:', error);
      setError(error.message || 'Failed to send reset email. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (sent) {
    return (
      <AuthLayout>
        <GlassCard>
          <div className="p-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-[20px] bg-accent-500/10 border border-accent-500/20 mb-6">
              <CheckCircle size={28} className="text-accent-400" />
            </div>

            <h2 className="text-xl font-semibold text-white mb-3">Check Your Email</h2>
            <p className="text-sm text-surface-400 leading-relaxed mb-8 max-w-xs mx-auto">
              We've sent password reset instructions to{' '}
              <span className="text-white font-medium">{email}</span>
            </p>

            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-surface-950/50 border border-white/[0.04]">
                <p className="text-xs text-surface-500 leading-relaxed">
                  Didn't receive the email? Check your spam folder or{' '}
                  <button
                    onClick={() => setSent(false)}
                    className="text-accent-400 hover:underline underline-offset-2"
                  >
                    try again
                  </button>
                </p>
              </div>

              <button
                onClick={() => onNavigate('login')}
                className="w-full py-3.5 px-6 bg-surface-800/50 border border-white/[0.08] text-surface-300 font-medium text-sm rounded-2xl transition-all hover:bg-surface-800/70 hover:text-white"
              >
                Back to Login
              </button>
            </div>
          </div>
        </GlassCard>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout>
      <GlassCard>
        <form onSubmit={handleSubmit} className="p-8">
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="flex items-center gap-2 text-surface-500 hover:text-white text-sm font-medium transition-colors mb-6"
          >
            <ArrowLeft size={16} />
            Back to Login
          </button>

          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-[18px] bg-surface-800/60 border border-white/[0.06] mb-5">
              <Mail size={24} className="text-surface-400" />
            </div>
            <h2 className="text-xl font-semibold text-white mb-2">Reset Password</h2>
            <p className="text-sm text-surface-500 max-w-xs mx-auto">
              Enter your email address and we'll send you instructions to reset your password
            </p>
          </div>

          <div className="space-y-5">
            <GlassInput
              label="Email Address"
              type="email"
              value={email}
              onChange={(val) => {
                setEmail(val);
                setError('');
              }}
              error={error}
              autoComplete="email"
            />
          </div>

          <div className="mt-8">
            <PrimaryButton type="submit" loading={loading}>
              Send Reset Instructions
            </PrimaryButton>
          </div>

          <div className="text-center mt-6">
            <span className="text-surface-500 text-sm">Remember your password? </span>
            <SecondaryLink highlight onClick={() => onNavigate('login')}>
              Sign In
            </SecondaryLink>
          </div>
        </form>
      </GlassCard>
    </AuthLayout>
  );
};
