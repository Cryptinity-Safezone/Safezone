import { useState } from 'react';
import { Shield, Zap } from 'lucide-react';
import {
  AuthLayout,
  GlassCard,
  GlassInput,
  PrimaryButton,
  SecondaryButton,
  SecondaryLink,
  Divider,
} from '../../components/auth';
import { useAuth } from '../../contexts/AuthContext';

type AuthView = 'login' | 'register' | 'forgot';

interface LoginViewProps {
  onNavigate: (view: AuthView) => void;
}

export const LoginView = ({ onNavigate }: LoginViewProps) => {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string; general?: string }>({});

  const validateForm = () => {
    const newErrors: { email?: string; password?: string } = {};

    if (!email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!password) {
      newErrors.password = 'Password is required';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setLoading(true);
    setErrors({});

    try {
      await signIn(email, password);
    } catch (error: any) {
      console.error('Login error:', error);
      setErrors({
        general: error.message || 'Invalid email or password. Please try again.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGuestContinue = () => {
    onNavigate('register');
  };

  return (
    <AuthLayout>
      <GlassCard>
        <form onSubmit={handleSubmit} className="p-8">
          <div className="text-center mb-8">
            <h2 className="text-xl font-semibold text-white mb-2">Welcome Back</h2>
            <p className="text-sm text-surface-500">Enter your credentials to access SafeZone</p>
          </div>

          {errors.general && (
            <div className="mb-5 p-4 rounded-2xl bg-red-500/10 border border-red-500/20">
              <p className="text-sm text-red-400 text-center">{errors.general}</p>
            </div>
          )}

          <div className="space-y-5">
            <GlassInput
              label="Email Address"
              type="email"
              value={email}
              onChange={setEmail}
              error={errors.email}
              autoComplete="email"
            />

            <GlassInput
              label="Password"
              type="password"
              value={password}
              onChange={setPassword}
              error={errors.password}
              autoComplete="current-password"
            />
          </div>

          <div className="flex justify-end mt-3">
            <SecondaryLink onClick={() => onNavigate('forgot')}>
              Forgot Password?
            </SecondaryLink>
          </div>

          <div className="mt-8">
            <PrimaryButton type="submit" loading={loading}>
              Enter SafeZone
            </PrimaryButton>
          </div>

          <Divider text="or" />

          <SecondaryButton onClick={handleGuestContinue}>
            Continue as Guest
          </SecondaryButton>

          <div className="text-center mt-6">
            <span className="text-surface-500 text-sm">Don't have an account? </span>
            <SecondaryLink highlight onClick={() => onNavigate('register')}>
              Create Account
            </SecondaryLink>
          </div>
        </form>

        <div className="px-8 pb-6">
          <div className="p-4 rounded-2xl bg-surface-950/50 border border-white/[0.04]">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-accent-500/10 flex items-center justify-center flex-shrink-0">
                <Shield size={14} className="text-accent-400" />
              </div>
              <div>
                <p className="text-xs text-surface-400 leading-relaxed">
                  <span className="text-accent-400 font-medium">Cryptinity is a SafeZone platform.</span>
                  <br />
                  No algorithms. No manipulation. No exploitation.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-8 pb-8">
          <div className="flex items-center justify-center gap-1.5 text-[10px] text-surface-600">
            <Zap size={10} className="text-surface-600" />
            <span>CTY is an internal utility with no real-world value.</span>
          </div>
        </div>
      </GlassCard>
    </AuthLayout>
  );
};
