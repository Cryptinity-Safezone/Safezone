import { useState } from 'react';
import {
  Sparkles,
  Coins,
  Shield,
  ShoppingBag,
  Users,
  Lock,
  ChevronRight,
  MessageCircle,
  Globe,
} from 'lucide-react';
import { AskCryptinity } from '../components/assistant';

interface HelpTopic {
  id: string;
  icon: React.ReactNode;
  title: string;
  description: string;
  question: string;
}

const helpTopics: HelpTopic[] = [
  {
    id: 'cty',
    icon: <Coins size={20} />,
    title: 'Understanding CTY',
    description: 'Learn what creative energy is and how it works',
    question: 'What is CTY and how does it work?',
  },
  {
    id: 'ownership',
    icon: <Shield size={20} />,
    title: 'Content Ownership',
    description: 'Your rights to what you create',
    question: 'Who owns my content when I create it here?',
  },
  {
    id: 'watermarks',
    icon: <Sparkles size={20} />,
    title: 'Watermarks & Protection',
    description: 'How we protect your creations',
    question: 'How does the watermark work?',
  },
  {
    id: 'selling',
    icon: <ShoppingBag size={20} />,
    title: 'Selling Your Work',
    description: 'How the marketplace works',
    question: 'How do I sell my creations?',
  },
  {
    id: 'community',
    icon: <Users size={20} />,
    title: 'Community Guidelines',
    description: 'Keeping Cryptinity safe and creative',
    question: 'What are the community rules?',
  },
  {
    id: 'privacy',
    icon: <Lock size={20} />,
    title: 'Privacy & Safety',
    description: 'Your account and content privacy',
    question: 'How is my privacy protected?',
  },
  {
    id: 'availability',
    icon: <Globe size={20} />,
    title: 'Global Availability',
    description: 'Access from anywhere in the world',
    question: 'Is Cryptinity available in my country?',
  },
];

export function HelpCenterView() {
  const [showAssistant, setShowAssistant] = useState(false);
  const [initialQuestion, setInitialQuestion] = useState<string>();

  const handleTopicClick = (question: string) => {
    setInitialQuestion(question);
    setShowAssistant(true);
  };

  const handleOpenAssistant = () => {
    setInitialQuestion(undefined);
    setShowAssistant(true);
  };

  return (
    <div className="min-h-full">
      <div className="px-6 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-accent-500 to-teal-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-accent-500/20">
              <Sparkles size={28} className="text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Help Center</h1>
            <p className="text-surface-400">
              Find answers or chat with our friendly assistant
            </p>
          </div>

          <button
            onClick={handleOpenAssistant}
            className="w-full mb-8 p-5 rounded-2xl bg-gradient-to-r from-accent-500/10 to-teal-500/10 border border-accent-500/20 hover:border-accent-500/40 transition-all group"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent-500 to-teal-600 flex items-center justify-center shadow-lg shadow-accent-500/20 group-hover:shadow-accent-500/30 transition-shadow">
                <MessageCircle size={22} className="text-white" />
              </div>
              <div className="flex-1 text-left">
                <h2 className="text-lg font-semibold text-white mb-0.5">
                  Ask Cryptinity
                </h2>
                <p className="text-sm text-surface-400">
                  Chat with our assistant for quick, friendly answers
                </p>
              </div>
              <ChevronRight
                size={20}
                className="text-surface-500 group-hover:text-accent-400 group-hover:translate-x-1 transition-all"
              />
            </div>
          </button>

          <div className="space-y-3">
            <h3 className="text-sm font-medium text-surface-500 uppercase tracking-wider px-1">
              Popular Topics
            </h3>

            {helpTopics.map((topic) => (
              <button
                key={topic.id}
                onClick={() => handleTopicClick(topic.question)}
                className="w-full p-4 rounded-xl bg-surface-900/50 border border-white/[0.06] hover:border-white/[0.12] hover:bg-surface-800/50 transition-all group text-left"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-surface-800 border border-white/[0.06] flex items-center justify-center text-surface-400 group-hover:text-accent-400 group-hover:border-accent-500/30 transition-colors">
                    {topic.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium text-white mb-0.5">
                      {topic.title}
                    </h4>
                    <p className="text-xs text-surface-500 truncate">
                      {topic.description}
                    </p>
                  </div>
                  <ChevronRight
                    size={16}
                    className="text-surface-600 group-hover:text-surface-400 group-hover:translate-x-0.5 transition-all"
                  />
                </div>
              </button>
            ))}
          </div>

          <div className="mt-8 p-4 rounded-xl bg-surface-900/30 border border-white/[0.04] text-center">
            <p className="text-sm text-surface-500">
              Can't find what you're looking for?
            </p>
            <button
              onClick={handleOpenAssistant}
              className="mt-2 text-sm text-accent-400 hover:text-accent-300 transition-colors"
            >
              Start a conversation with Ask Cryptinity
            </button>
          </div>

          <div className="mt-8 pt-6 border-t border-white/[0.04] text-center">
            <div className="flex items-center justify-center gap-2 text-surface-500 mb-2">
              <Globe size={14} />
              <span className="text-xs font-medium uppercase tracking-wider">Available Worldwide</span>
            </div>
            <p className="text-xs text-surface-600 leading-relaxed max-w-xs mx-auto">
              Cryptinity is available worldwide. No country restrictions.
              Creativity and SafeZone access are open to everyone.
            </p>
          </div>
        </div>
      </div>

      <AskCryptinity
        isOpen={showAssistant}
        onClose={() => {
          setShowAssistant(false);
          setInitialQuestion(undefined);
        }}
        initialQuestion={initialQuestion}
      />
    </div>
  );
}
