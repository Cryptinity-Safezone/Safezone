import { useState, useRef, useEffect } from 'react';
import {
  Check,
  Zap,
  Edit3,
  Settings,
  Share2,
  Grid3X3,
  Sparkles,
  Store,
  Info,
  Skull,
  Volume2,
  VolumeX,
  Heart,
  UserPlus,
  Music,
  Pause,
  Play,
  MessageCircle,
  Camera,
  ArrowLeft,
} from 'lucide-react';
import type { UserProfile, ProfileTab } from '../types';
import { useProfile } from '../hooks/useProfile';
import { usePosts } from '../hooks/usePosts';
import { useMessaging } from '../hooks/useMessaging';
import { EditProfileModal } from '../components/profile/EditProfileModal';
import { ImageUploadModal } from '../components/profile/ImageUploadModal';
import { TipModal } from '../components/tipping';
import { supabase } from '../lib/supabase';

interface ProfileViewProps {
  user: UserProfile | null;
  viewingUserId?: string | null;
}

const TABS: { id: ProfileTab; label: string; icon: typeof Grid3X3 }[] = [
  { id: 'posts', label: 'Posts', icon: Grid3X3 },
  { id: 'showcase', label: 'Showcase', icon: Sparkles },
  { id: 'store', label: 'Store', icon: Store },
  { id: 'about', label: 'About', icon: Info },
];

type ImageUploadType = 'avatar' | 'cover' | null;

const DEFAULT_AVATAR = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cdefs%3E%3ClinearGradient id='bg' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%230d9488'/%3E%3Cstop offset='100%25' style='stop-color:%2310b981'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='100' height='100' rx='20' fill='url(%23bg)'/%3E%3Ctext x='50' y='65' font-family='system-ui,-apple-system,sans-serif' font-size='48' font-weight='600' fill='white' text-anchor='middle'%3EC%3C/text%3E%3C/svg%3E";

export const ProfileView = ({ user, viewingUserId }: ProfileViewProps) => {
  const [tab, setTab] = useState<ProfileTab>('posts');
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [showEditModal, setShowEditModal] = useState(false);
  const [imageUploadType, setImageUploadType] = useState<ImageUploadType>(null);
  const [messageStatus, setMessageStatus] = useState<'idle' | 'loading' | 'can_message' | 'needs_request' | 'request_sent' | 'blocked'>('idle');
  const [coverLoaded, setCoverLoaded] = useState(false);
  const [coverError, setCoverError] = useState(false);
  const [viewedProfile, setViewedProfile] = useState<UserProfile | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(false);
  const [showTipModal, setShowTipModal] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const { isFollowing, toggleFollow, updateProfile, uploadAvatar, uploadCover, removeAvatar, removeCover } = useProfile(viewingUserId || undefined);
  const { posts, loading: postsLoading } = usePosts();
  const { checkCanMessage, sendMessageRequest, getOrCreateConversation } = useMessaging();

  const isOwnProfile = !viewingUserId || viewingUserId === user?.uid;

  useEffect(() => {
    if (viewingUserId && viewingUserId !== user?.uid) {
      fetchViewedProfile(viewingUserId);
    } else {
      setViewedProfile(null);
    }
  }, [viewingUserId, user?.uid]);

  const fetchViewedProfile = async (userId: string) => {
    setLoadingProfile(true);
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) throw error;
      if (data) {
        const profileData = data as any;
        setViewedProfile({
          uid: profileData.id,
          username: profileData.username,
          handle: profileData.handle,
          avatar: profileData.avatar_url || DEFAULT_AVATAR,
          cover: profileData.cover_url || null,
          plan: profileData.plan_type,
          ctyBalance: profileData.cty_balance,
          isVerified: profileData.is_verified,
          isRestricted: profileData.is_restricted,
          followers: profileData.followers_count,
          following: profileData.following_count,
          creations: profileData.creations_count,
          bio: profileData.bio || undefined,
          interests: profileData.interests || [],
          backgroundMusic: profileData.background_music_url
            ? {
                title: profileData.background_music_title || '',
                artist: profileData.background_music_artist || '',
                url: profileData.background_music_url,
              }
            : undefined,
        });
      }
    } catch (err) {
      console.error('Error fetching profile:', err);
    } finally {
      setLoadingProfile(false);
    }
  };

  const displayProfile = isOwnProfile ? user : viewedProfile;

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = 0.3;
      audioRef.current.muted = isMuted;
    }
  }, [isMuted]);

  useEffect(() => {
    setCoverLoaded(false);
    setCoverError(false);
  }, [displayProfile?.cover]);

  useEffect(() => {
    const checkMessaging = async () => {
      if (isOwnProfile || !displayProfile?.uid) return;
      setMessageStatus('loading');
      const result = await checkCanMessage(displayProfile.uid);
      if (!result.canMessage && result.reason === 'User is blocked') {
        setMessageStatus('blocked');
      } else if (result.canMessage) {
        setMessageStatus('can_message');
      } else {
        setMessageStatus('needs_request');
      }
    };
    checkMessaging();
  }, [displayProfile?.uid, isOwnProfile, checkCanMessage]);

  const handleGoBack = () => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: 'feed' }));
  };

  if (loadingProfile || !displayProfile) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6">
        <div className="flex flex-col items-center text-center max-w-md">
          <div className="w-20 h-20 rounded-full bg-teal-500/20 border-2 border-teal-500 flex items-center justify-center mb-6">
            <div className="w-10 h-10 border-4 border-teal-500/30 border-t-teal-400 rounded-full animate-spin" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">Loading Profile</h3>
          <p className="text-base text-gray-300">Please wait...</p>
        </div>
      </div>
    );
  }

  const handleMessage = async () => {
    if (!displayProfile?.uid) return;
    if (messageStatus === 'can_message') {
      await getOrCreateConversation(displayProfile.uid);
      window.dispatchEvent(new CustomEvent('navigate', { detail: 'messages' }));
    } else if (messageStatus === 'needs_request') {
      try {
        await sendMessageRequest(displayProfile.uid);
        setMessageStatus('request_sent');
      } catch (err) {
        console.error('Failed to send message request:', err);
      }
    }
  };

  const toggleMusic = () => {
    if (audioRef.current) {
      if (isMusicPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsMusicPlaying(!isMusicPlaying);
    }
  };

  const handleFollow = async () => {
    try {
      await toggleFollow();
    } catch (error) {
      console.error('Failed to toggle follow:', error);
    }
  };

  const handleSaveProfile = async (updates: any) => {
    await updateProfile(updates);
  };

  const userPosts = displayProfile?.uid ? posts.filter((post) => post.user_id === displayProfile.uid) : [];
  const safeInterests = Array.isArray(displayProfile?.interests) ? displayProfile.interests : [];
  const safeAvatar = displayProfile?.avatar || '';
  const safeCover = displayProfile?.cover || null;
  const safeUsername = displayProfile?.username || '';
  const safeHandle = displayProfile?.handle || '';
  const safeBio = displayProfile?.bio || '';
  const safeFollowers = displayProfile?.followers ?? 0;
  const safeFollowing = displayProfile?.following ?? 0;
  const safeCtyBalance = displayProfile?.ctyBalance ?? 0;
  const safeCreations = displayProfile?.creations ?? 0;
  const safePlan = displayProfile?.plan || 'free';
  const safeIsVerified = displayProfile?.isVerified ?? false;
  const safeIsRestricted = displayProfile?.isRestricted ?? false;
  const safeBackgroundMusic = displayProfile?.backgroundMusic;

  return (
    <div className="min-h-screen bg-slate-900 relative pb-32">
      {safeBackgroundMusic && (
        <audio ref={audioRef} loop src={safeBackgroundMusic.url} />
      )}

      <div className="absolute top-0 left-0 right-0 h-[40vh] z-0 overflow-hidden">
        {safeCover && !coverError ? (
          <>
            {!coverLoaded && (
              <div className="absolute inset-0 bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900 animate-pulse" />
            )}
            <img
              src={safeCover}
              className={`w-full h-full object-cover transition-opacity duration-300 ${coverLoaded ? 'opacity-100' : 'opacity-0'}`}
              alt="Cover"
              onLoad={() => setCoverLoaded(true)}
              onError={() => setCoverError(true)}
            />
          </>
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900" />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/30 via-slate-900/60 to-slate-900" />
        <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-slate-900 to-transparent" />
      </div>

      <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {!isOwnProfile && (
            <button
              onClick={handleGoBack}
              className="w-10 h-10 glass rounded-2xl flex items-center justify-center text-white/80 hover:text-white transition-colors"
            >
              <ArrowLeft size={18} />
            </button>
          )}
          <div className="px-4 py-2 glass rounded-2xl">
            <span className="text-xs font-semibold text-white/90 tracking-wide">Profile</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isOwnProfile && (
            <button
              onClick={() => setImageUploadType('cover')}
              className="flex items-center gap-2 px-3 py-2 glass rounded-2xl text-white/80 hover:text-accent-400 hover:bg-surface-800/60 transition-all"
            >
              <Camera size={16} />
              <span className="text-xs font-medium">Edit Cover</span>
            </button>
          )}
          {safeBackgroundMusic && (
            <div className="flex items-center gap-1">
              <button
                onClick={toggleMusic}
                className="w-10 h-10 glass rounded-2xl flex items-center justify-center text-white/80 hover:text-accent-400 transition-colors"
              >
                {isMusicPlaying ? <Pause size={16} /> : <Play size={16} />}
              </button>
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="w-10 h-10 glass rounded-2xl flex items-center justify-center text-white/80 hover:text-accent-400 transition-colors"
              >
                {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </button>
            </div>
          )}
          <button className="w-10 h-10 glass rounded-2xl flex items-center justify-center text-white/80 hover:text-white transition-colors">
            <Share2 size={18} />
          </button>
          {isOwnProfile && (
            <button
              onClick={() => setShowEditModal(true)}
              className="w-10 h-10 glass rounded-2xl flex items-center justify-center text-white/80 hover:text-white transition-colors"
            >
              <Settings size={18} />
            </button>
          )}
        </div>
      </div>

      <div className="relative z-10 pt-[28vh] px-4 flex flex-col items-center">
        <div className="relative">
          <div
            className={`relative w-32 h-32 rounded-3xl p-1 bg-slate-800 border-4 border-teal-500 shadow-2xl ${isOwnProfile ? 'cursor-pointer' : ''}`}
            onClick={() => isOwnProfile && setImageUploadType('avatar')}
          >
            {safeAvatar ? (
              <img
                src={safeAvatar}
                alt={safeUsername}
                className="w-full h-full rounded-[24px] object-cover bg-surface-800"
              />
            ) : (
              <div className="w-full h-full rounded-[24px] bg-gradient-to-br from-accent-500/20 to-teal-500/10 flex items-center justify-center">
                <span className="text-4xl font-bold text-white/60">
                  {safeUsername ? safeUsername.charAt(0).toUpperCase() : '?'}
                </span>
              </div>
            )}
            {isOwnProfile && (
              <>
                <div className="absolute inset-1 rounded-[24px] flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="flex flex-col items-center text-white/90">
                    <Camera size={20} />
                    <span className="text-xs mt-1 font-medium">Change</span>
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowEditModal(true);
                  }}
                  className="absolute -bottom-2 -right-2 w-9 h-9 bg-surface-900 border border-white/10 rounded-xl flex items-center justify-center text-surface-400 hover:text-white hover:bg-surface-800 transition-all shadow-lg"
                >
                  <Edit3 size={14} />
                </button>
              </>
            )}
          </div>

          {safeIsVerified && (
            <div className="absolute -top-1 -right-1 w-8 h-8 bg-surface-950 rounded-xl flex items-center justify-center p-0.5">
              <div className="w-full h-full bg-gradient-to-br from-accent-400 to-teal-500 rounded-[10px] flex items-center justify-center shadow-glow">
                <Check size={14} className="text-white" strokeWidth={3} />
              </div>
            </div>
          )}

          {safeIsRestricted && (
            <div className="absolute -top-1 -left-1 w-8 h-8 bg-surface-950 rounded-xl flex items-center justify-center p-0.5">
              <div className="w-full h-full bg-gradient-to-br from-red-500 to-orange-600 rounded-[10px] flex items-center justify-center">
                <Skull size={14} className="text-white" />
              </div>
            </div>
          )}
        </div>

        <div className="text-center mt-5 mb-6">
          <div className="flex items-center justify-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">{safeUsername}</h1>
            {safeIsRestricted && (
              <span className="px-2 py-0.5 bg-red-500/10 border border-red-500/20 rounded-lg text-[10px] text-red-400 font-semibold uppercase tracking-wider">
                Restricted
              </span>
            )}
          </div>
          <p className="text-accent-400 font-medium text-base mt-1">{safeHandle}</p>
          {safeBio && (
            <p className="text-sm text-surface-400 mt-3 max-w-xs mx-auto leading-relaxed">{safeBio}</p>
          )}
        </div>

        {safeInterests.length > 0 && (
          <div className="flex flex-wrap justify-center gap-2 mb-6 max-w-sm">
            {safeInterests.map((interest) => (
              <span
                key={interest}
                className="px-3 py-1.5 bg-surface-900/60 border border-white/5 rounded-xl text-xs text-surface-300 font-medium hover:border-accent-500/30 hover:text-accent-400 transition-colors cursor-pointer"
              >
                {interest}
              </span>
            ))}
          </div>
        )}

        <div className="w-full max-w-md bg-slate-800 border-2 border-teal-500/30 rounded-3xl p-6 mb-6">
          <div className="flex justify-between items-center">
            <div className="flex flex-col items-center flex-1">
              <span className="text-2xl font-bold text-white">{safeFollowers.toLocaleString()}</span>
              <span className="text-xs text-gray-400 uppercase tracking-wide mt-1">Followers</span>
            </div>
            <div className="w-px h-12 bg-teal-500/30" />
            <div className="flex flex-col items-center flex-1">
              <span className="text-2xl font-bold text-white">{safeFollowing.toLocaleString()}</span>
              <span className="text-xs text-gray-400 uppercase tracking-wide mt-1">Following</span>
            </div>
            <div className="w-px h-12 bg-teal-500/30" />
            <div className="flex flex-col items-center flex-1">
              <div className="flex items-center gap-1.5">
                <Zap size={18} className="text-teal-400 fill-teal-400" />
                <span className="text-2xl font-bold text-teal-400">{safeCtyBalance.toLocaleString()}</span>
              </div>
              <span className="text-xs text-gray-400 uppercase tracking-wide mt-1">CTY</span>
            </div>
          </div>
        </div>

        {safeBackgroundMusic && (
          <div className="w-full max-w-md glass rounded-2xl p-4 mb-6 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent-500/10 flex items-center justify-center">
              <Music size={16} className="text-accent-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{safeBackgroundMusic.title}</p>
              <p className="text-xs text-surface-500 truncate">{safeBackgroundMusic.artist}</p>
            </div>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className={`w-0.5 bg-accent-400 rounded-full transition-all ${
                    isMusicPlaying ? 'animate-pulse' : ''
                  }`}
                  style={{
                    height: isMusicPlaying ? `${8 + Math.random() * 12}px` : '4px',
                    animationDelay: `${i * 100}ms`,
                  }}
                />
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-wrap justify-center gap-3 mb-8 px-2">
          {!isOwnProfile && (
            <>
              <button
                onClick={handleFollow}
                className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-semibold transition-all text-lg ${
                  isFollowing
                    ? 'bg-slate-700 border-2 border-white/30 text-white hover:border-red-500 hover:text-red-400'
                    : 'bg-teal-500 border-2 border-teal-400 text-white hover:bg-teal-600'
                }`}
              >
                <UserPlus size={18} />
                {isFollowing ? 'Following' : 'Follow'}
              </button>
              {messageStatus !== 'blocked' && (
                <button
                  onClick={handleMessage}
                  disabled={messageStatus === 'loading' || messageStatus === 'request_sent'}
                  className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-semibold transition-all ${
                    messageStatus === 'request_sent'
                      ? 'bg-surface-800 border border-accent-500/30 text-accent-400 cursor-default'
                      : messageStatus === 'can_message'
                      ? 'bg-accent-500/20 border border-accent-500/30 text-accent-400 hover:bg-accent-500/30'
                      : 'bg-surface-800 border border-white/10 text-white hover:border-accent-500/30'
                  }`}
                >
                  <MessageCircle size={16} />
                  {messageStatus === 'loading' && 'Loading...'}
                  {messageStatus === 'can_message' && 'Message'}
                  {messageStatus === 'needs_request' && 'Request'}
                  {messageStatus === 'request_sent' && 'Requested'}
                  {messageStatus === 'idle' && 'Message'}
                </button>
              )}
            </>
          )}
          {!isOwnProfile && (
            <button
              onClick={() => setShowTipModal(true)}
              className="flex items-center gap-2 px-6 py-3 bg-yellow-500/30 border-2 border-yellow-500 text-yellow-300 rounded-2xl font-semibold text-lg hover:bg-yellow-500/40 transition-all"
            >
              <Zap size={18} className="fill-yellow-300" />
              Tip
            </button>
          )}
          <button className="px-5 py-3 bg-slate-700 border-2 border-slate-600 text-white rounded-2xl hover:bg-slate-600 transition-all">
            <Share2 size={18} />
          </button>
        </div>

        <div className="w-full max-w-2xl bg-slate-900 px-4">
          <div className="flex border-b-2 border-teal-500/30 mb-6 overflow-x-auto hide-scrollbar">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex-1 min-w-[100px] pb-4 flex items-center justify-center gap-2 font-semibold text-base relative transition-all ${
                  tab === t.id ? 'text-teal-400' : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                <t.icon size={20} />
                <span>{t.label}</span>
                {tab === t.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-teal-400 rounded-full" />
                )}
              </button>
            ))}
          </div>

          <div className="min-h-[250px] bg-slate-900 pb-10">
            {tab === 'posts' && (
              <>
                {postsLoading ? (
                  <div className="flex flex-col items-center text-center py-16 bg-slate-800 rounded-2xl">
                    <div className="w-20 h-20 rounded-full bg-teal-500/20 border-2 border-teal-500 flex items-center justify-center mb-4">
                      <div className="w-10 h-10 border-4 border-teal-500/30 border-t-teal-400 rounded-full animate-spin" />
                    </div>
                    <p className="text-lg font-medium text-white">Loading posts...</p>
                  </div>
                ) : userPosts.length === 0 ? (
                  <div className="flex flex-col items-center text-center py-16 bg-slate-800 rounded-2xl">
                    <div className="w-20 h-20 rounded-full bg-slate-700 border-2 border-slate-600 flex items-center justify-center mb-4">
                      <Grid3X3 size={32} className="text-gray-400" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">
                      {isOwnProfile ? 'Your space is ready' : 'Nothing here yet'}
                    </h3>
                    <p className="text-base text-gray-400 max-w-xs">
                      {isOwnProfile ? 'When you share, your creations will live here' : 'Calm spaces grow naturally as people create'}
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-2">
                    {userPosts.map((post) => (
                      <div
                        key={post.id}
                        className="relative aspect-square rounded-xl overflow-hidden bg-surface-900/40 border border-white/5 hover:border-accent-500/30 transition-all cursor-pointer group"
                      >
                        {post.image_url ? (
                          <img
                            src={post.image_url}
                            alt="Post"
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center p-3">
                            <p className="text-xs text-surface-400 line-clamp-4">{post.content}</p>
                          </div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        <div className="absolute bottom-2 left-2 right-2 flex items-center gap-3 text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="flex items-center gap-1">
                            <Heart size={12} className={post.is_liked ? 'fill-current text-red-400' : ''} />
                            <span>{post.likes_count}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageCircle size={12} />
                            <span>{post.comments_count}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            {tab === 'showcase' && (
              <div className="flex flex-col items-center text-center py-12 animate-fade-in">
                <div className="w-16 h-16 rounded-[20px] bg-surface-900/40 border border-white/5 flex items-center justify-center mb-4">
                  <Sparkles size={28} className="text-surface-600" />
                </div>
                <h3 className="text-lg font-medium text-surface-400 mb-2">Showcase Empty</h3>
                <p className="text-sm text-surface-600 max-w-xs">
                  Featured creations will be displayed here
                </p>
              </div>
            )}

            {tab === 'store' && (
              <div className="flex flex-col items-center text-center py-12 animate-fade-in">
                <div className="w-16 h-16 rounded-[20px] bg-surface-900/40 border border-white/5 flex items-center justify-center mb-4">
                  <Store size={28} className="text-surface-600" />
                </div>
                <h3 className="text-lg font-medium text-surface-400 mb-2">Store Unavailable</h3>
                <p className="text-sm text-surface-600 max-w-xs">
                  Not available during beta
                </p>
              </div>
            )}

            {tab === 'about' && (
              <div className="space-y-4 animate-fade-in">
                <div className="glass rounded-[20px] p-5">
                  <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <Heart size={16} className="text-accent-400" />
                    Bio
                  </h3>
                  <p className="text-sm text-surface-400 leading-relaxed">
                    {safeBio || 'No bio yet. This user prefers to remain mysterious.'}
                  </p>
                </div>

                <div className="glass rounded-[20px] p-5">
                  <h3 className="text-white font-semibold mb-3">Stats</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-surface-500">Creations</span>
                      <p className="text-white font-medium">{safeCreations}</p>
                    </div>
                    <div>
                      <span className="text-surface-500">Plan</span>
                      <p className="text-white font-medium capitalize">{safePlan}</p>
                    </div>
                  </div>
                </div>

                {safeInterests.length > 0 && (
                  <div className="glass rounded-[20px] p-5">
                    <h3 className="text-white font-semibold mb-3">Interests</h3>
                    <div className="flex flex-wrap gap-2">
                      {safeInterests.map((interest) => (
                        <span
                          key={interest}
                          className="px-3 py-1.5 bg-accent-500/10 border border-accent-500/20 rounded-xl text-xs text-accent-400 font-medium"
                        >
                          {interest}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {showEditModal && isOwnProfile && (
        <EditProfileModal
          profile={displayProfile}
          onClose={() => setShowEditModal(false)}
          onSave={handleSaveProfile}
        />
      )}

      {isOwnProfile && (
        <ImageUploadModal
          isOpen={imageUploadType !== null}
          onClose={() => setImageUploadType(null)}
          type={imageUploadType || 'avatar'}
          currentImage={imageUploadType === 'avatar' ? safeAvatar : (safeCover || undefined)}
          onUpload={imageUploadType === 'avatar' ? uploadAvatar : uploadCover}
          onRemove={imageUploadType === 'avatar' ? (safeAvatar ? removeAvatar : undefined) : (safeCover ? removeCover : undefined)}
        />
      )}

      {!isOwnProfile && displayProfile && (
        <TipModal
          isOpen={showTipModal}
          onClose={() => setShowTipModal(false)}
          recipientId={displayProfile.uid}
          recipientName={safeUsername}
        />
      )}
    </div>
  );
};
