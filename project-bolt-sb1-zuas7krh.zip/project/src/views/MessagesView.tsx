import { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Send,
  MessageCircle,
  MoreVertical,
  AlertTriangle,
  Check,
  X,
  Inbox,
  Sparkles,
} from 'lucide-react';
import { useMessaging } from '../hooks/useMessaging';
import { useAuth } from '../contexts/AuthContext';
import { AskCryptinity } from '../components/assistant';
import type { Conversation, Message, MessageRequest } from '../types';

const DEFAULT_AVATAR = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cdefs%3E%3ClinearGradient id='bg' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%230d9488'/%3E%3Cstop offset='100%25' style='stop-color:%2310b981'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='100' height='100' rx='20' fill='url(%23bg)'/%3E%3Ctext x='50' y='65' font-family='system-ui,-apple-system,sans-serif' font-size='48' font-weight='600' fill='white' text-anchor='middle'%3EC%3C/text%3E%3C/svg%3E";

interface ConversationViewProps {
  conversation: Conversation;
  onBack: () => void;
}

const ConversationView = ({ conversation, onBack }: ConversationViewProps) => {
  const { user } = useAuth();
  const { getMessages, sendMessage, reportMessage } = useMessaging();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [reportDetails, setReportDetails] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadMessages = async () => {
      setLoading(true);
      const msgs = await getMessages(conversation.id);
      setMessages(msgs);
      setLoading(false);
    };
    loadMessages();
  }, [conversation.id, getMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!newMessage.trim() || sending) return;

    setSending(true);
    try {
      const msg = await sendMessage(conversation.id, newMessage.trim());
      setMessages((prev) => [...prev, msg]);
      setNewMessage('');
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setSending(false);
    }
  };

  const handleReport = async () => {
    if (!reportReason) return;

    try {
      await reportMessage(
        messages[messages.length - 1]?.id || '',
        conversation.id,
        reportReason,
        reportDetails || undefined
      );
      setShowReportModal(false);
      setReportReason('');
      setReportDetails('');
    } catch (err) {
      console.error('Failed to report:', err);
    }
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);

    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    return date.toLocaleDateString();
  };

  const otherUser = conversation.other_user;

  return (
    <div className="flex flex-col h-[calc(100vh-180px)]">
      <div className="flex items-center justify-between p-4 border-b border-white/5">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-center text-surface-400 hover:text-white transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <img
            src={otherUser?.avatar_url || DEFAULT_AVATAR}
            alt={otherUser?.username || 'User'}
            className="w-10 h-10 rounded-xl object-cover"
          />
          <div>
            <p className="font-medium text-white">{otherUser?.username || 'User'}</p>
            <p className="text-xs text-surface-500">{otherUser?.handle}</p>
          </div>
        </div>
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="w-10 h-10 rounded-xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-center text-surface-400 hover:text-white transition-colors"
          >
            <MoreVertical size={18} />
          </button>
          {showMenu && (
            <div className="absolute right-0 top-12 w-48 bg-surface-900 border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50">
              <button
                onClick={() => {
                  setShowMenu(false);
                  setShowReportModal(true);
                }}
                className="w-full px-4 py-3 text-left text-sm text-red-400 hover:bg-white/5 flex items-center gap-2"
              >
                <AlertTriangle size={16} />
                Report Conversation
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="w-8 h-8 border-2 border-accent-400/30 border-t-accent-400 rounded-full animate-spin" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-16 h-16 rounded-2xl bg-surface-900/60 border border-white/5 flex items-center justify-center mb-4">
              <MessageCircle size={28} className="text-surface-600" />
            </div>
            <p className="text-surface-500">No messages yet</p>
            <p className="text-sm text-surface-600 mt-1">Send a message to start the conversation</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isOwn = msg.sender_id === user?.id;
            return (
              <div
                key={msg.id}
                className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[75%] px-4 py-2.5 rounded-2xl ${
                    isOwn
                      ? 'bg-accent-500/20 border border-accent-500/30 text-white'
                      : 'bg-surface-900/60 border border-white/5 text-surface-300'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{msg.content}</p>
                  <p className={`text-[10px] mt-1 ${isOwn ? 'text-accent-400/60' : 'text-surface-600'}`}>
                    {formatTime(msg.created_at)}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-white/5">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder="Type a message..."
            className="flex-1 px-4 py-3 bg-surface-900/60 border border-white/5 rounded-xl text-white placeholder-surface-600 focus:outline-none focus:border-accent-500/30"
          />
          <button
            onClick={handleSend}
            disabled={!newMessage.trim() || sending}
            className="w-12 h-12 rounded-xl bg-accent-500/20 border border-accent-500/30 flex items-center justify-center text-accent-400 hover:bg-accent-500/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            <Send size={18} />
          </button>
        </div>
      </div>

      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md bg-surface-900 border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Report Conversation</h3>
            <div className="space-y-3 mb-4">
              {['spam', 'harassment', 'inappropriate', 'threats', 'other'].map((reason) => (
                <button
                  key={reason}
                  onClick={() => setReportReason(reason)}
                  className={`w-full px-4 py-3 rounded-xl text-left text-sm capitalize transition-all ${
                    reportReason === reason
                      ? 'bg-accent-500/20 border border-accent-500/30 text-accent-400'
                      : 'bg-white/[0.03] border border-white/5 text-surface-400 hover:border-white/10'
                  }`}
                >
                  {reason}
                </button>
              ))}
            </div>
            <textarea
              value={reportDetails}
              onChange={(e) => setReportDetails(e.target.value)}
              placeholder="Additional details (optional)"
              className="w-full px-4 py-3 bg-white/[0.03] border border-white/5 rounded-xl text-white placeholder-surface-600 focus:outline-none focus:border-accent-500/30 resize-none h-24 mb-4"
            />
            <div className="flex gap-3">
              <button
                onClick={() => setShowReportModal(false)}
                className="flex-1 px-4 py-3 bg-white/[0.03] border border-white/5 rounded-xl text-surface-400 hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleReport}
                disabled={!reportReason}
                className="flex-1 px-4 py-3 bg-red-500/20 border border-red-500/30 rounded-xl text-red-400 hover:bg-red-500/30 disabled:opacity-50 transition-all"
              >
                Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface RequestItemProps {
  request: MessageRequest;
  onAccept: () => void;
  onDecline: () => void;
}

const RequestItem = ({ request, onAccept, onDecline }: RequestItemProps) => (
  <div className="flex items-center justify-between p-4 bg-surface-900/40 border border-white/5 rounded-xl">
    <div className="flex items-center gap-3">
      <img
        src={request.sender?.avatar_url || DEFAULT_AVATAR}
        alt={request.sender?.username || 'User'}
        className="w-10 h-10 rounded-xl object-cover"
      />
      <div>
        <p className="font-medium text-white">{request.sender?.username}</p>
        <p className="text-xs text-surface-500">{request.sender?.handle}</p>
      </div>
    </div>
    <div className="flex gap-2">
      <button
        onClick={onAccept}
        className="w-9 h-9 rounded-lg bg-accent-500/20 border border-accent-500/30 flex items-center justify-center text-accent-400 hover:bg-accent-500/30 transition-all"
      >
        <Check size={16} />
      </button>
      <button
        onClick={onDecline}
        className="w-9 h-9 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 hover:bg-red-500/20 transition-all"
      >
        <X size={16} />
      </button>
    </div>
  </div>
);

type TabType = 'messages' | 'assistant';

export const MessagesView = () => {
  const [activeTab, setActiveTab] = useState<TabType>('messages');
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [showRequests, setShowRequests] = useState(false);
  const { conversations, messageRequests, loading, respondToRequest } = useMessaging();

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);

    if (mins < 1) return 'Now';
    if (mins < 60) return `${mins}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    return date.toLocaleDateString();
  };

  if (selectedConversation) {
    return (
      <div className="pt-24 px-4 pb-32">
        <ConversationView
          conversation={selectedConversation}
          onBack={() => setSelectedConversation(null)}
        />
      </div>
    );
  }

  return (
    <div className="pt-24 px-4 pb-32">
      <div className="max-w-lg mx-auto">
        <div className="flex items-center gap-2 mb-6 p-1 bg-surface-900/50 border border-white/[0.06] rounded-xl">
          <button
            onClick={() => setActiveTab('messages')}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'messages'
                ? 'bg-white/[0.08] text-white'
                : 'text-surface-500 hover:text-surface-300'
            }`}
          >
            <MessageCircle size={16} />
            Messages
            {messageRequests.length > 0 && (
              <span className="w-5 h-5 bg-accent-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {messageRequests.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('assistant')}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'assistant'
                ? 'bg-gradient-to-r from-accent-500/20 to-teal-500/20 text-white border border-accent-500/20'
                : 'text-surface-500 hover:text-surface-300'
            }`}
          >
            <Sparkles size={16} />
            Ask Cryptinity
          </button>
        </div>

        {activeTab === 'assistant' ? (
          <div className="bg-surface-900/50 border border-white/[0.06] rounded-2xl overflow-hidden h-[calc(100vh-280px)]">
            <AskCryptinity
              isOpen={true}
              onClose={() => setActiveTab('messages')}
              variant="embedded"
            />
          </div>
        ) : (
          <>
            {messageRequests.length > 0 && (
              <button
                onClick={() => setShowRequests(!showRequests)}
                className="w-full mb-4 p-3 bg-accent-500/10 border border-accent-500/20 rounded-xl text-sm text-accent-400 hover:bg-accent-500/20 transition-all flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <Inbox size={16} />
                  <span>Message Requests</span>
                </div>
                <span className="w-6 h-6 bg-accent-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {messageRequests.length}
                </span>
              </button>
            )}

            {showRequests && messageRequests.length > 0 && (
              <div className="mb-6 space-y-3">
                {messageRequests.map((req) => (
                  <RequestItem
                    key={req.id}
                    request={req}
                    onAccept={() => respondToRequest(req.id, true)}
                    onDecline={() => respondToRequest(req.id, false)}
                  />
                ))}
              </div>
            )}

            {loading ? (
              <div className="flex flex-col items-center justify-center py-20">
                <div className="w-12 h-12 border-2 border-accent-400/30 border-t-accent-400 rounded-full animate-spin mb-4" />
                <p className="text-surface-500">Loading messages...</p>
              </div>
            ) : conversations.length === 0 ? (
              <div className="flex flex-col items-center text-center py-16">
                <div className="w-20 h-20 rounded-2xl bg-surface-900/60 border border-white/5 flex items-center justify-center mb-5">
                  <MessageCircle size={36} className="text-surface-600" />
                </div>
                <h2 className="text-lg font-semibold text-surface-400 mb-2">No messages yet</h2>
                <p className="text-sm text-surface-600 max-w-xs mb-6">
                  Messages appear when both sides are ready. You're always in control.
                </p>
                <button
                  onClick={() => setActiveTab('assistant')}
                  className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-accent-500/10 to-teal-500/10 border border-accent-500/20 rounded-xl text-sm text-accent-400 hover:border-accent-500/40 transition-all"
                >
                  <Sparkles size={14} />
                  Chat with Ask Cryptinity
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {conversations.map((convo) => (
                  <button
                    key={convo.id}
                    onClick={() => setSelectedConversation(convo)}
                    className="w-full flex items-center gap-3 p-4 bg-surface-900/40 border border-white/5 rounded-xl hover:border-accent-500/20 transition-all text-left"
                  >
                    <img
                      src={convo.other_user?.avatar_url || DEFAULT_AVATAR}
                      alt={convo.other_user?.username || 'User'}
                      className="w-12 h-12 rounded-xl object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <p className="font-medium text-white truncate">
                          {convo.other_user?.username || 'User'}
                        </p>
                        <span className="text-xs text-surface-600 flex-shrink-0 ml-2">
                          {formatTime(convo.last_message_at)}
                        </span>
                      </div>
                      <p className="text-sm text-surface-500 truncate">
                        {convo.last_message?.content || 'No messages yet'}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
