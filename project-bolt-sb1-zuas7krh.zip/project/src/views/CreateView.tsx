import { useState, useEffect } from 'react';
import {
  Sparkles,
  Lock,
  Share2,
  Loader2,
  ChevronRight,
  Download,
  RefreshCw,
  Trash2,
  Check,
  AlertCircle,
  Image as ImageIcon,
  Zap,
  Shield,
  X,
  Clock,
  Coins,
  Play,
} from 'lucide-react';
import { useImageGeneration, GeneratedImage } from '../hooks/useImageGeneration';
import { useCTY } from '../hooks/useCTY';
import { ProtectedImage } from '../components/protection/ProtectedImage';
import { MotionGenerator } from '../components/motion/MotionGenerator';

const STYLES = [
  { id: 'emotional', label: 'Emotional', icon: '💭' },
  { id: 'dreamlike', label: 'Dreamlike', icon: '✨' },
  { id: 'healing', label: 'Healing', icon: '🌿' },
  { id: 'abstract', label: 'Abstract', icon: '🎨' },
  { id: 'nature', label: 'Nature', icon: '🍃' },
  { id: 'symbolic', label: 'Symbolic', icon: '🔮' },
  { id: 'minimal', label: 'Minimal', icon: '◯' },
  { id: 'inner-world', label: 'Inner World', icon: '🧠' },
];

const EXAMPLE_PROMPTS = [
  {
    category: 'Emotional',
    text: 'A calm abstract scene representing peace after sadness, soft green and blue tones, gentle light, minimalist',
  },
  {
    category: 'Dreamlike',
    text: 'A surreal floating island under a quiet night sky, glowing plants, dreamlike atmosphere, symbolic and calm',
  },
  {
    category: 'Healing',
    text: 'Soft sunlight through a forest clearing, peaceful mood, gentle colors, symbolic of recovery and hope',
  },
  {
    category: 'Inner World',
    text: 'An abstract visualization of the human mind, flowing shapes, green energy, calm and introspective',
  },
  {
    category: 'Abstract',
    text: 'Minimal abstract art using soft gradients, flowing forms, emotional balance, modern style',
  },
];

const QUALITY_OPTIONS = [
  { id: 'standard', label: 'Standard', cost: 25, description: 'Good for personal use' },
  { id: 'high', label: 'High', cost: 40, description: 'Creator quality', requiresPlan: 'personal' },
];

interface OwnershipModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept: () => void;
}

function OwnershipModal({ isOpen, onClose, onAccept }: OwnershipModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative glass rounded-3xl p-6 max-w-md w-full animate-fade-in">
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-accent-500/20 to-teal-500/10 flex items-center justify-center mx-auto mb-4">
            <Shield size={32} className="text-accent-400" />
          </div>
          <h2 className="text-xl font-semibold text-white mb-2">SafeZone Content Creation</h2>
          <p className="text-sm text-surface-400">
            Before you create, please understand our content guidelines.
          </p>
        </div>

        <div className="space-y-4 mb-6">
          <div className="glass rounded-xl p-4">
            <h3 className="text-sm font-medium text-white mb-2">What you can create:</h3>
            <ul className="text-xs text-surface-400 space-y-1.5">
              <li className="flex items-center gap-2">
                <Check size={12} className="text-teal-400" />
                Abstract and emotional artwork
              </li>
              <li className="flex items-center gap-2">
                <Check size={12} className="text-teal-400" />
                Dreamlike and surreal scenes
              </li>
              <li className="flex items-center gap-2">
                <Check size={12} className="text-teal-400" />
                Nature and symbolic imagery
              </li>
              <li className="flex items-center gap-2">
                <Check size={12} className="text-teal-400" />
                Healing and peaceful visuals
              </li>
            </ul>
          </div>

          <div className="glass rounded-xl p-4 border-orange-500/20">
            <h3 className="text-sm font-medium text-white mb-2">Not allowed in SafeZone:</h3>
            <ul className="text-xs text-surface-400 space-y-1.5">
              <li className="flex items-center gap-2">
                <X size={12} className="text-orange-400" />
                Real artist style imitation
              </li>
              <li className="flex items-center gap-2">
                <X size={12} className="text-orange-400" />
                Copyrighted characters or brands
              </li>
              <li className="flex items-center gap-2">
                <X size={12} className="text-orange-400" />
                Celebrities or public figures
              </li>
              <li className="flex items-center gap-2">
                <X size={12} className="text-orange-400" />
                Photorealistic human faces
              </li>
            </ul>
          </div>
        </div>

        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 glass rounded-xl py-3 text-surface-400 hover:text-white transition-colors">
            Cancel
          </button>
          <button
            onClick={onAccept}
            className="flex-1 bg-gradient-to-r from-accent-600 to-teal-600 rounded-xl py-3 text-white font-medium hover:opacity-90 transition-opacity"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
}

interface ResultViewProps {
  image: GeneratedImage;
  onBack: () => void;
  onRegenerate: () => void;
  onShare: () => Promise<void>;
  onDelete: () => Promise<void>;
  sharing: boolean;
  isCreator: boolean;
}

function ResultView({ image, onBack, onRegenerate, onShare, onDelete, sharing, isCreator }: ResultViewProps) {
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async () => {
    setDeleting(true);
    await onDelete();
    setDeleting(false);
  };

  return (
    <div className="animate-fade-in">
      <div className="relative rounded-3xl overflow-hidden mb-6 bg-surface-900/50">
        <ProtectedImage
          src={image.image_url}
          alt={image.prompt}
          isAIGenerated={true}
          isWatermarked={true}
          isOwner={true}
          watermarkVariant="corner"
          enableViewer={true}
          className="w-full aspect-square"
        />
        <div className="absolute top-3 left-3 flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-black/40 backdrop-blur-sm">
            <Sparkles size={12} className="text-accent-400" />
            <span className="text-xs text-white/90 font-medium">AI-generated</span>
          </div>
          {image.is_private ? (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-black/40 backdrop-blur-sm">
              <Lock size={12} className="text-surface-400" />
              <span className="text-xs text-white/70">Private</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-black/40 backdrop-blur-sm">
              <Share2 size={12} className="text-teal-400" />
              <span className="text-xs text-white/70">Shared</span>
            </div>
          )}
        </div>
      </div>

      <div className="glass rounded-2xl p-4 mb-4">
        <p className="text-sm text-surface-300 leading-relaxed">{image.prompt}</p>
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-white/5">
          <span className="text-xs text-surface-500 capitalize">{image.style}</span>
          <span className="w-1 h-1 rounded-full bg-surface-600" />
          <span className="text-xs text-surface-500 capitalize">{image.quality} quality</span>
          <span className="w-1 h-1 rounded-full bg-surface-600" />
          <span className="text-xs text-surface-500">{image.cty_cost} CTY</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <button
          onClick={onBack}
          className="glass rounded-xl py-3.5 px-4 flex items-center justify-center gap-2 text-surface-300 hover:text-white hover:bg-surface-800/60 transition-all"
        >
          <Lock size={16} />
          <span className="text-sm font-medium">Save Private</span>
        </button>

        {image.is_private && !image.is_shared && (
          <button
            onClick={onShare}
            disabled={sharing}
            className="glass rounded-xl py-3.5 px-4 flex items-center justify-center gap-2 text-teal-400 hover:bg-teal-500/10 hover:border-teal-500/30 transition-all disabled:opacity-50"
          >
            {sharing ? <Loader2 size={16} className="animate-spin" /> : <Share2 size={16} />}
            <span className="text-sm font-medium">Share to Feed</span>
          </button>
        )}

        {image.is_shared && (
          <button
            disabled
            className="glass rounded-xl py-3.5 px-4 flex items-center justify-center gap-2 text-teal-400 opacity-60"
          >
            <Check size={16} />
            <span className="text-sm font-medium">Shared</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-3 gap-3">
        <button
          onClick={onRegenerate}
          className="glass rounded-xl py-3 px-3 flex flex-col items-center gap-1.5 text-surface-400 hover:text-accent-400 hover:bg-surface-800/60 transition-all"
        >
          <RefreshCw size={18} />
          <span className="text-xs">Regenerate</span>
        </button>

        {isCreator && (
          <button className="glass rounded-xl py-3 px-3 flex flex-col items-center gap-1.5 text-surface-400 hover:text-teal-400 hover:bg-surface-800/60 transition-all">
            <Download size={18} />
            <span className="text-xs">Export</span>
          </button>
        )}

        <button
          onClick={handleDelete}
          disabled={deleting}
          className="glass rounded-xl py-3 px-3 flex flex-col items-center gap-1.5 text-surface-400 hover:text-red-400 hover:bg-surface-800/60 transition-all disabled:opacity-50"
        >
          {deleting ? <Loader2 size={18} className="animate-spin" /> : <Trash2 size={18} />}
          <span className="text-xs">Delete</span>
        </button>
      </div>
    </div>
  );
}

export function CreateView() {
  const { balance, plan } = useCTY();
  const { images, limits, generating, error, generate, shareToFeed, deleteImage, clearError } = useImageGeneration();

  const [activeTab, setActiveTab] = useState<'image' | 'motion'>('image');
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('abstract');
  const [quality, setQuality] = useState<'standard' | 'high'>('standard');
  const [isPrivate, setIsPrivate] = useState(true);
  const [showOwnershipModal, setShowOwnershipModal] = useState(false);
  const [hasAcceptedTerms, setHasAcceptedTerms] = useState(false);
  const [currentResult, setCurrentResult] = useState<GeneratedImage | null>(null);
  const [sharing, setSharing] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem('cryptinity_create_terms_accepted');
    if (accepted === 'true') {
      setHasAcceptedTerms(true);
    }
  }, []);

  const selectedQualityOption = QUALITY_OPTIONS.find(q => q.id === quality)!;
  const cost = selectedQualityOption.cost;
  const canAfford = balance >= cost;
  const canGenerate = prompt.trim().length >= 10 && canAfford && hasAcceptedTerms;

  const handleGenerate = async () => {
    if (!hasAcceptedTerms) {
      setShowOwnershipModal(true);
      return;
    }

    if (!canAfford) {
      return;
    }

    if (prompt.trim().length < 10) {
      return;
    }

    clearError();

    try {
      const result = await generate({
        prompt: prompt.trim(),
        style: selectedStyle,
        quality,
        isPrivate,
      });

      if (result) {
        setCurrentResult(result);
      }
    } catch (err: any) {
      console.error('Generation failed:', err);
    }
  };

  const handleAcceptTerms = () => {
    setHasAcceptedTerms(true);
    localStorage.setItem('cryptinity_create_terms_accepted', 'true');
    setShowOwnershipModal(false);
  };

  const handleShare = async () => {
    if (!currentResult) return;
    setSharing(true);
    await shareToFeed(currentResult.id);
    setCurrentResult(prev => prev ? { ...prev, is_private: false, is_shared: true } : null);
    setSharing(false);
  };

  const handleDelete = async () => {
    if (!currentResult) return;
    await deleteImage(currentResult.id);
    setCurrentResult(null);
    setPrompt('');
  };

  const handleRegenerate = () => {
    setCurrentResult(null);
  };

  const handleExampleClick = (text: string) => {
    setPrompt(text);
  };

  if (currentResult) {
    return (
      <div className="pt-24 pb-32 px-4 max-w-lg mx-auto">
        <ResultView
          image={currentResult}
          onBack={() => setCurrentResult(null)}
          onRegenerate={handleRegenerate}
          onShare={handleShare}
          onDelete={handleDelete}
          sharing={sharing}
          isCreator={plan === 'creator'}
        />
      </div>
    );
  }

  return (
    <div className="pt-24 pb-32 px-4 max-w-lg mx-auto animate-fade-in">
      <OwnershipModal
        isOpen={showOwnershipModal}
        onClose={() => setShowOwnershipModal(false)}
        onAccept={handleAcceptTerms}
      />

      <div className="text-center mb-6">
        <div className="relative inline-flex mb-4">
          <div className="absolute -inset-4 bg-gradient-to-br from-accent-500/20 to-teal-500/20 rounded-full blur-2xl" />
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-accent-500/20 to-teal-500/10 border border-accent-500/20 flex items-center justify-center">
            <span className="text-2xl font-bold bg-gradient-to-br from-accent-400 to-teal-400 bg-clip-text text-transparent">C</span>
          </div>
        </div>
        <h1 className="text-xl font-semibold text-white mb-1">Create</h1>
        <p className="text-sm text-surface-500">AI-generated content, protected by Cryptinity</p>
      </div>

      <div className="flex gap-2 p-1 glass rounded-2xl mb-8">
        <button
          onClick={() => setActiveTab('image')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-medium text-sm transition-all ${
            activeTab === 'image'
              ? 'bg-gradient-to-r from-accent-600 to-teal-600 text-white'
              : 'text-surface-400 hover:text-white'
          }`}
        >
          <ImageIcon size={18} />
          <span>Image</span>
        </button>
        <button
          onClick={() => setActiveTab('motion')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-medium text-sm transition-all ${
            activeTab === 'motion'
              ? 'bg-gradient-to-r from-accent-600 to-teal-600 text-white'
              : 'text-surface-400 hover:text-white'
          }`}
        >
          <Play size={18} />
          <span>Living Image</span>
        </button>
      </div>

      {activeTab === 'motion' && (
        <MotionGenerator onClose={() => setActiveTab('image')} />
      )}

      {activeTab === 'image' && (
        <>

      {limits && (
        <div className="glass rounded-2xl p-4 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent-500/10 flex items-center justify-center">
              <Zap size={18} className="text-accent-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-white">Daily Generations</p>
              <p className="text-xs text-surface-500">{limits.remaining} of {limits.limit} remaining</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Coins size={14} className="text-accent-400" />
            <span className="text-sm font-medium text-white">{balance} CTY</span>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-500/20 border-2 border-red-500 rounded-2xl p-4 mb-6 flex items-start gap-3">
          <AlertCircle size={20} className="text-red-400 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-base font-semibold text-red-300 mb-1">Generation Failed</p>
            <p className="text-sm text-red-200">{error}</p>
            <button onClick={clearError} className="text-sm text-red-400 hover:text-red-300 mt-2 underline">
              Dismiss
            </button>
          </div>
        </div>
      )}

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-surface-300 mb-3">Describe your vision</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe a feeling, idea, or vision..."
            rows={4}
            maxLength={500}
            className="w-full glass rounded-2xl p-4 text-white placeholder-surface-600 resize-none focus:outline-none focus:ring-1 focus:ring-accent-500/30 transition-all text-sm leading-relaxed"
          />
          <div className="flex items-center justify-between mt-2">
            <p className="text-xs text-surface-600">Minimum 10 characters</p>
            <p className="text-xs text-surface-600">{prompt.length}/500</p>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-surface-300 mb-3">Style</label>
          <div className="flex flex-wrap gap-2">
            {STYLES.map((style) => (
              <button
                key={style.id}
                onClick={() => setSelectedStyle(style.id)}
                className={`px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                  selectedStyle === style.id
                    ? 'bg-accent-500/20 text-accent-400 border border-accent-500/30'
                    : 'glass text-surface-400 hover:text-white hover:bg-surface-800/60'
                }`}
              >
                <span className="mr-1.5">{style.icon}</span>
                {style.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-surface-300 mb-3">Quality</label>
          <div className="grid grid-cols-2 gap-3">
            {QUALITY_OPTIONS.map((option) => {
              const isLocked = option.requiresPlan && plan === 'free';
              return (
                <button
                  key={option.id}
                  onClick={() => !isLocked && setQuality(option.id as 'standard' | 'high')}
                  disabled={isLocked}
                  className={`glass rounded-xl p-4 text-left transition-all ${
                    quality === option.id
                      ? 'bg-accent-500/10 border-accent-500/30'
                      : isLocked
                      ? 'opacity-50 cursor-not-allowed'
                      : 'hover:bg-surface-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-sm font-medium ${quality === option.id ? 'text-accent-400' : 'text-white'}`}>
                      {option.label}
                    </span>
                    {isLocked && <Lock size={14} className="text-surface-500" />}
                  </div>
                  <p className="text-xs text-surface-500">{option.description}</p>
                  <div className="flex items-center gap-1 mt-2">
                    <Coins size={12} className="text-accent-400" />
                    <span className="text-xs text-accent-400">{option.cost} CTY</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-surface-300 mb-3">Privacy</label>
          <div className="glass rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {isPrivate ? (
                <Lock size={18} className="text-surface-400" />
              ) : (
                <Share2 size={18} className="text-teal-400" />
              )}
              <div>
                <p className="text-sm font-medium text-white">{isPrivate ? 'Private' : 'Share to Feed'}</p>
                <p className="text-xs text-surface-500">
                  {isPrivate ? 'Only visible to you' : 'Visible to everyone'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsPrivate(!isPrivate)}
              className={`relative w-12 h-7 rounded-full transition-colors ${
                isPrivate ? 'bg-surface-700' : 'bg-teal-600'
              }`}
            >
              <div
                className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-transform ${
                  isPrivate ? 'left-1' : 'left-6'
                }`}
              />
            </button>
          </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={!canGenerate || generating}
          className={`w-full rounded-2xl py-4 px-6 flex items-center justify-center gap-3 font-medium transition-all ${
            canGenerate && !generating
              ? 'bg-gradient-to-r from-accent-600 to-teal-600 text-white hover:opacity-90'
              : 'glass text-surface-500 cursor-not-allowed'
          }`}
        >
          {generating ? (
            <>
              <Loader2 size={20} className="animate-spin" />
              <span>Creating your vision...</span>
            </>
          ) : (
            <>
              <Sparkles size={20} />
              <span>Create Image</span>
              <span className="text-white/70">({cost} CTY)</span>
            </>
          )}
        </button>

        {!canAfford && !generating && (
          <div className="bg-orange-500/20 border border-orange-500/50 rounded-xl p-3 text-center">
            <p className="text-sm font-medium text-orange-300">
              Insufficient CTY balance. You need {cost} CTY to generate.
            </p>
            <p className="text-xs text-orange-400/70 mt-1">Current balance: {balance} CTY</p>
          </div>
        )}

        <p className="text-xs text-center text-surface-600">
          AI-generated content is protected by Cryptinity
        </p>
      </div>

      <div className="mt-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-medium text-surface-300">Example Prompts</h2>
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="text-xs text-accent-400 hover:text-accent-300 transition-colors flex items-center gap-1"
          >
            <Clock size={12} />
            {showHistory ? 'Show examples' : 'View history'}
          </button>
        </div>

        {showHistory ? (
          <div className="space-y-3">
            {images.length === 0 ? (
              <div className="glass rounded-2xl p-6 text-center">
                <ImageIcon size={32} className="text-surface-600 mx-auto mb-3" />
                <p className="text-sm text-surface-500">No images yet. Your creations will appear here.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {images.slice(0, 4).map((img) => (
                  <button
                    key={img.id}
                    onClick={() => setCurrentResult(img)}
                    className="relative group rounded-xl overflow-hidden aspect-square"
                  >
                    <img
                      src={img.thumbnail_url || img.image_url}
                      alt={img.prompt}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                      <ChevronRight
                        size={24}
                        className="text-white opacity-0 group-hover:opacity-100 transition-opacity"
                      />
                    </div>
                    {img.is_private && (
                      <div className="absolute top-2 right-2">
                        <Lock size={12} className="text-white/70" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            {EXAMPLE_PROMPTS.map((example, index) => (
              <button
                key={index}
                onClick={() => handleExampleClick(example.text)}
                className="w-full glass rounded-xl p-4 text-left hover:bg-surface-800/60 transition-all group"
              >
                <span className="text-xs text-accent-400 font-medium">{example.category}</span>
                <p className="text-sm text-surface-400 mt-1 group-hover:text-surface-300 transition-colors line-clamp-2">
                  {example.text}
                </p>
              </button>
            ))}
          </div>
        )}
      </div>
        </>
      )}
    </div>
  );
}
