import { useCallback, useRef, useState } from 'react';
import {
  Upload,
  Download,
  Trash2,
  Settings2,
  Check,
  Maximize2,
  FileImage,
  Sparkles,
  RefreshCw,
  ChevronDown,
  Zap,
} from 'lucide-react';
import { useImageOptimizer } from '../hooks/useImageOptimizer';
import type { OptimizedImage, ImageOptimizeSettings } from '../types';

const formatBytes = (bytes: number): string => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
};

interface SliderProps {
  value: number;
  min: number;
  max: number;
  onChange: (value: number) => void;
  label: string;
  unit?: string;
}

const Slider = ({ value, min, max, onChange, label, unit = '' }: SliderProps) => {
  const percentage = ((value - min) / (max - min)) * 100;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-surface-300">{label}</span>
        <span className="text-sm font-bold text-white tabular-nums">
          {value}{unit}
        </span>
      </div>
      <div className="relative h-2">
        <div className="absolute inset-0 bg-surface-800 rounded-full" />
        <div
          className="absolute left-0 top-0 h-full bg-gradient-to-r from-accent-500 to-teal-500 rounded-full transition-all duration-150"
          style={{ width: `${percentage}%` }}
        />
        <input
          type="range"
          min={min}
          max={max}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        <div
          className="absolute top-1/2 -translate-y-1/2 w-5 h-5 bg-white rounded-full shadow-lg border-2 border-accent-500 transition-all duration-150 pointer-events-none"
          style={{ left: `calc(${percentage}% - 10px)` }}
        />
      </div>
    </div>
  );
};

interface FormatSelectorProps {
  value: ImageOptimizeSettings['format'];
  onChange: (format: ImageOptimizeSettings['format']) => void;
}

const FormatSelector = ({ value, onChange }: FormatSelectorProps) => {
  const formats: { value: ImageOptimizeSettings['format']; label: string; desc: string }[] = [
    { value: 'webp', label: 'WebP', desc: 'Best compression' },
    { value: 'jpeg', label: 'JPEG', desc: 'Universal' },
    { value: 'png', label: 'PNG', desc: 'Lossless' },
  ];

  return (
    <div className="space-y-3">
      <span className="text-sm font-medium text-surface-300">Output Format</span>
      <div className="grid grid-cols-3 gap-2">
        {formats.map((format) => (
          <button
            key={format.value}
            onClick={() => onChange(format.value)}
            className={`relative p-3 rounded-xl border transition-all duration-200 ${
              value === format.value
                ? 'bg-accent-500/10 border-accent-500/50 text-white'
                : 'bg-surface-900/40 border-white/5 text-surface-400 hover:border-white/10 hover:text-white'
            }`}
          >
            {value === format.value && (
              <div className="absolute top-2 right-2 w-4 h-4 bg-accent-500 rounded-full flex items-center justify-center">
                <Check size={10} className="text-white" strokeWidth={3} />
              </div>
            )}
            <div className="text-sm font-bold">{format.label}</div>
            <div className="text-[10px] mt-0.5 opacity-60">{format.desc}</div>
          </button>
        ))}
      </div>
    </div>
  );
};

interface ImageCardProps {
  image: OptimizedImage;
  onRemove: () => void;
  onDownload: () => void;
}

const ImageCard = ({ image, onRemove, onDownload }: ImageCardProps) => {
  const [showOriginal, setShowOriginal] = useState(false);

  return (
    <div className="group card p-4 space-y-4 animate-scale-in">
      <div className="relative aspect-video rounded-2xl overflow-hidden bg-surface-900">
        <img
          src={showOriginal ? image.original.url : image.optimized.url}
          alt="Preview"
          className="w-full h-full object-contain"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        <div className="absolute top-3 left-3 flex gap-2">
          <span className={`badge ${showOriginal ? 'badge-surface' : 'badge-accent'}`}>
            {showOriginal ? 'Original' : 'Optimized'}
          </span>
          {!showOriginal && image.savings > 0 && (
            <span className="badge bg-teal-500/10 text-teal-400 border border-teal-500/20">
              -{image.savings}%
            </span>
          )}
        </div>

        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <button
            onClick={() => setShowOriginal(!showOriginal)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 backdrop-blur-md rounded-lg text-white text-xs font-medium hover:bg-white/20 transition-colors"
          >
            <RefreshCw size={12} />
            Compare
          </button>
          <div className="flex gap-2">
            <button
              onClick={onDownload}
              className="w-8 h-8 flex items-center justify-center bg-accent-500 rounded-lg text-white hover:bg-accent-400 transition-colors"
            >
              <Download size={14} />
            </button>
            <button
              onClick={onRemove}
              className="w-8 h-8 flex items-center justify-center bg-surface-800/80 rounded-lg text-surface-400 hover:bg-red-500/20 hover:text-red-400 transition-colors"
            >
              <Trash2 size={14} />
            </button>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between text-xs">
        <div className="space-y-1">
          <div className="text-surface-500">Original</div>
          <div className="text-white font-medium">
            {image.original.width} x {image.original.height}
          </div>
          <div className="text-surface-400">{formatBytes(image.original.size)}</div>
        </div>
        <div className="flex flex-col items-center">
          <Zap size={16} className="text-accent-400 fill-accent-400" />
          <span className="text-accent-400 font-bold text-lg mt-1">
            {image.savings > 0 ? `-${image.savings}%` : '0%'}
          </span>
        </div>
        <div className="space-y-1 text-right">
          <div className="text-surface-500">Optimized</div>
          <div className="text-white font-medium">
            {image.optimized.width} x {image.optimized.height}
          </div>
          <div className="text-accent-400 font-medium">{formatBytes(image.optimized.size)}</div>
        </div>
      </div>
    </div>
  );
};

export const ImageOptimizerView = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const {
    settings,
    updateSettings,
    images,
    processing,
    processImages,
    removeImage,
    clearAll,
    downloadImage,
    downloadAll,
    reprocessAll,
  } = useImageOptimizer();

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const files = Array.from(e.dataTransfer.files);
      processImages(files);
    },
    [processImages]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = Array.from(e.target.files || []);
      processImages(files);
      if (fileInputRef.current) fileInputRef.current.value = '';
    },
    [processImages]
  );

  const totalSavings = images.reduce(
    (acc, img) => ({
      original: acc.original + img.original.size,
      optimized: acc.optimized + img.optimized.size,
    }),
    { original: 0, optimized: 0 }
  );

  const overallSavings =
    totalSavings.original > 0
      ? Math.round(((totalSavings.original - totalSavings.optimized) / totalSavings.original) * 100)
      : 0;

  return (
    <div className="pt-24 pb-32 px-4 max-w-4xl mx-auto animate-fade-in">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileSelect}
        className="hidden"
      />

      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-accent-500/20 to-teal-500/10 border border-accent-500/20 flex items-center justify-center">
            <Sparkles size={18} className="text-accent-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Image Optimizer</h1>
            <p className="text-sm text-surface-500">Compress and convert images with precision</p>
          </div>
        </div>
      </div>

      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
        className={`relative group cursor-pointer rounded-3xl border-2 border-dashed transition-all duration-300 ${
          isDragging
            ? 'border-accent-500 bg-accent-500/10'
            : 'border-white/10 hover:border-white/20 bg-surface-900/30 hover:bg-surface-900/50'
        }`}
      >
        <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-accent-500/5 to-teal-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        <div className="relative p-12 flex flex-col items-center text-center">
          <div className={`w-20 h-20 rounded-3xl flex items-center justify-center mb-6 transition-all duration-300 ${
            isDragging
              ? 'bg-accent-500/20 scale-110'
              : 'bg-surface-800/60 group-hover:bg-surface-800'
          }`}>
            <Upload
              size={32}
              className={`transition-colors duration-300 ${
                isDragging ? 'text-accent-400' : 'text-surface-400 group-hover:text-white'
              }`}
            />
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">
            {isDragging ? 'Drop images here' : 'Upload Images'}
          </h3>
          <p className="text-sm text-surface-500 max-w-xs">
            Drag and drop your images here, or click to browse. Supports JPEG, PNG, WebP.
          </p>
        </div>
      </div>

      <div className="mt-6 flex items-center justify-between">
        <button
          onClick={() => setShowSettings(!showSettings)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all duration-200 ${
            showSettings
              ? 'bg-accent-500/10 text-accent-400 border border-accent-500/30'
              : 'bg-surface-900/60 text-surface-400 border border-white/5 hover:text-white hover:bg-surface-800/60'
          }`}
        >
          <Settings2 size={16} />
          <span className="text-sm font-medium">Settings</span>
          <ChevronDown
            size={14}
            className={`transition-transform duration-200 ${showSettings ? 'rotate-180' : ''}`}
          />
        </button>

        {images.length > 0 && (
          <div className="flex items-center gap-3">
            <button
              onClick={reprocessAll}
              disabled={processing}
              className="flex items-center gap-2 px-4 py-2.5 bg-surface-900/60 border border-white/5 rounded-xl text-surface-400 hover:text-white hover:bg-surface-800/60 transition-all text-sm font-medium disabled:opacity-50"
            >
              <RefreshCw size={14} className={processing ? 'animate-spin' : ''} />
              Reprocess
            </button>
            <button
              onClick={downloadAll}
              className="btn-primary text-sm py-2.5 flex items-center gap-2"
            >
              <Download size={14} />
              Download All
            </button>
          </div>
        )}
      </div>

      {showSettings && (
        <div className="mt-4 p-6 glass rounded-3xl space-y-6 animate-slide-down">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Slider
              label="Quality"
              value={settings.quality}
              min={10}
              max={100}
              onChange={(quality) => updateSettings({ quality })}
              unit="%"
            />
            <Slider
              label="Max Width"
              value={settings.maxWidth}
              min={320}
              max={4096}
              onChange={(maxWidth) => updateSettings({ maxWidth })}
              unit="px"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Slider
              label="Max Height"
              value={settings.maxHeight}
              min={320}
              max={4096}
              onChange={(maxHeight) => updateSettings({ maxHeight })}
              unit="px"
            />
            <div className="space-y-3">
              <span className="text-sm font-medium text-surface-300">Aspect Ratio</span>
              <button
                onClick={() => updateSettings({ preserveAspectRatio: !settings.preserveAspectRatio })}
                className={`w-full p-3 rounded-xl border flex items-center justify-between transition-all duration-200 ${
                  settings.preserveAspectRatio
                    ? 'bg-accent-500/10 border-accent-500/30 text-white'
                    : 'bg-surface-900/40 border-white/5 text-surface-400'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Maximize2 size={16} />
                  <span className="text-sm font-medium">Preserve Ratio</span>
                </div>
                <div
                  className={`w-10 h-6 rounded-full p-1 transition-colors duration-200 ${
                    settings.preserveAspectRatio ? 'bg-accent-500' : 'bg-surface-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white shadow transition-transform duration-200 ${
                      settings.preserveAspectRatio ? 'translate-x-4' : ''
                    }`}
                  />
                </div>
              </button>
            </div>
          </div>
          <FormatSelector value={settings.format} onChange={(format) => updateSettings({ format })} />
        </div>
      )}

      {images.length > 0 && (
        <div className="mt-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <h2 className="text-lg font-semibold text-white">
                Processed <span className="text-accent-400">({images.length})</span>
              </h2>
              {overallSavings > 0 && (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-accent-500/10 border border-accent-500/20 rounded-full">
                  <Zap size={12} className="text-accent-400 fill-accent-400" />
                  <span className="text-xs font-bold text-accent-400">
                    {formatBytes(totalSavings.original - totalSavings.optimized)} saved ({overallSavings}%)
                  </span>
                </div>
              )}
            </div>
            <button
              onClick={clearAll}
              className="flex items-center gap-2 px-3 py-1.5 text-surface-500 hover:text-red-400 text-sm transition-colors"
            >
              <Trash2 size={14} />
              Clear All
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {images.map((image, index) => (
              <ImageCard
                key={index}
                image={image}
                onRemove={() => removeImage(index)}
                onDownload={() => downloadImage(image)}
              />
            ))}
          </div>
        </div>
      )}

      {processing && (
        <div className="fixed inset-0 bg-surface-950/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="glass rounded-3xl p-8 text-center animate-scale-in">
            <div className="w-16 h-16 rounded-2xl bg-accent-500/20 flex items-center justify-center mx-auto mb-4">
              <RefreshCw size={28} className="text-accent-400 animate-spin" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Optimizing...</h3>
            <p className="text-sm text-surface-500">Please wait while we process your images</p>
          </div>
        </div>
      )}

      {images.length === 0 && !processing && (
        <div className="mt-16 text-center">
          <div className="w-20 h-20 rounded-3xl bg-surface-900/40 border border-white/5 flex items-center justify-center mx-auto mb-6">
            <FileImage size={32} className="text-surface-600" />
          </div>
          <h3 className="text-lg font-medium text-surface-400 mb-2">No images yet</h3>
          <p className="text-sm text-surface-600 max-w-xs mx-auto">
            Upload images to start optimizing. Your optimized images will appear here.
          </p>
        </div>
      )}
    </div>
  );
};
