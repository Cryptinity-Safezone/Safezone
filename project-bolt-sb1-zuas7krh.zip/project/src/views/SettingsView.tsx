import { useState } from 'react';
import {
  User, Mail, Lock, LogOut, Trash2, Shield, Eye, Volume2,
  Info, Users, FileText, MessageCircle, ChevronRight, AlertTriangle,
  VolumeX, Activity, ArrowLeft, ShieldCheck, Wand2, Play, Loader2,
  Clock, Sparkles, Lock as LockIcon, AtSign, BellOff, Settings, Zap
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useProfile } from '../hooks/useProfile';
import { useSettings } from '../hooks/useSettings';
import { useBlockedUsers } from '../hooks/useBlockedUsers';
import { useMutedUsers } from '../hooks/useMutedUsers';
import { useReports } from '../hooks/useReports';
import { useSound } from '../contexts/SoundContext';
import { useAISounds, AMBIENT_SOUNDSCAPE_TYPES, SoundscapeType } from '../hooks/useAISounds';
import { useCTY } from '../hooks/useCTY';
import { useAdmin } from '../hooks/useAdmin';
import { useAdminGrant } from '../hooks/useAdminGrant';
import { EditProfileModal } from '../components/profile/EditProfileModal';
import { supabase } from '../lib/supabase';

export function SettingsView() {
  const { user, signOut } = useAuth();
  const { profile } = useProfile(user?.id);
  const { settings, updateSettings } = useSettings();
  const { blockedUsers, unblockUser } = useBlockedUsers();
  const { mutedUsers, unmuteUser: unmuteMentions, toggleMentions } = useMutedUsers();
  const { reports } = useReports();
  const { isPlaying, volume, toggleSound, setVolume } = useSound();
  const { sounds, generating, error: aiError, generateSound, deleteSound, getCost, clearError } = useAISounds();
  const { balance, refresh: refreshBalance } = useCTY();
  const { isAdmin } = useAdmin();
  const { grantCTY, granting, error: grantError, success: grantSuccess, clearMessages } = useAdminGrant();

  const [activeSection, setActiveSection] = useState<string>('account');
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showChangeEmail, setShowChangeEmail] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [showDeleteAccount, setShowDeleteAccount] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [showCTYInfo, setShowCTYInfo] = useState(false);
  const [showGuidelines, setShowGuidelines] = useState(false);
  const [showAIGenerator, setShowAIGenerator] = useState(false);
  const [selectedSoundscape, setSelectedSoundscape] = useState<SoundscapeType>('deep_ocean');
  const [selectedDuration, setSelectedDuration] = useState<'short' | 'extended'>('short');

  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [deleteConfirmation, setDeleteConfirmation] = useState('');

  const sections = [
    { id: 'account', label: 'Account', icon: User },
    { id: 'privacy', label: 'Privacy & Safety', icon: Shield },
    { id: 'sound', label: 'Sound & Experience', icon: Volume2 },
    { id: 'about', label: 'About & Support', icon: Info },
    ...(isAdmin ? [{ id: 'admin', label: 'Admin Panel', icon: Settings }] : [])
  ];

  const handleChangeEmail = async () => {
    if (!newEmail) return;
    try {
      const { error } = await supabase.auth.updateUser({ email: newEmail });
      if (error) throw error;
      alert('Email update initiated. Please check your inbox for confirmation.');
      setShowChangeEmail(false);
      setNewEmail('');
    } catch (error: any) {
      alert(error.message);
    }
  };

  const handleChangePassword = async () => {
    if (newPassword !== confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    if (newPassword.length < 6) {
      alert('Password must be at least 6 characters');
      return;
    }
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      alert('Password updated successfully');
      setShowChangePassword(false);
      setNewPassword('');
      setConfirmPassword('');
    } catch (error: any) {
      alert(error.message);
    }
  };

  const handleDeleteAccount = async () => {
    if (deleteConfirmation !== 'DELETE') {
      alert('Please type DELETE to confirm');
      return;
    }
    alert('Account deletion request submitted. This feature requires admin approval.');
    setShowDeleteAccount(false);
    setDeleteConfirmation('');
  };

  const navigateBack = () => {
    window.dispatchEvent(new CustomEvent('navigate', { detail: 'feed' }));
  };

  return (
    <div className="min-h-screen pb-20">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={navigateBack}
            className="p-2 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-bold text-white">Settings</h1>
        </div>

        <div className="grid md:grid-cols-[240px,1fr] gap-6">
          {/* Sidebar Navigation */}
          <nav className="space-y-1">
            {sections.map(section => {
              const Icon = section.icon;
              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeSection === section.id
                      ? 'bg-white/10 text-white'
                      : 'text-gray-400 hover:bg-white/5 hover:text-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{section.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Content Area */}
          <div className="space-y-6">
            {/* Account Section */}
            {activeSection === 'account' && (
              <div className="space-y-4">
                <SettingsCard
                  icon={User}
                  title="Edit Profile"
                  description="Update your profile information"
                  onClick={() => setShowEditProfile(true)}
                />
                <SettingsCard
                  icon={Mail}
                  title="Change Email"
                  description={user?.email}
                  onClick={() => setShowChangeEmail(true)}
                />
                <SettingsCard
                  icon={Lock}
                  title="Change Password"
                  description="Update your password"
                  onClick={() => setShowChangePassword(true)}
                />
                <SettingsCard
                  icon={LogOut}
                  title="Logout"
                  description="Sign out of your account"
                  onClick={signOut}
                />
                <SettingsCard
                  icon={Trash2}
                  title="Delete Account"
                  description="Permanently delete your account"
                  onClick={() => setShowDeleteAccount(true)}
                  danger
                />
              </div>
            )}

            {/* Privacy & Safety Section */}
            {activeSection === 'privacy' && (
              <div className="space-y-6">
                <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center gap-3 mb-4">
                    <MessageCircle className="w-5 h-5 text-teal-400" />
                    <h3 className="text-lg font-semibold text-white">Who can message me</h3>
                  </div>
                  <div className="space-y-2">
                    <label className="flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:bg-white/5 transition-colors">
                      <input
                        type="radio"
                        name="messaging"
                        checked={settings?.messaging_preference === 'message_requests'}
                        onChange={() => updateSettings({ messaging_preference: 'message_requests' })}
                        className="w-4 h-4 text-teal-500 accent-teal-500"
                      />
                      <div>
                        <div className="text-white font-medium">Message Requests</div>
                        <div className="text-sm text-gray-400">Anyone can send you message requests</div>
                      </div>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:bg-white/5 transition-colors">
                      <input
                        type="radio"
                        name="messaging"
                        checked={settings?.messaging_preference === 'mutual_followers'}
                        onChange={() => updateSettings({ messaging_preference: 'mutual_followers' })}
                        className="w-4 h-4 text-teal-500 accent-teal-500"
                      />
                      <div>
                        <div className="text-white font-medium">Mutual Followers Only</div>
                        <div className="text-sm text-gray-400">Only mutual followers can message you</div>
                      </div>
                    </label>
                  </div>
                </div>

                <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center gap-3 mb-4">
                    <Eye className="w-5 h-5 text-teal-400" />
                    <h3 className="text-lg font-semibold text-white">Who can see my posts</h3>
                  </div>
                  <div className="space-y-2">
                    <label className="flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:bg-white/5 transition-colors">
                      <input
                        type="radio"
                        name="visibility"
                        checked={settings?.post_visibility === 'everyone'}
                        onChange={() => updateSettings({ post_visibility: 'everyone' })}
                        className="w-4 h-4 text-teal-500 accent-teal-500"
                      />
                      <div>
                        <div className="text-white font-medium">Everyone</div>
                        <div className="text-sm text-gray-400">Anyone can see your posts</div>
                      </div>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:bg-white/5 transition-colors">
                      <input
                        type="radio"
                        name="visibility"
                        checked={settings?.post_visibility === 'followers_only'}
                        onChange={() => updateSettings({ post_visibility: 'followers_only' })}
                        className="w-4 h-4 text-teal-500 accent-teal-500"
                      />
                      <div>
                        <div className="text-white font-medium">Followers Only</div>
                        <div className="text-sm text-gray-400">Only your followers can see your posts</div>
                      </div>
                    </label>
                  </div>
                </div>

                <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center gap-3 mb-4">
                    <Users className="w-5 h-5 text-teal-400" />
                    <h3 className="text-lg font-semibold text-white">Blocked Users</h3>
                  </div>
                  {blockedUsers.length === 0 ? (
                    <p className="text-gray-400 text-sm">No blocked users</p>
                  ) : (
                    <div className="space-y-2">
                      {blockedUsers.map(blocked => (
                        <div key={blocked.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                          <div className="flex items-center gap-3">
                            <img
                              src={blocked.blocked_user.avatar_url}
                              alt={blocked.blocked_user.username}
                              className="w-10 h-10 rounded-full"
                            />
                            <div>
                              <div className="text-white font-medium">{blocked.blocked_user.username}</div>
                              <div className="text-sm text-gray-400">{blocked.blocked_user.handle}</div>
                            </div>
                          </div>
                          <button
                            onClick={() => unblockUser(blocked.id)}
                            className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm transition-colors"
                          >
                            Unblock
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center gap-3 mb-4">
                    <BellOff className="w-5 h-5 text-teal-400" />
                    <h3 className="text-lg font-semibold text-white">Muted Mentions</h3>
                  </div>
                  <p className="text-sm text-gray-400 mb-4">
                    Users whose @mentions will not notify you
                  </p>
                  {mutedUsers.filter(m => m.mute_mentions).length === 0 ? (
                    <p className="text-gray-400 text-sm">No muted mentions</p>
                  ) : (
                    <div className="space-y-2">
                      {mutedUsers.filter(m => m.mute_mentions).map(muted => (
                        <div key={muted.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                          <div className="flex items-center gap-3">
                            <img
                              src={muted.muted_user?.avatar_url || `https://ui-avatars.com/api/?name=${muted.muted_user?.username}&background=0d9488&color=fff`}
                              alt={muted.muted_user?.username || 'User'}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                            <div>
                              <div className="text-white font-medium">{muted.muted_user?.username}</div>
                              <div className="text-sm text-gray-400 flex items-center gap-1">
                                <AtSign size={12} />
                                {muted.muted_user?.handle}
                              </div>
                            </div>
                          </div>
                          <button
                            onClick={() => unmuteMentions(muted.id)}
                            className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm transition-colors"
                          >
                            Unmute
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center gap-3 mb-4">
                    <FileText className="w-5 h-5 text-teal-400" />
                    <h3 className="text-lg font-semibold text-white">Reports I've Submitted</h3>
                  </div>
                  {reports.length === 0 ? (
                    <p className="text-gray-400 text-sm">No reports submitted</p>
                  ) : (
                    <div className="space-y-2">
                      {reports.map(report => (
                        <div key={report.id} className="p-4 rounded-lg bg-white/5 border border-white/10">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs font-medium text-teal-400 uppercase">{report.type} Report</span>
                            <span className={`text-xs px-2 py-1 rounded ${
                              report.status === 'pending' ? 'bg-yellow-500/20 text-yellow-300' :
                              report.status === 'resolved' ? 'bg-green-500/20 text-green-300' :
                              'bg-gray-500/20 text-gray-300'
                            }`}>
                              {report.status}
                            </span>
                          </div>
                          <div className="text-sm text-white mb-1">Reason: {report.reason}</div>
                          {report.details && (
                            <div className="text-sm text-gray-400">{report.details}</div>
                          )}
                          <div className="text-xs text-gray-500 mt-2">
                            {new Date(report.created_at).toLocaleDateString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Sound & Experience Section */}
            {activeSection === 'sound' && (
              <div className="space-y-4">
                <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${isPlaying ? 'bg-teal-500/20' : 'bg-white/10'}`}>
                        <Volume2 className={`w-5 h-5 ${isPlaying ? 'text-teal-400' : 'text-gray-400'}`} />
                      </div>
                      <div>
                        <div className="text-white font-medium">Background Sound</div>
                        <div className="text-sm text-gray-400">
                          {isPlaying ? 'Ambient sound is playing' : 'Enable ambient background sound'}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={toggleSound}
                      disabled={settings?.reduce_motion}
                      className={`px-4 py-2 rounded-lg font-medium text-sm transition-all ${
                        isPlaying
                          ? 'bg-teal-500/20 text-teal-400 hover:bg-teal-500/30'
                          : 'bg-white/10 text-white hover:bg-white/20'
                      } ${settings?.reduce_motion ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      {isPlaying ? 'Stop' : 'Play'}
                    </button>
                  </div>
                  {isPlaying && (
                    <div className="mt-4 flex items-center gap-2">
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <div
                            key={i}
                            className="w-1 bg-teal-400 rounded-full animate-pulse"
                            style={{
                              height: `${8 + Math.random() * 12}px`,
                              animationDelay: `${i * 0.1}s`
                            }}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-teal-400">Playing ambient soundscape</span>
                    </div>
                  )}
                </div>

                <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <Activity className="w-5 h-5 text-teal-400" />
                      <div>
                        <div className="text-white font-medium">Autoplay Sound</div>
                        <div className="text-sm text-gray-400">Play sound automatically when app loads</div>
                      </div>
                    </div>
                    <label className="relative inline-block w-12 h-6">
                      <input
                        type="checkbox"
                        checked={settings?.autoplay_sound || false}
                        onChange={(e) => updateSettings({ autoplay_sound: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-full h-full bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-6 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600"></div>
                    </label>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Note: Autoplay requires background sound to be enabled first
                  </p>
                </div>

                <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Volume2 className="w-5 h-5 text-teal-400" />
                      <div>
                        <div className="text-white font-medium">Master Volume</div>
                        <div className="text-sm text-gray-400">Adjust the overall volume level</div>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-teal-400 tabular-nums w-12 text-right">
                      {volume}%
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={volume}
                      onChange={(e) => setVolume(parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-teal-500"
                    />
                    <div className="flex justify-between mt-2 text-xs text-gray-500">
                      <span>0%</span>
                      <span>50%</span>
                      <span>100%</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <VolumeX className="w-5 h-5 text-teal-400" />
                      <div>
                        <div className="text-white font-medium">Reduce Motion & Sound</div>
                        <div className="text-sm text-gray-400">Minimize animations and sounds</div>
                      </div>
                    </div>
                    <label className="relative inline-block w-12 h-6">
                      <input
                        type="checkbox"
                        checked={settings?.reduce_motion || false}
                        onChange={(e) => updateSettings({ reduce_motion: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-full h-full bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-6 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600"></div>
                    </label>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Enabling this will stop all background sounds and reduce visual effects
                  </p>
                </div>

                <div className="bg-amber-500/5 rounded-lg p-5 border border-amber-500/20">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-amber-500/10 flex-shrink-0">
                      <ShieldCheck className="w-5 h-5 text-amber-400" />
                    </div>
                    <div>
                      <div className="text-amber-300 font-medium mb-1">Audio Copyright Policy</div>
                      <p className="text-sm text-amber-200/70 leading-relaxed">
                        Only original or AI-generated sounds are supported. Copyrighted music is not allowed.
                      </p>
                      <p className="text-xs text-amber-200/50 mt-2">
                        All ambient sounds are generated by our platform using Web Audio synthesis.
                        External music uploads are disabled to protect copyright holders.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-teal-500/10 to-cyan-500/10 rounded-lg p-6 border border-teal-500/20">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-teal-500/20">
                        <Wand2 className="w-5 h-5 text-teal-400" />
                      </div>
                      <div>
                        <div className="text-white font-medium">AI Ambient Sound Generator</div>
                        <div className="text-sm text-gray-400">Create unique non-vocal soundscapes</div>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowAIGenerator(!showAIGenerator)}
                      className="px-4 py-2 rounded-lg font-medium text-sm bg-teal-500/20 text-teal-400 hover:bg-teal-500/30 transition-all"
                    >
                      {showAIGenerator ? 'Close' : 'Generate'}
                    </button>
                  </div>

                  {showAIGenerator && (
                    <div className="mt-4 space-y-4 pt-4 border-t border-white/10">
                      <div className="flex items-center gap-2 text-xs text-cyan-400 bg-cyan-500/10 rounded-lg px-3 py-2">
                        <Sparkles className="w-4 h-4" />
                        <span>AI-generated ambient soundscapes - no vocals, no artist imitation</span>
                      </div>

                      {aiError && (
                        <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 text-red-400 text-sm flex items-center justify-between">
                          <span>{aiError}</span>
                          <button onClick={clearError} className="text-red-300 hover:text-white">&times;</button>
                        </div>
                      )}

                      <div>
                        <label className="block text-sm text-gray-400 mb-2">Soundscape Type</label>
                        <div className="grid grid-cols-2 gap-2">
                          {AMBIENT_SOUNDSCAPE_TYPES.map((type) => (
                            <button
                              key={type.id}
                              onClick={() => setSelectedSoundscape(type.id)}
                              className={`p-3 rounded-lg text-left transition-all ${
                                selectedSoundscape === type.id
                                  ? 'bg-teal-500/20 border-teal-500/50 border'
                                  : 'bg-white/5 border border-white/10 hover:bg-white/10'
                              }`}
                            >
                              <div className={`text-sm font-medium ${selectedSoundscape === type.id ? 'text-teal-300' : 'text-white'}`}>
                                {type.name}
                              </div>
                              <div className="text-xs text-gray-500 mt-0.5">{type.description}</div>
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm text-gray-400 mb-2">Duration</label>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setSelectedDuration('short')}
                            className={`flex-1 p-3 rounded-lg flex items-center justify-center gap-2 transition-all ${
                              selectedDuration === 'short'
                                ? 'bg-teal-500/20 border-teal-500/50 border text-teal-300'
                                : 'bg-white/5 border border-white/10 text-white hover:bg-white/10'
                            }`}
                          >
                            <Clock className="w-4 h-4" />
                            <span className="text-sm">30 seconds</span>
                            <span className="text-xs text-gray-500">({getCost('short')} CTY)</span>
                          </button>
                          <button
                            onClick={() => setSelectedDuration('extended')}
                            className={`flex-1 p-3 rounded-lg flex items-center justify-center gap-2 transition-all ${
                              selectedDuration === 'extended'
                                ? 'bg-teal-500/20 border-teal-500/50 border text-teal-300'
                                : 'bg-white/5 border border-white/10 text-white hover:bg-white/10'
                            }`}
                          >
                            <Clock className="w-4 h-4" />
                            <span className="text-sm">2 minutes</span>
                            <span className="text-xs text-gray-500">({getCost('extended')} CTY)</span>
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-2 text-sm text-gray-400">
                          <LockIcon className="w-4 h-4" />
                          <span>Generated sounds are private by default</span>
                        </div>
                        <div className="text-sm text-teal-400">
                          Your balance: <span className="font-medium">{balance} CTY</span>
                        </div>
                      </div>

                      <button
                        onClick={() => generateSound({ soundscapeType: selectedSoundscape, duration: selectedDuration })}
                        disabled={generating || balance < getCost(selectedDuration)}
                        className={`w-full py-3 rounded-lg font-medium flex items-center justify-center gap-2 transition-all ${
                          generating || balance < getCost(selectedDuration)
                            ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                            : 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white hover:from-teal-400 hover:to-cyan-400'
                        }`}
                      >
                        {generating ? (
                          <>
                            <Loader2 className="w-5 h-5 animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Wand2 className="w-5 h-5" />
                            Generate for {getCost(selectedDuration)} CTY
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>

                {sounds.length > 0 && (
                  <div className="bg-white/5 rounded-lg p-6 backdrop-blur-sm border border-white/10">
                    <div className="flex items-center gap-2 mb-4">
                      <Sparkles className="w-5 h-5 text-teal-400" />
                      <span className="text-white font-medium">Your AI-Generated Sounds</span>
                      <span className="text-xs text-gray-500 ml-auto">AI-generated</span>
                    </div>
                    <div className="space-y-2">
                      {sounds.slice(0, 5).map((sound) => (
                        <div
                          key={sound.id}
                          className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
                        >
                          <div className="flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-teal-500/20">
                              <Play className="w-4 h-4 text-teal-400" />
                            </div>
                            <div>
                              <div className="text-white text-sm font-medium">{sound.name}</div>
                              <div className="text-xs text-gray-500 flex items-center gap-2">
                                <span>{sound.duration_seconds}s</span>
                                <span className="text-teal-500">AI-generated</span>
                                {sound.is_private && (
                                  <span className="flex items-center gap-1 text-amber-500">
                                    <LockIcon className="w-3 h-3" />
                                    Private
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                          <button
                            onClick={() => deleteSound(sound.id)}
                            className="text-gray-500 hover:text-red-400 transition-colors p-2"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* About & Support Section */}
            {activeSection === 'about' && (
              <div className="space-y-4">
                <SettingsCard
                  icon={Info}
                  title="About Cryptinity"
                  description="Learn about our platform"
                  onClick={() => setShowAbout(true)}
                />
                <SettingsCard
                  icon={Activity}
                  title="What is CTY⚡"
                  description="Understanding Cryptinity's energy system"
                  onClick={() => setShowCTYInfo(true)}
                />
                <SettingsCard
                  icon={FileText}
                  title="Community Guidelines"
                  description="Read our community rules"
                  onClick={() => setShowGuidelines(true)}
                />
                <SettingsCard
                  icon={MessageCircle}
                  title="Contact Support"
                  description="Get help with your account"
                  onClick={() => window.open('mailto:support@cryptinity.com', '_blank')}
                />
              </div>
            )}

            {/* Admin Panel Section */}
            {activeSection === 'admin' && isAdmin && (
              <div className="space-y-4">
                <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 rounded-lg p-6 border border-orange-500/20">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-lg bg-orange-500/20">
                      <ShieldCheck className="w-6 h-6 text-orange-400" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">Admin Panel</h3>
                      <p className="text-sm text-orange-300/70">Testing and development tools</p>
                    </div>
                  </div>

                  <div className="bg-black/20 rounded-lg p-4 mb-4">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm text-gray-300">Current Balance</span>
                      <div className="flex items-center gap-2">
                        <Zap size={16} className="text-accent-400" />
                        <span className="text-lg font-semibold text-white">{balance} CTY</span>
                      </div>
                    </div>
                  </div>

                  {grantError && (
                    <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 mb-4 flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <AlertTriangle size={16} className="text-red-400 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-red-300">{grantError}</span>
                      </div>
                      <button onClick={clearMessages} className="text-red-400 hover:text-red-300">×</button>
                    </div>
                  )}

                  {grantSuccess && (
                    <div className="bg-teal-500/10 border border-teal-500/20 rounded-lg p-3 mb-4 flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <ShieldCheck size={16} className="text-teal-400 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-teal-300">{grantSuccess}</span>
                      </div>
                      <button onClick={clearMessages} className="text-teal-400 hover:text-teal-300">×</button>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-3">Grant Test CTY</label>
                    <div className="grid grid-cols-3 gap-3">
                      {[100, 500, 1000].map((amount) => (
                        <button
                          key={amount}
                          onClick={async () => {
                            const newBalance = await grantCTY(amount);
                            if (newBalance !== null) {
                              await refreshBalance();
                            }
                          }}
                          disabled={granting}
                          className="flex flex-col items-center gap-2 p-4 rounded-lg bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-500/30 hover:from-orange-500/30 hover:to-red-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <Zap size={20} className="text-orange-400" />
                          <span className="text-sm font-medium text-white">{amount} CTY</span>
                        </button>
                      ))}
                    </div>
                    {granting && (
                      <div className="flex items-center justify-center gap-2 mt-4 text-sm text-gray-400">
                        <Loader2 size={16} className="animate-spin" />
                        <span>Processing grant...</span>
                      </div>
                    )}
                  </div>

                  <div className="mt-6 pt-4 border-t border-white/10">
                    <p className="text-xs text-orange-300/50 leading-relaxed">
                      This admin panel is for testing purposes only. All grants are logged in cty_transactions with reason "admin_test_grant". Remember to disable this feature before public launch by setting enableAdminFeatures to false in admin-config.ts.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modals */}
      {showEditProfile && (
        <EditProfileModal
          profile={profile!}
          onClose={() => setShowEditProfile(false)}
        />
      )}

      {showChangeEmail && (
        <Modal onClose={() => setShowChangeEmail(false)} title="Change Email">
          <div className="space-y-4">
            <input
              type="email"
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              placeholder="New email address"
              className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-400 focus:outline-none focus:border-teal-500"
            />
            <button
              onClick={handleChangeEmail}
              className="w-full py-3 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-medium transition-colors"
            >
              Update Email
            </button>
          </div>
        </Modal>
      )}

      {showChangePassword && (
        <Modal onClose={() => setShowChangePassword(false)} title="Change Password">
          <div className="space-y-4">
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="New password"
              className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-400 focus:outline-none focus:border-teal-500"
            />
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm password"
              className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-400 focus:outline-none focus:border-teal-500"
            />
            <button
              onClick={handleChangePassword}
              className="w-full py-3 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-medium transition-colors"
            >
              Update Password
            </button>
          </div>
        </Modal>
      )}

      {showDeleteAccount && (
        <Modal onClose={() => setShowDeleteAccount(false)} title="Delete Account">
          <div className="space-y-4">
            <div className="flex items-start gap-3 p-4 rounded-lg bg-red-500/10 border border-red-500/20">
              <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-red-300">
                This action cannot be undone. All your data will be permanently deleted.
              </div>
            </div>
            <input
              type="text"
              value={deleteConfirmation}
              onChange={(e) => setDeleteConfirmation(e.target.value)}
              placeholder="Type DELETE to confirm"
              className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-400 focus:outline-none focus:border-red-500"
            />
            <button
              onClick={handleDeleteAccount}
              disabled={deleteConfirmation !== 'DELETE'}
              className="w-full py-3 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Delete Account
            </button>
          </div>
        </Modal>
      )}

      {showAbout && (
        <Modal onClose={() => setShowAbout(false)} title="About Cryptinity">
          <div className="space-y-4 text-gray-300">
            <p>Cryptinity is a social platform where creativity meets community. Share your passions, connect with others, and grow your presence in a vibrant digital space.</p>
            <p className="text-sm text-gray-400">Version 1.0.0</p>
          </div>
        </Modal>
      )}

      {showCTYInfo && (
        <Modal onClose={() => setShowCTYInfo(false)} title="What is CTY⚡">
          <div className="space-y-4 text-gray-300">
            <p>CTY (Cryptinity) is our platform's energy currency. Use CTY to unlock premium features, boost your posts, and access exclusive content.</p>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                <span>Create Post</span>
                <span className="text-teal-400 font-medium">10 CTY</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                <span>Image Optimization</span>
                <span className="text-teal-400 font-medium">20 CTY</span>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {showGuidelines && (
        <Modal onClose={() => setShowGuidelines(false)} title="Community Guidelines">
          <div className="space-y-4 text-gray-300">
            <div>
              <h3 className="text-white font-semibold mb-2">1. Be Respectful</h3>
              <p className="text-sm">Treat all community members with respect and kindness.</p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-2">2. No Harassment</h3>
              <p className="text-sm">Harassment, bullying, or hate speech of any kind is not tolerated.</p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-2">3. Keep it Safe</h3>
              <p className="text-sm">Do not share content that is illegal, harmful, or inappropriate.</p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-2">4. Be Authentic</h3>
              <p className="text-sm">Use your real identity and don't impersonate others.</p>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function SettingsCard({
  icon: Icon,
  title,
  description,
  onClick,
  danger = false
}: {
  icon: any;
  title: string;
  description: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center justify-between p-4 rounded-lg backdrop-blur-sm border transition-colors ${
        danger
          ? 'bg-red-500/5 border-red-500/20 hover:bg-red-500/10'
          : 'bg-white/5 border-white/10 hover:bg-white/10'
      }`}
    >
      <div className="flex items-center gap-4">
        <div className={`p-2 rounded-lg ${danger ? 'bg-red-500/20' : 'bg-white/10'}`}>
          <Icon className={`w-5 h-5 ${danger ? 'text-red-400' : 'text-teal-400'}`} />
        </div>
        <div className="text-left">
          <div className={`font-medium ${danger ? 'text-red-300' : 'text-white'}`}>{title}</div>
          <div className="text-sm text-gray-400">{description}</div>
        </div>
      </div>
      <ChevronRight className={`w-5 h-5 ${danger ? 'text-red-400' : 'text-gray-400'}`} />
    </button>
  );
}

function Modal({
  children,
  onClose,
  title
}: {
  children: React.ReactNode;
  onClose: () => void;
  title: string;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 rounded-lg p-6 border border-white/10">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white">{title}</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
          >
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
