import { useState, useEffect, useCallback, useRef } from 'react';
import { Background } from './components/Background';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { Sidebar } from './components/Sidebar';
import { OnboardingScreen } from './components/onboarding/OnboardingScreen';
import { SplashScreen } from './components/SplashScreen';
import { SoundControl } from './components/sound/SoundControl';
import { SoundProvider } from './contexts/SoundContext';
import { FeedView } from './views/FeedView';
import { ExploreView } from './views/ExploreView';
import { ImageOptimizerView } from './views/ImageOptimizerView';
import { WarehouseView } from './views/WarehouseView';
import { ProfileView } from './views/ProfileView';
import { AboutView } from './views/AboutView';
import { UpgradeView } from './views/UpgradeView';
import { MessagesView } from './views/MessagesView';
import { SettingsView } from './views/SettingsView';
import { HelpCenterView } from './views/HelpCenterView';
import { CreateView } from './views/CreateView';
import { HiddenGardenView } from './views/HiddenGardenView';
import { LoginView, RegisterView, ForgotPasswordView } from './views/auth';
import { useAuth } from './contexts/AuthContext';
import { supabase } from './lib/supabase';
import type { ViewState, AuthView, UserProfile } from './types';

const DEFAULT_AVATAR = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cdefs%3E%3ClinearGradient id='bg' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%230d9488'/%3E%3Cstop offset='100%25' style='stop-color:%2310b981'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='100' height='100' rx='20' fill='url(%23bg)'/%3E%3Ctext x='50' y='65' font-family='system-ui,-apple-system,sans-serif' font-size='48' font-weight='600' fill='white' text-anchor='middle'%3EC%3C/text%3E%3C/svg%3E";

const App = () => {
  const { user, profile, loading: authLoading } = useAuth();
  const [splashLoading, setSplashLoading] = useState(true);
  const [authView, setAuthView] = useState<AuthView>('login');
  const [view, setView] = useState<ViewState>('feed');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewingUserId, setViewingUserId] = useState<string | null>(null);
  const [showGarden, setShowGarden] = useState(false);

  const touchStartX = useRef(0);
  const touchStartY = useRef(0);

  useEffect(() => {
    const maxSplashTime = setTimeout(() => {
      setSplashLoading(false);
    }, 4000);
    return () => clearTimeout(maxSplashTime);
  }, []);

  useEffect(() => {
    const handleNavigate = (e: CustomEvent<ViewState>) => {
      setView(e.detail);
      if (e.detail === 'profile') {
        setViewingUserId(null);
      }
    };
    const handleViewProfile = (e: CustomEvent<string>) => {
      setViewingUserId(e.detail);
      setView('profile');
    };
    const handleOpenGarden = () => {
      setShowGarden(true);
    };
    window.addEventListener('navigate', handleNavigate as EventListener);
    window.addEventListener('view-profile', handleViewProfile as EventListener);
    window.addEventListener('open-garden', handleOpenGarden as EventListener);
    return () => {
      window.removeEventListener('navigate', handleNavigate as EventListener);
      window.removeEventListener('view-profile', handleViewProfile as EventListener);
      window.removeEventListener('open-garden', handleOpenGarden as EventListener);
    };
  }, []);

  const handleTouchStart = useCallback((e: TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  }, []);

  const handleTouchEnd = useCallback((e: TouchEvent) => {
    const touchEndX = e.changedTouches[0].clientX;
    const touchEndY = e.changedTouches[0].clientY;
    const deltaX = touchEndX - touchStartX.current;
    const deltaY = Math.abs(touchEndY - touchStartY.current);

    if (touchStartX.current < 30 && deltaX > 60 && deltaY < 100 && !sidebarOpen) {
      setSidebarOpen(true);
    }
  }, [sidebarOpen]);

  useEffect(() => {
    document.addEventListener('touchstart', handleTouchStart, { passive: true });
    document.addEventListener('touchend', handleTouchEnd, { passive: true });
    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchend', handleTouchEnd);
    };
  }, [handleTouchStart, handleTouchEnd]);

  if (splashLoading) {
    return <SplashScreen onComplete={() => setSplashLoading(false)} />;
  }

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Background />
        <div className="relative z-10">
          <div className="w-16 h-16 rounded-3xl bg-white/[0.02] border border-white/[0.04] flex items-center justify-center mx-auto mb-4">
            <div className="w-8 h-8 border-2 border-accent-400/30 border-t-accent-400 rounded-full animate-spin" />
          </div>
          <p className="text-sm text-surface-600/70 font-light text-center">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user || !profile) {
    return (
      <>
        {authView === 'login' && <LoginView onNavigate={setAuthView} />}
        {authView === 'register' && <RegisterView onNavigate={setAuthView} />}
        {authView === 'forgot' && <ForgotPasswordView onNavigate={setAuthView} />}
      </>
    );
  }

  const handleOnboardingComplete = async () => {
    try {
      await supabase
        .from('user_profiles')
        .update({ onboarding_completed: true })
        .eq('id', profile.id);

      window.location.reload();
    } catch (error) {
      console.error('Error completing onboarding:', error);
    }
  };

  if (!profile.onboarding_completed) {
    return <OnboardingScreen onComplete={handleOnboardingComplete} />;
  }

  const userProfile: UserProfile = {
    uid: profile.id,
    username: profile.username,
    handle: profile.handle,
    avatar: profile.avatar_url || DEFAULT_AVATAR,
    cover: profile.cover_url || null,
    plan: profile.plan_type,
    ctyBalance: profile.cty_balance,
    isVerified: profile.is_verified,
    isRestricted: profile.is_restricted,
    followers: profile.followers_count,
    following: profile.following_count,
    creations: profile.creations_count,
    bio: profile.bio || undefined,
    interests: profile.interests,
    backgroundMusic: profile.background_music_url
      ? {
          title: profile.background_music_title || '',
          artist: profile.background_music_artist || '',
          url: profile.background_music_url,
        }
      : undefined,
  };

  const showHeader = view !== 'profile' && view !== 'settings';
  const showSoundControl = view === 'feed' || view === 'profile';

  return (
    <SoundProvider>
      <div className="min-h-screen font-sans overflow-x-hidden">
        <Background />

        <Sidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          currentView={view}
          onNavigate={setView}
        />

        {showHeader && (
          <Header
            onUpgradeClick={() => setView('upgrade')}
            onSettingsClick={() => setView('settings')}
            onMenuClick={() => setSidebarOpen(true)}
          />
        )}

        <main className="relative z-10 w-full max-w-full overflow-x-hidden">
          {view === 'feed' && <FeedView />}
          {view === 'explore' && <ExploreView />}
          {view === 'optimizer' && <ImageOptimizerView />}
          {view === 'warehouse' && <WarehouseView />}
          {view === 'profile' && <ProfileView user={userProfile} viewingUserId={viewingUserId} />}
          {view === 'about' && <AboutView />}
          {view === 'upgrade' && <UpgradeView />}
          {view === 'messages' && <MessagesView />}
          {view === 'settings' && <SettingsView />}
          {view === 'help' && <HelpCenterView />}
          {view === 'create' && <CreateView />}
        </main>

        {showSoundControl && <SoundControl position="bottom-left" />}

        <Navigation view={view} onViewChange={(newView) => {
          setView(newView);
          if (newView === 'profile') {
            setViewingUserId(null);
          }
        }} />

        {showGarden && (
          <HiddenGardenView onClose={() => setShowGarden(false)} />
        )}
      </div>
    </SoundProvider>
  );
};

export default App;
