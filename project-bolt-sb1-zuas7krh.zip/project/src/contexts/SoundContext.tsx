/**
 * Audio Copyright Policy Enforcement
 *
 * IMPORTANT: This module ONLY uses platform-generated audio via Web Audio API.
 * External music file uploads are NOT supported and must remain disabled.
 *
 * Allowed audio sources:
 * - Platform-provided ambient tracks (Web Audio synthesis)
 * - AI-generated audio
 *
 * NOT allowed:
 * - User-uploaded music files
 * - Copyrighted/licensed songs
 * - External audio URLs
 */
import { createContext, useContext, useState, useEffect, useRef, useCallback, ReactNode } from 'react';
import { useSettings } from '../hooks/useSettings';

interface SoundContextType {
  isPlaying: boolean;
  volume: number;
  isMuted: boolean;
  isInitialized: boolean;
  toggleSound: () => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  fadeIn: () => void;
  fadeOut: () => void;
}

const SoundContext = createContext<SoundContextType | null>(null);

const FADE_DURATION = 2000;

export function SoundProvider({ children }: { children: ReactNode }) {
  const { settings, updateSettings } = useSettings();
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolumeState] = useState(50);
  const [isMuted, setIsMuted] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const nodesRef = useRef<OscillatorNode[]>([]);
  const fadeIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (settings) {
      setVolumeState(settings.master_volume);
      if (settings.reduce_motion) {
        stopSound();
      }
    }
  }, [settings]);

  useEffect(() => {
    if (settings?.autoplay_sound && settings?.background_sound_enabled && !isPlaying && !settings?.reduce_motion) {
      const handleFirstInteraction = () => {
        if (!isInitialized) {
          createAmbientSound();
        }
        setTimeout(() => {
          setIsPlaying(true);
          fadeIn();
        }, 500);
        document.removeEventListener('click', handleFirstInteraction);
        document.removeEventListener('touchstart', handleFirstInteraction);
      };

      document.addEventListener('click', handleFirstInteraction, { once: true });
      document.addEventListener('touchstart', handleFirstInteraction, { once: true });

      return () => {
        document.removeEventListener('click', handleFirstInteraction);
        document.removeEventListener('touchstart', handleFirstInteraction);
      };
    }
  }, [settings?.autoplay_sound, settings?.background_sound_enabled, settings?.reduce_motion]);

  const createAmbientSound = useCallback(() => {
    if (audioContextRef.current) return;

    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioContextClass();
    audioContextRef.current = ctx;

    const masterGain = ctx.createGain();
    masterGain.gain.value = 0;
    masterGain.connect(ctx.destination);
    gainNodeRef.current = masterGain;

    const frequencies = [
      { freq: 60, gain: 0.15, type: 'sine' as OscillatorType },
      { freq: 90, gain: 0.1, type: 'sine' as OscillatorType },
      { freq: 120, gain: 0.08, type: 'sine' as OscillatorType },
      { freq: 180, gain: 0.05, type: 'triangle' as OscillatorType },
      { freq: 240, gain: 0.03, type: 'sine' as OscillatorType },
    ];

    frequencies.forEach(({ freq, gain, type }) => {
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();

      osc.type = type;
      osc.frequency.value = freq;
      oscGain.gain.value = gain;

      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.frequency.value = 0.05 + Math.random() * 0.1;
      lfoGain.gain.value = freq * 0.02;
      lfo.connect(lfoGain);
      lfoGain.connect(osc.frequency);
      lfo.start();

      osc.connect(oscGain);
      oscGain.connect(masterGain);
      osc.start();

      nodesRef.current.push(osc);
    });

    const noiseBufferSize = ctx.sampleRate * 2;
    const noiseBuffer = ctx.createBuffer(1, noiseBufferSize, ctx.sampleRate);
    const noiseData = noiseBuffer.getChannelData(0);

    for (let i = 0; i < noiseBufferSize; i++) {
      noiseData[i] = (Math.random() * 2 - 1) * 0.01;
    }

    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = 'lowpass';
    noiseFilter.frequency.value = 200;

    const noiseGain = ctx.createGain();
    noiseGain.gain.value = 0.3;

    noiseSource.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(masterGain);
    noiseSource.start();

    setIsInitialized(true);
  }, []);

  const fadeIn = useCallback(() => {
    if (!gainNodeRef.current || !audioContextRef.current) return;

    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }

    if (fadeIntervalRef.current) {
      clearInterval(fadeIntervalRef.current);
    }

    const targetVolume = (volume / 100) * 0.3;
    const currentVolume = gainNodeRef.current.gain.value;
    const steps = FADE_DURATION / 50;
    const volumeStep = (targetVolume - currentVolume) / steps;
    let currentStep = 0;

    fadeIntervalRef.current = window.setInterval(() => {
      currentStep++;
      if (gainNodeRef.current) {
        const newVolume = currentVolume + (volumeStep * currentStep);
        gainNodeRef.current.gain.value = Math.max(0, Math.min(targetVolume, newVolume));
      }
      if (currentStep >= steps) {
        if (fadeIntervalRef.current) {
          clearInterval(fadeIntervalRef.current);
        }
      }
    }, 50);
  }, [volume]);

  const fadeOut = useCallback(() => {
    if (!gainNodeRef.current) return;

    if (fadeIntervalRef.current) {
      clearInterval(fadeIntervalRef.current);
    }

    const currentVolume = gainNodeRef.current.gain.value;
    const steps = FADE_DURATION / 50;
    const volumeStep = currentVolume / steps;
    let currentStep = 0;

    fadeIntervalRef.current = window.setInterval(() => {
      currentStep++;
      if (gainNodeRef.current) {
        const newVolume = currentVolume - (volumeStep * currentStep);
        gainNodeRef.current.gain.value = Math.max(0, newVolume);
      }
      if (currentStep >= steps) {
        if (fadeIntervalRef.current) {
          clearInterval(fadeIntervalRef.current);
        }
        setIsPlaying(false);
      }
    }, 50);
  }, []);

  const stopSound = useCallback(() => {
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
      gainNodeRef.current = null;
      nodesRef.current = [];
      setIsInitialized(false);
      setIsPlaying(false);
    }
  }, []);

  const toggleSound = useCallback(() => {
    if (settings?.reduce_motion) return;

    if (!isPlaying) {
      if (!isInitialized) {
        createAmbientSound();
      }
      setTimeout(() => {
        setIsPlaying(true);
        fadeIn();
      }, 100);
      if (settings && !settings.background_sound_enabled) {
        updateSettings({ background_sound_enabled: true });
      }
    } else {
      fadeOut();
    }
  }, [isPlaying, isInitialized, createAmbientSound, fadeIn, fadeOut, settings, updateSettings]);

  const setVolume = useCallback((newVolume: number) => {
    setVolumeState(newVolume);
    if (gainNodeRef.current && isPlaying && !isMuted) {
      gainNodeRef.current.gain.value = (newVolume / 100) * 0.3;
    }
    if (settings) {
      updateSettings({ master_volume: newVolume });
    }
  }, [isPlaying, isMuted, settings, updateSettings]);

  const toggleMute = useCallback(() => {
    if (gainNodeRef.current) {
      if (isMuted) {
        gainNodeRef.current.gain.value = (volume / 100) * 0.3;
      } else {
        gainNodeRef.current.gain.value = 0;
      }
    }
    setIsMuted(!isMuted);
  }, [isMuted, volume]);

  useEffect(() => {
    return () => {
      if (fadeIntervalRef.current) {
        clearInterval(fadeIntervalRef.current);
      }
      stopSound();
    };
  }, [stopSound]);

  return (
    <SoundContext.Provider
      value={{
        isPlaying,
        volume,
        isMuted,
        isInitialized,
        toggleSound,
        setVolume,
        toggleMute,
        fadeIn,
        fadeOut,
      }}
    >
      {children}
    </SoundContext.Provider>
  );
}

export function useSound() {
  const context = useContext(SoundContext);
  if (!context) {
    throw new Error('useSound must be used within a SoundProvider');
  }
  return context;
}
